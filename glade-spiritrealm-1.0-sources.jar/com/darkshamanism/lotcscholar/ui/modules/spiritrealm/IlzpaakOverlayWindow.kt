package com.darkshamanism.lotcscholar.ui.modules.spiritrealm

import com.darkshamanism.lotcscholar.core.ClientContext
import com.darkshamanism.lotcscholar.modules.spiritrealm.IlzpaakSandPath
import com.darkshamanism.lotcscholar.modules.spiritrealm.IlzpaakSignProfile
import com.darkshamanism.lotcscholar.modules.spiritrealm.SpiritRealmLoreRepository
import com.darkshamanism.lotcscholar.modules.spiritrealm.SpiritRealmModule
import com.darkshamanism.lotcscholar.services.SpiritRealmConstellation
import com.darkshamanism.lotcscholar.services.SpiritRealmPayload
import com.darkshamanism.lotcscholar.services.SpiritRealmStar
import com.darkshamanism.lotcscholar.ui.components.wrapPlain
import com.darkshamanism.lotcscholar.ui.overlay.WindowDescriptor
import com.darkshamanism.lotcscholar.ui.overlay.WindowId
import com.darkshamanism.lotcscholar.ui.overlay.WindowState
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import net.minecraft.client.MinecraftClient
import net.minecraft.client.font.TextRenderer
import net.minecraft.client.gui.DrawContext
import net.minecraft.client.gui.screen.Screen
import net.minecraft.client.util.InputUtil
import org.lwjgl.glfw.GLFW

/**
 * Compact Ilzpaak overlay viewer + divination helper.
 */
class IlzpaakOverlayWindow(
    private val ctx: ClientContext,
    private val module: SpiritRealmModule,
) {

    companion object {
        val WINDOW_ID = WindowId("ilzpaak")
    }

    private data class Hitbox(
        val x: Int,
        val y: Int,
        val w: Int,
        val h: Int,
    ) {
        fun contains(px: Int, py: Int): Boolean = px in x until (x + w) && py in y until (y + h)
    }

    private data class SignHitbox(
        val x: Int,
        val y: Int,
        val r: Int,
        val index: Int,
    ) {
        fun contains(px: Int, py: Int): Boolean {
            val dx = x - px
            val dy = y - py
            return (dx * dx + dy * dy) <= (r * r)
        }
    }

    private data class NodeHitbox(
        val x: Int,
        val y: Int,
        val r: Int,
        val signIndex: Int,
        val nodeIndex: Int,
        val star: SpiritRealmStar,
    ) {
        fun contains(px: Int, py: Int): Boolean {
            val dx = x - px
            val dy = y - py
            return (dx * dx + dy * dy) <= (r * r)
        }
    }

    private data class SelectedNode(
        val signIndex: Int,
        val nodeIndex: Int,
        val star: SpiritRealmStar,
    )

    private val signs = SpiritRealmLoreRepository.ilzpaakSigns()
    private val spiritConstellations = SpiritRealmLoreRepository.constellations()
    private val ancestralPool = SpiritRealmLoreRepository.ancestralStars().ifEmpty {
        listOf(SpiritRealmStar("Unknown Ancestral", "", "lesser", "No ancestral lore available."))
    }
    private val skySpiritAssignments = buildSkySpiritAssignments()
    private val skyBackdrop = List(110) { i ->
        val x = unitNoise("ilz_overlay_x_$i")
        val y = unitNoise("ilz_overlay_y_$i")
        val twinkle = 0.5f + unitNoise("ilz_overlay_t_$i")
        Triple(x, y, twinkle)
    }

    private var openedAtMs = System.currentTimeMillis()
    private var lastAutoRefreshAtMs = 0L
    private var highlighted = SpiritRealmLoreRepository.currentTimeConversion().monthIdx.coerceIn(0, signs.lastIndex.coerceAtLeast(0))
    private var divinationMonthIdx = highlighted
    private var divinationDay = SpiritRealmLoreRepository.currentTimeConversion().dayOfMonth
    private var divinationSand = SpiritRealmLoreRepository.guessSandPath(SpiritRealmLoreRepository.currentTimeConversion())
    private var showDivination = false
    private var followPayload = true

    private var prevButton: Hitbox? = null
    private var nextButton: Hitbox? = null
    private var sandButton: Hitbox? = null
    private var toggleDivButton: Hitbox? = null
    private var mapButton: Hitbox? = null
    private var signHitboxes: List<SignHitbox> = emptyList()
    private var nodeHitboxes: List<NodeHitbox> = emptyList()
    private var hoveredSignIdx: Int? = null
    private var focusedSignIdx: Int? = null
    private var selectedNode: SelectedNode? = null
    private var hoveredNode: SelectedNode? = null
    private var lorePanelRect: Hitbox? = null
    private var loreScroll = 0
    private var loreMaxScroll = 0
    private var loreScrollKey = ""

    private var revealedText: String = ""
    private var revealStartedAt: Long = 0L
    private var cachedWrapWidth: Int = -1
    private var cachedWrappedFor: String = ""
    private var cachedWrapped: List<String> = emptyList()

    private fun startReveal(fullText: String) {
        if (fullText == revealedText) return
        revealedText = fullText
        revealStartedAt = if (ctx.config.current.ui.reducedMotion) 0L else System.currentTimeMillis()
        cachedWrappedFor = ""
    }

    private fun visibleRevealText(): String {
        if (revealStartedAt == 0L) return revealedText
        val charsPerSecond = 60L
        val elapsed = System.currentTimeMillis() - revealStartedAt
        val visible = (elapsed * charsPerSecond / 1000L).toInt().coerceAtMost(revealedText.length)
        return if (visible >= revealedText.length) revealedText else revealedText.substring(0, visible)
    }

    private fun isRevealActive(): Boolean =
        revealStartedAt != 0L && visibleRevealText().length < revealedText.length

    private fun completeRevealNow() {
        if (revealStartedAt != 0L) revealStartedAt = System.currentTimeMillis() - 99_999L
    }

    fun createDescriptor(): WindowDescriptor = WindowDescriptor(
        id = WINDOW_ID,
        title = "Ilzpaak",
        defaultWidth = 290,
        defaultHeight = 232,
        resizable = true,
        iconChar = "✦",
        onRender = ::render,
        onMouseClick = ::onMouseClick,
        onMouseScroll = ::onMouseScroll,
        onKeyPress = ::onKeyPress,
    )

    private fun render(
        dc: DrawContext,
        tr: TextRenderer,
        ws: WindowState,
        mx: Int,
        my: Int,
        delta: Float,
    ) {
        val payload = module.snapshot()
        maybeAutoRefresh(payload)
        syncMonthFromPayload(payload)

        val cx = ws.contentX
        val cy = ws.contentY
        val cw = ws.contentW
        val ch = ws.contentH

        renderBackdrop(dc, cx, cy, cw, ch)
        if (signs.isEmpty()) {
            dc.drawTextWithShadow(tr, "No Ilzpaak signs loaded.", cx + 6, cy + 8, 0xFFC7B28A.toInt())
            return
        }

        renderConstellationCluster(dc, ws, mx, my)

        val displayIdx = (focusedSignIdx ?: hoveredSignIdx ?: highlighted).coerceIn(0, signs.lastIndex)
        val active = signs[displayIdx]
        dc.drawTextWithShadow(tr, "Ilzpaak Sky", cx + 4, cy + 3, 0xFFEBD08A.toInt())
        dc.drawTextWithShadow(tr, tr.trimToWidth("${active.orcish} | ${active.elven} | ${active.constellationShape}", cw - 8), cx + 4, cy + 13, 0xFFC9B07A.toInt())
        dc.drawTextWithShadow(tr, tr.trimToWidth("Spirit: ${active.spirit}", cw - 8), cx + 4, cy + 23, 0xFFB99D65.toInt())

        renderControls(dc, tr, ws, mx, my)
        renderBottomPanel(dc, tr, ws, active)
    }

    private fun renderBackdrop(dc: DrawContext, x: Int, y: Int, w: Int, h: Int) {
        val topRgb = 0x12050B
        val midRgb = 0x321022
        val bottomRgb = 0x19070F
        for (row in 0 until h step 2) {
            val t = row.toFloat() / (h - 1).coerceAtLeast(1).toFloat()
            val rise = if (t < 0.56f) (t / 0.56f) else (1f - ((t - 0.56f) / 0.44f)).coerceAtLeast(0f)
            val wave = (((sin((t * PI * 1.8) - 0.5) + 1.0) * 0.5).toFloat() * 0.30f)
            val blend = (rise * 0.70f + wave).coerceIn(0f, 1f)
            val upper = mixColor(topRgb, midRgb, blend)
            val rgb = mixColor(upper, bottomRgb, (t * t * 0.58f).coerceIn(0f, 1f))
            dc.fill(x, y + row, x + w, min(y + h, y + row + 2), argb(255, rgb))
        }
        dc.fill(x, y, x + w, y + h, argb(58, 0x4A1220))
        dc.fill(x, y + (h * 0.22f).toInt(), x + w, y + (h * 0.84f).toInt(), argb(52, 0x5D2430))

        val t = (System.currentTimeMillis() - openedAtMs) / 1300.0
        for ((idx, star) in skyBackdrop.withIndex()) {
            val px = (x + star.first * w + cos(t * 0.06 + idx) * 2.8f).toInt().coerceIn(x, x + w - 1)
            val py = (y + star.second * h + sin(t * 0.08 + idx) * 2.2f).toInt().coerceIn(y, y + h - 1)
            val pulse = 0.5 + (sin(t + idx * 0.21) + 1.0) * 0.24 * star.third
            val alpha = (150f * pulse).toInt().coerceIn(42, 200)
            val warm = unitNoise("ilz_overlay_w_$idx")
            val rgb = mixColor(0xE8B9C0, 0xFFD8AE, warm)
            dc.fill(px, py, px + 1, py + 1, argb(alpha, rgb))
        }
    }

    private fun renderConstellationCluster(dc: DrawContext, ws: WindowState, mx: Int, my: Int) {
        val cx = ws.contentX
        val cy = ws.contentY
        val cw = ws.contentW
        val ch = ws.contentH

        val centerX = cx + cw / 2f
        val centerY = cy + (ch * 0.42f)
        val orbitX = cw * 0.30f
        val orbitY = ch * 0.14f
        val rotation = ((System.currentTimeMillis() - openedAtMs) / 72_000.0) * (PI * 2.0)
        val signScale = ((min(cw, ch) * 0.29f) / 100f).coerceAtLeast(0.34f)

        val signHits = mutableListOf<SignHitbox>()
        val nodeHits = mutableListOf<NodeHitbox>()
        val focusedSign = focusedSignIdx
        hoveredSignIdx = null
        hoveredNode = null
        var bestSignHoverDist = Float.MAX_VALUE
        var bestNodeHoverDist = Float.MAX_VALUE

        for ((idx, sign) in signs.withIndex()) {
            val orbitAngle = rotation + ((PI * 2.0) * idx / signs.size) - (PI / 2.0)
            val signCx = centerX + cos(orbitAngle).toFloat() * orbitX
            val signCy = centerY + sin(orbitAngle).toFloat() * orbitY
            val hitR = max(16, (signScale * 40f).roundToInt())
            val dx = signCx - mx
            val dy = signCy - my
            val distSq = (dx * dx + dy * dy)
            if (distSq <= (hitR * hitR) && distSq < bestSignHoverDist) {
                bestSignHoverDist = distSq
                hoveredSignIdx = idx
            }
            signHits += SignHitbox(signCx.roundToInt(), signCy.roundToInt(), hitR, idx)

            val signSelected = idx == highlighted
            val signHovered = hoveredSignIdx == idx
            val nodeInteractionEnabled = focusedSign != null && focusedSign == idx
            val signDimmed = focusedSign != null && focusedSign != idx
            val assignedStars = skySpiritAssignments.getOrElse(idx) { emptyList() }
            val lineAlpha = when {
                signDimmed -> 70
                signSelected || signHovered || nodeInteractionEnabled -> 225
                else -> 162
            }
            val lineColor = argb(lineAlpha, if (signSelected || signHovered || nodeInteractionEnabled) 0xD7A67A else 0x8C5E45)

            for (edge in sign.constellationEdges) {
                val a = sign.constellationNodes.getOrNull(edge.a) ?: continue
                val b = sign.constellationNodes.getOrNull(edge.b) ?: continue
                val ap = rotatePoint(a.x - 50f, a.y - 50f, rotation + (idx * 0.27))
                val bp = rotatePoint(b.x - 50f, b.y - 50f, rotation + (idx * 0.27))
                val ax = signCx + ap.first * signScale
                val ay = signCy + ap.second * signScale
                val bx = signCx + bp.first * signScale
                val by = signCy + bp.second * signScale
                drawPrimitiveLine(dc, ax, ay, bx, by, lineColor, if (signSelected || signHovered || nodeInteractionEnabled) 1 else 0)
            }

            for ((i, node) in sign.constellationNodes.withIndex()) {
                val np = rotatePoint(node.x - 50f, node.y - 50f, rotation + (idx * 0.27))
                val nx = (signCx + np.first * signScale).roundToInt()
                val ny = (signCy + np.second * signScale).roundToInt()
                val assignedStar = assignedStars.getOrNull(i)
                val nodeDx = nx - mx
                val nodeDy = ny - my
                val nodeDistSq = (nodeDx * nodeDx + nodeDy * nodeDy).toFloat()
                val nodeHovering = nodeInteractionEnabled && assignedStar != null && nodeDistSq <= 14f * 14f
                if (nodeHovering && nodeDistSq < bestNodeHoverDist) {
                    bestNodeHoverDist = nodeDistSq
                    hoveredNode = SelectedNode(idx, i, assignedStar)
                }
                val nodeSelected = selectedNode?.let { it.signIndex == idx && it.nodeIndex == i } == true
                val nodeActive = nodeInteractionEnabled && (nodeSelected || nodeHovering)
                val sz = when {
                    nodeActive -> 3
                    nodeInteractionEnabled -> if (i == 0 || i == sign.constellationNodes.lastIndex) 2 else 1
                    else -> 1
                }
                val glowColor = when {
                    signDimmed -> argb(64, 0x7A5C3A)
                    nodeActive -> argb(210, 0xF0C97E)
                    nodeInteractionEnabled -> argb(162, 0xC99B5D)
                    else -> argb(108, 0x9E7246)
                }
                val coreColor = when {
                    signDimmed -> argb(122, 0xE9CFAE)
                    nodeActive -> argb(255, 0xFFF6DA)
                    else -> argb(232, 0xFFEACE)
                }
                dc.fill(nx - sz - 1, ny - sz - 1, nx + sz + 2, ny + sz + 2, glowColor)
                dc.fill(nx - sz, ny - sz, nx + sz + 1, ny + sz + 1, coreColor)
                if (nodeInteractionEnabled && assignedStar != null) {
                    nodeHits += NodeHitbox(nx, ny, max(8, sz + 8), idx, i, assignedStar)
                }
            }
        }

        signHitboxes = signHits
        nodeHitboxes = nodeHits
        if (hoveredNode != null) {
            highlighted = hoveredNode!!.signIndex
            divinationMonthIdx = hoveredNode!!.signIndex
        }
    }

    private fun renderControls(dc: DrawContext, tr: TextRenderer, ws: WindowState, mx: Int, my: Int) {
        val y = ws.contentY + (ws.contentH * 0.58f).roundToInt()
        var x = ws.contentX + 6

        fun drawBtn(label: String, w: Int): Hitbox {
            val hover = mx in x until (x + w) && my in y until (y + 14)
            dc.fill(x, y, x + w, y + 14, if (hover) 0x55344763 else 0x3321304C)
            dc.drawStrokedRectangle(x, y, w, 14, if (hover) 0xFF8AB6F1.toInt() else 0xFF4A5F86.toInt())
            dc.drawCenteredTextWithShadow(tr, net.minecraft.text.Text.literal(label), x + w / 2, y + 3, 0xFFD5E6FF.toInt())
            val box = Hitbox(x, y, w, 14)
            x += w + 4
            return box
        }

        prevButton = drawBtn("<", 16)
        nextButton = drawBtn(">", 16)
        sandButton = drawBtn("Sand: ${sandShort()}", maxOf(56, tr.getWidth("Sand: ${sandShort()}") + 8))
        toggleDivButton = drawBtn(if (showDivination) "Lore" else "Div", 36)
        mapButton = drawBtn("Map", 30)
    }

    private fun renderBottomPanel(
        dc: DrawContext,
        tr: TextRenderer,
        ws: WindowState,
        active: IlzpaakSignProfile,
    ) {
        val left = ws.contentX + 4
        val right = ws.contentX + ws.contentW - 4
        val top = ws.contentY + (ws.contentH * 0.66f).roundToInt()
        val bottom = ws.contentY + ws.contentH - 4
        dc.fill(left, top, right, bottom, 0xC0130E1C.toInt())
        dc.drawStrokedRectangle(left, top, right - left, bottom - top, 0xFF5D4A2A.toInt())
        lorePanelRect = Hitbox(left, top, right - left, bottom - top)

        var y = top + 5
        fun drawLine(text: String, color: Int) {
            if (y <= bottom - 10) {
                dc.drawTextWithShadow(tr, tr.trimToWidth(text, right - left - 8), left + 4, y, color)
                y += 10
            }
        }

        if (showDivination) {
            val year = SpiritRealmLoreRepository.currentTimeConversion().saYear
            val result = SpiritRealmLoreRepository.divine(
                name = "Unknown Kub",
                calendarSystem = "SA",
                yearInput = year,
                monthIdx = divinationMonthIdx,
                dayInput = divinationDay,
                sand = divinationSand,
            )
            drawLine("Divination | ${result.sign.orcish} | Day $divinationDay", 0xFFE7CB90.toInt())
            drawLine("Path: ${divinationSand.label()}", 0xFFD7C59A.toInt())
            val linesLeft = ((bottom - y - 2) / 10).coerceAtLeast(0)
            for (line in tr.wrapPlain(result.reading, right - left - 8).take(linesLeft)) {
                drawLine(line, 0xFFAFA4BB.toInt())
            }
            loreMaxScroll = 0
            loreScroll = 0
            loreScrollKey = "div"
        } else {
            val hovered = hoveredNode
            val selected = selectedNode
            val node = hovered ?: selected
            if (node != null) {
                drawLine("Star Spirit: ${node.star.name} [${normalizeTier(node.star.tier)}]", tierColor(node.star.tier))
                val domain = node.star.domain.ifBlank { "No role listed" }
                drawLine(domain, 0xFFCDBA91.toInt())
                if (y <= bottom - 10) {
                    drawLine("Spirit details only (plane lore hidden in overlay).", 0xFF8E85A5.toInt())
                }
                loreMaxScroll = 0
                loreScroll = 0
                loreScrollKey = "node:${node.signIndex}:${node.nodeIndex}"
            } else {
                drawLine("${active.constellationShape} | ${active.spiritDomain}", 0xFFD7C59A.toInt())
                drawLine("Spirit: ${active.spirit}", 0xFFCDBA91.toInt())
                val showFull = isShiftDown()
                val lore = overlayLoreText(signLoreText(active), showFull)
                startReveal(lore)
                val wrapWidth = right - left - 8
                val visibleLore = visibleRevealText()
                if (cachedWrappedFor != visibleLore || cachedWrapWidth != wrapWidth) {
                    cachedWrapped = tr.wrapPlain(visibleLore, wrapWidth)
                    cachedWrappedFor = visibleLore
                    cachedWrapWidth = wrapWidth
                }
                val wrapped = cachedWrapped
                val linesLeft = ((bottom - y - 12) / 10).coerceAtLeast(0)
                val key = buildString {
                    append(active.orcish)
                    append('|')
                    append(divinationSand.name)
                    append(':')
                    append(showFull)
                }
                if (loreScrollKey != key) {
                    loreScrollKey = key
                    loreScroll = 0
                }
                loreMaxScroll = (wrapped.size - linesLeft).coerceAtLeast(0)
                loreScroll = loreScroll.coerceIn(0, loreMaxScroll)
                for (line in wrapped.drop(loreScroll).take(linesLeft)) {
                    drawLine(line, 0xFFAFA4BB.toInt())
                }
                if (!showFull && y <= bottom - 10) {
                    drawLine("Hold Shift for full lore. Click sign, then stars for spirits.", 0xFF8E85A5.toInt())
                } else if (showFull && loreMaxScroll > 0 && y <= bottom - 10) {
                    drawLine("Shift lore scroll: mouse wheel", 0xFF8E85A5.toInt())
                }
            }
        }
    }

    private fun onMouseClick(ws: WindowState, mx: Int, my: Int, button: Int): Boolean {
        if (button == 0 && isRevealActive() && lorePanelRect?.contains(mx, my) == true) {
            completeRevealNow()
            return true
        }
        if (button == 1 && focusedSignIdx != null) {
            focusedSignIdx = null
            selectedNode = null
            hoveredNode = null
            loreScroll = 0
            return true
        }
        if (prevButton?.contains(mx, my) == true) {
            cycleMonth(-1)
            return true
        }
        if (nextButton?.contains(mx, my) == true) {
            cycleMonth(1)
            return true
        }
        if (sandButton?.contains(mx, my) == true) {
            cycleSand()
            return true
        }
        if (toggleDivButton?.contains(mx, my) == true) {
            showDivination = !showDivination
            return true
        }
        if (mapButton?.contains(mx, my) == true) {
            module.openScreen(null)
            return true
        }
        val nodeHit = nodeHitboxes.firstOrNull { it.contains(mx, my) }
        if (nodeHit != null) {
            highlighted = nodeHit.signIndex
            divinationMonthIdx = nodeHit.signIndex
            selectedNode = SelectedNode(nodeHit.signIndex, nodeHit.nodeIndex, nodeHit.star)
            loreScroll = 0
            return true
        }
        val signHit = signHitboxes.firstOrNull { it.contains(mx, my) }
        if (signHit != null) {
            highlighted = signHit.index
            divinationMonthIdx = signHit.index
            focusedSignIdx = signHit.index
            selectedNode = null
            followPayload = false
            loreScroll = 0
            return true
        }
        return false
    }

    private fun onMouseScroll(ws: WindowState, mx: Int, my: Int, dx: Double, dy: Double): Boolean {
        val loreRect = lorePanelRect
        if (!showDivination && loreRect != null && loreRect.contains(mx, my)) {
            if (loreMaxScroll > 0 && dy != 0.0) {
                val step = if (dy < 0) 1 else -1
                loreScroll = (loreScroll + step).coerceIn(0, loreMaxScroll)
            }
            return true
        }
        if (dy > 0) cycleMonth(1) else if (dy < 0) cycleMonth(-1)
        return dy != 0.0
    }

    private fun onKeyPress(ws: WindowState, keyCode: Int, scanCode: Int, modifiers: Int): Boolean = when (keyCode) {
        GLFW.GLFW_KEY_F -> {
            val nextFocus = if (focusedSignIdx == highlighted) null else highlighted
            focusedSignIdx = nextFocus
            if (nextFocus != null) {
                followPayload = false
            }
            selectedNode = null
            loreScroll = 0
            true
        }
        GLFW.GLFW_KEY_LEFT -> {
            cycleMonth(-1); true
        }
        GLFW.GLFW_KEY_RIGHT -> {
            cycleMonth(1); true
        }
        GLFW.GLFW_KEY_UP -> {
            divinationDay = (divinationDay + 1).coerceAtMost(24); true
        }
        GLFW.GLFW_KEY_DOWN -> {
            divinationDay = (divinationDay - 1).coerceAtLeast(1); true
        }
        GLFW.GLFW_KEY_O -> {
            cycleSand(); true
        }
        GLFW.GLFW_KEY_V -> {
            showDivination = !showDivination; true
        }
        GLFW.GLFW_KEY_K, GLFW.GLFW_KEY_M -> {
            module.openScreen(null); true
        }
        GLFW.GLFW_KEY_R -> {
            module.requestRefresh(force = true, notifyOnFail = true)
            followPayload = true
            focusedSignIdx = null
            selectedNode = null
            loreScroll = 0
            true
        }
        else -> false
    }

    private fun cycleMonth(step: Int) {
        if (signs.isEmpty()) return
        val size = signs.size
        divinationMonthIdx = ((divinationMonthIdx + step) % size + size) % size
        highlighted = divinationMonthIdx
        if (focusedSignIdx != null) {
            focusedSignIdx = highlighted
        }
        selectedNode = null
        loreScroll = 0
        followPayload = false
    }

    private fun cycleSand() {
        divinationSand = when (divinationSand) {
            IlzpaakSandPath.YELLOW -> IlzpaakSandPath.BOTH
            IlzpaakSandPath.BOTH -> IlzpaakSandPath.RED
            IlzpaakSandPath.RED -> IlzpaakSandPath.YELLOW
        }
    }

    private fun sandShort(): String = when (divinationSand) {
        IlzpaakSandPath.YELLOW -> "Y"
        IlzpaakSandPath.BOTH -> "Both"
        IlzpaakSandPath.RED -> "R"
    }

    private fun maybeAutoRefresh(payload: SpiritRealmPayload?) {
        val now = System.currentTimeMillis()
        if (payload == null && !module.isRefreshing() && now - lastAutoRefreshAtMs > 2400) {
            lastAutoRefreshAtMs = now
            module.requestRefresh(force = true, notifyOnFail = false)
        }
    }

    private fun syncMonthFromPayload(payload: SpiritRealmPayload?) {
        if (!followPayload || signs.isEmpty() || payload == null) return
        val inferred = inferIlzpaakFromPayload(payload)
        if (inferred >= 0) {
            highlighted = inferred
            divinationMonthIdx = inferred
            focusedSignIdx = null
            selectedNode = null
            loreScroll = 0
        }
    }

    private fun inferIlzpaakFromPayload(payload: SpiritRealmPayload): Int {
        val tokens = buildString {
            append(payload.currentSign.name.lowercase())
            append(' ')
            append(payload.currentSign.domain.lowercase())
            if (payload.zodiac.isNotEmpty()) {
                append(' ')
                append(payload.zodiac.joinToString(" ") { it.name.lowercase() })
            }
        }
        return signs.indexOfFirst { sign ->
            tokens.contains(sign.orcish.lowercase()) ||
                tokens.contains(sign.elven.lowercase()) ||
                tokens.contains(sign.spirit.lowercase())
        }
    }

    private fun signLoreText(sign: IlzpaakSignProfile): String = when (divinationSand) {
        IlzpaakSandPath.YELLOW -> sign.yellowReading.ifBlank { sign.general }
        IlzpaakSandPath.RED -> sign.redReading.ifBlank { sign.general }
        IlzpaakSandPath.BOTH -> sign.bothReading.ifBlank { sign.general }
    }.ifBlank { sign.general }

    private fun buildSkySpiritAssignments(): List<List<SpiritRealmStar>> {
        if (signs.isEmpty()) return emptyList()
        val constellationsById = spiritConstellations.associateBy { it.id.lowercase() }
        val fallbackImmortalConstellation = spiritConstellations.firstOrNull { it.id.startsWith("immortal_realm_") }
        val fallbackElementalConstellation = spiritConstellations.firstOrNull { it.id.startsWith("elemental_realm_") }
        val greaterAncestrals = ancestralPool.filter { normalizeTier(it.tier) == "greater" }.ifEmpty { ancestralPool }
        val lesserAncestrals = ancestralPool.filter { normalizeTier(it.tier) == "lesser" }.ifEmpty { ancestralPool }
        val fallbackImmortalLessers = spiritConstellations
            .filter { it.id.startsWith("immortal_realm_") }
            .flatMap { constellation ->
                constellation.stars
                    .filter { normalizeTier(it.tier) == "lesser" }
                    .map { enrichSkyLoreStar(it, "Lesser Immortal Echo", constellation.name) }
            }
            .ifEmpty {
                lesserAncestrals.map { enrichSkyLoreStar(it, "Lesser Ancestral Echo", "Ancestral Realm") }
            }

        val out = mutableListOf<List<SpiritRealmStar>>()
        var greaterAncestralCursor = 0
        var lesserAncestralCursor = 0
        var immortalFallbackCursor = 0

        fun nextGreaterAncestral(): SpiritRealmStar {
            val star = greaterAncestrals[greaterAncestralCursor % greaterAncestrals.size]
            greaterAncestralCursor++
            return enrichSkyLoreStar(star, "Greater Ancestral", "Ancestral Realm")
        }

        fun nextLesserAncestral(): SpiritRealmStar {
            val star = lesserAncestrals[lesserAncestralCursor % lesserAncestrals.size]
            lesserAncestralCursor++
            return enrichSkyLoreStar(star, "Lesser Ancestral", "Ancestral Realm")
        }

        fun nextImmortalFallback(): SpiritRealmStar {
            val star = fallbackImmortalLessers[immortalFallbackCursor % fallbackImmortalLessers.size]
            immortalFallbackCursor++
            return star
        }

        for ((index, sign) in signs.withIndex()) {
            val nodeCount = sign.constellationNodes.size.coerceAtLeast(1)
            val immortalId = "immortal_realm_${normalizedIdToken(sign.spirit)}"
            val elementalId = pickElementalConstellationId(index)

            val immortalConstellation = constellationsById[immortalId] ?: fallbackImmortalConstellation
            val elementalConstellation = constellationsById[elementalId] ?: fallbackElementalConstellation

            val immortalGreater = immortalConstellation?.stars
                ?.firstOrNull { normalizeTier(it.tier) == "greater" }
                ?.let { enrichSkyLoreStar(it, "Greater Immortal", immortalConstellation.name) }

            val immortalLesserPool = mutableListOf<SpiritRealmStar>()
            if (immortalConstellation != null) {
                immortalLesserPool += immortalConstellation.stars
                    .filter { normalizeTier(it.tier) == "lesser" }
                    .map { enrichSkyLoreStar(it, "Lesser Immortal", immortalConstellation.name) }
            }
            if (immortalLesserPool.isEmpty() && sign.spirit.equals("Paxahru", ignoreCase = true)) {
                for (allyId in listOf("immortal_realm_ghorza", "immortal_realm_veist")) {
                    val ally = constellationsById[allyId] ?: continue
                    immortalLesserPool += ally.stars
                        .filter { normalizeTier(it.tier) == "lesser" }
                        .map { enrichSkyLoreStar(it, "Lesser Immortal (Linked)", ally.name) }
                }
            }

            val elementalGreater = elementalConstellation?.stars
                ?.firstOrNull { normalizeTier(it.tier) == "greater" }
                ?.let { enrichSkyLoreStar(it, "Greater Elemental", elementalConstellation.name) }

            val elementalLesserPool = elementalConstellation?.stars
                ?.filter { normalizeTier(it.tier) == "lesser" }
                ?.map { enrichSkyLoreStar(it, "Lesser Elemental", elementalConstellation.name) }
                .orEmpty()

            val assigned = mutableListOf<SpiritRealmStar>()
            assigned += nextLesserAncestral()
            assigned += immortalGreater ?: nextImmortalFallback()
            assigned += elementalGreater ?: nextLesserAncestral()
            assigned += nextGreaterAncestral()
            assigned += if (immortalLesserPool.isNotEmpty()) immortalLesserPool.first() else nextImmortalFallback()
            assigned += if (elementalLesserPool.isNotEmpty()) elementalLesserPool.first() else nextLesserAncestral()

            var immortalCursor = 1
            var elementalCursor = 1
            while (assigned.size < nodeCount) {
                assigned += nextLesserAncestral()
                if (assigned.size >= nodeCount) break
                assigned += if (immortalLesserPool.isNotEmpty()) {
                    immortalLesserPool[immortalCursor % immortalLesserPool.size].also { immortalCursor++ }
                } else {
                    nextImmortalFallback()
                }
                if (assigned.size >= nodeCount) break
                assigned += if (elementalLesserPool.isNotEmpty()) {
                    elementalLesserPool[elementalCursor % elementalLesserPool.size].also { elementalCursor++ }
                } else {
                    nextLesserAncestral()
                }
                if (assigned.size >= nodeCount) break
                assigned += nextLesserAncestral()
            }
            out += assigned.take(nodeCount)
        }
        return out
    }

    private fun enrichSkyLoreStar(star: SpiritRealmStar, role: String, source: String): SpiritRealmStar {
        val taggedDomain = buildString {
            append(role)
            if (source.isNotBlank()) append(" - ").append(source)
            if (star.domain.isNotBlank()) append(" - ").append(star.domain)
        }
        val text = star.description.ifBlank { "$role spirit tied to $source." }
        return star.copy(domain = taggedDomain, description = text)
    }

    private fun pickElementalConstellationId(monthIdx: Int): String = when (monthIdx % 7) {
        0 -> "elemental_realm_neizdark"
        1 -> "elemental_realm_akathro"
        2 -> "elemental_realm_skathach"
        3 -> "elemental_realm_bregthar"
        4 -> "elemental_realm_kulthark"
        5 -> "elemental_realm_fiarza"
        else -> "elemental_realm_akathro"
    }

    private fun normalizedIdToken(value: String): String = value.lowercase()
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .ifBlank { "unknown" }

    private fun rotatePoint(x: Float, y: Float, angle: Double): Pair<Float, Float> {
        val c = cos(angle).toFloat()
        val s = sin(angle).toFloat()
        return Pair((x * c) - (y * s), (x * s) + (y * c))
    }

    private fun drawPrimitiveLine(dc: DrawContext, x1: Float, y1: Float, x2: Float, y2: Float, color: Int, thickness: Int) {
        val dx = x2 - x1
        val dy = y2 - y1
        val steps = max(abs(dx), abs(dy)).roundToInt().coerceAtLeast(1)
        for (i in 0..steps) {
            val t = i.toFloat() / steps.toFloat()
            val x = (x1 + dx * t).roundToInt()
            val y = (y1 + dy * t).roundToInt()
            dc.fill(x - thickness, y - thickness, x + thickness + 1, y + thickness + 1, color)
        }
    }

    private fun tierColor(tier: String): Int = when (normalizeTier(tier)) {
        "greater" -> 0xFFE6BD88.toInt()
        "lesser" -> 0xFF8EE9FF.toInt()
        "dishonored" -> 0xFFFF6C6C.toInt()
        else -> 0xFFCAD5ED.toInt()
    }

    private fun normalizeTier(input: String): String = when (input.lowercase()) {
        "greater" -> "greater"
        "lesser" -> "lesser"
        "dishonored", "dishonoured" -> "dishonored"
        else -> "greater"
    }

    private fun overlayLoreText(raw: String, full: Boolean): String {
        val normalized = normalizeLore(raw)
        if (full || normalized.length <= 220) return normalized
        val cut = normalized.take(220).trimEnd()
        val pivot = cut.lastIndexOf(' ')
        val base = if (pivot > 120) cut.substring(0, pivot) else cut
        return "$base..."
    }

    private fun normalizeLore(raw: String): String = raw
        .replace('\n', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun isShiftDown(): Boolean {
        val client = MinecraftClient.getInstance()
        return InputUtil.isKeyPressed(client.window, GLFW.GLFW_KEY_LEFT_SHIFT) ||
            InputUtil.isKeyPressed(client.window, GLFW.GLFW_KEY_RIGHT_SHIFT)
    }

    private fun argb(alpha: Int, rgb: Int): Int {
        val a = alpha.coerceIn(0, 255)
        return (a shl 24) or (rgb and 0xFFFFFF)
    }

    private fun mixColor(a: Int, b: Int, t: Float): Int {
        val mix = t.coerceIn(0f, 1f)
        val ar = (a shr 16) and 0xFF
        val ag = (a shr 8) and 0xFF
        val ab = a and 0xFF
        val br = (b shr 16) and 0xFF
        val bg = (b shr 8) and 0xFF
        val bb = b and 0xFF
        val r = (ar + ((br - ar) * mix)).roundToInt().coerceIn(0, 255)
        val g = (ag + ((bg - ag) * mix)).roundToInt().coerceIn(0, 255)
        val c = (ab + ((bb - ab) * mix)).roundToInt().coerceIn(0, 255)
        return (r shl 16) or (g shl 8) or c
    }

    private fun unitNoise(seed: String): Float {
        val h = seed.hashCode().toLong() * 1103515245L + 12345L
        val v = ((h ushr 16) and 0x7FFFL).toFloat()
        return (v % 4096f) / 4096f
    }
}
