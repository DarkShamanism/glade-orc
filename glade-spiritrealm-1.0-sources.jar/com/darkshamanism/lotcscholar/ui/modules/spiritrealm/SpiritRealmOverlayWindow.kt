﻿package com.darkshamanism.lotcscholar.ui.modules.spiritrealm

import com.darkshamanism.lotcscholar.core.ClientContext
import com.darkshamanism.lotcscholar.modules.spiritrealm.IlzpaakConstellationNode
import com.darkshamanism.lotcscholar.modules.spiritrealm.SpiritRealmLoreRepository
import com.darkshamanism.lotcscholar.modules.spiritrealm.SpiritRealmModule
import com.darkshamanism.lotcscholar.services.SpiritRealmConstellation
import com.darkshamanism.lotcscholar.services.SpiritRealmPayload
import com.darkshamanism.lotcscholar.services.SpiritRealmStar
import com.darkshamanism.lotcscholar.ui.overlay.WindowDescriptor
import com.darkshamanism.lotcscholar.ui.overlay.WindowId
import com.darkshamanism.lotcscholar.ui.overlay.WindowState
import net.minecraft.client.MinecraftClient
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import net.minecraft.client.font.TextRenderer
import net.minecraft.client.gui.DrawContext
import org.lwjgl.glfw.GLFW

/**
 * Compact overlay chart for Spirit Realm constellations.
 *
 * Designed for the window system: small footprint, fast reference, and no
 * long lore-body panels that crowd the viewport.
 */
class SpiritRealmOverlayWindow(
    private val ctx: ClientContext,
    private val module: SpiritRealmModule,
) {

    companion object {
        val WINDOW_ID = WindowId("spiritrealm-map")
    }

    private data class PlotRect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val width: Int get() = right - left
        val height: Int get() = bottom - top
    }

    private data class StarPoint(
        val key: String,
        val constellation: SpiritRealmConstellation,
        val star: SpiritRealmStar,
        val x: Int,
        val y: Int,
        val radius: Int,
        val color: Int,
    )

    private data class TierPill(
        val id: String,
        val x: Int,
        val y: Int,
        val w: Int,
        val h: Int,
    )

    private data class Hitbox(
        val x: Int,
        val y: Int,
        val w: Int,
        val h: Int,
    ) {
        fun contains(px: Int, py: Int): Boolean = px in x until (x + w) && py in y until (y + h)
    }

    private data class DriftStar(
        var x: Float,
        var y: Float,
        val vx: Float,
        val vy: Float,
        val twinkle: Float,
        val warmBias: Float,
        val size: Int,
    )

    private data class MapRawBounds(
        val minX: Float,
        val maxX: Float,
        val minY: Float,
        val maxY: Float,
    )

    private val driftingStars = MutableList(220) { i ->
        val angle = (unitNoise("spirit_overlay_a_$i") * (PI * 2f).toFloat())
        val speed = 0.010f + (unitNoise("spirit_overlay_s_$i") * 0.040f)
        DriftStar(
            x = unitNoise("spirit_overlay_x_$i"),
            y = unitNoise("spirit_overlay_y_$i"),
            vx = cos(angle) * speed,
            vy = sin(angle) * speed,
            twinkle = 0.6f + unitNoise("spirit_overlay_t_$i"),
            warmBias = unitNoise("spirit_overlay_w_$i"),
            size = if (unitNoise("spirit_overlay_z_$i") > 0.82f) 2 else 1,
        )
    }

    private var revealedText: String = ""
    private var revealStartedAt: Long = 0L

    private fun startReveal(fullText: String) {
        if (fullText == revealedText) return
        revealedText = fullText
        revealStartedAt = if (ctx.config.current.ui.reducedMotion) 0L else System.currentTimeMillis()
    }

    private fun visibleRevealText(): String {
        if (revealStartedAt == 0L) return revealedText
        val charsPerSecond = 60L
        val elapsed = System.currentTimeMillis() - revealStartedAt
        val visible = (elapsed * charsPerSecond / 1000L).toInt().coerceAtMost(revealedText.length)
        return if (visible >= revealedText.length) revealedText else revealedText.substring(0, visible)
    }

    private var openedAtMs = System.currentTimeMillis()
    private var lastSkyDriftMs = System.currentTimeMillis()
    private var lastAutoRefreshAtMs = 0L
    private var tierFilter = "all"
    private var selectedKey = ""
    private var hoveredKey = ""
    private var stars: List<StarPoint> = emptyList()
    private var tierPills: List<TierPill> = emptyList()
    private var switchButton: Hitbox? = null
    private var mapPlot: PlotRect? = null
    private var mapRawBounds: MapRawBounds? = null
    private var mapPanX = 0f
    private var mapPanY = 0f
    private var mapZoom = 1.18f
    private val minMapZoom = 0.36f
    private val maxMapZoom = 2.8f
    private var draggingMap = false
    private var dragLastMouseX = 0
    private var dragLastMouseY = 0
    private val ilzpaakSigns = SpiritRealmLoreRepository.ilzpaakSigns()

    fun createDescriptor(): WindowDescriptor = WindowDescriptor(
        id = WINDOW_ID,
        title = "Spirit Realm",
        defaultWidth = 360,
        defaultHeight = 226,
        resizable = true,
        iconChar = "✶",
        onRender = ::render,
        onMouseClick = ::onMouseClick,
        onMouseScroll = ::onMouseScroll,
        onKeyPress = ::onKeyPress,
    )

    private fun render(
        dc: DrawContext,
        tr: TextRenderer,
        ws: WindowState,
        mx: Int,
        my: Int,
        delta: Float,
    ) {
        val payload = module.snapshot()
        maybeAutoRefresh(payload)

        val cx = ws.contentX
        val cy = ws.contentY
        val cw = ws.contentW
        val ch = ws.contentH

        renderBackdrop(dc, cx, cy, cw, ch)

        val titleY = cy + 3
        dc.drawTextWithShadow(tr, "Spirit Realm", cx + 4, titleY, 0xFFD9C79D.toInt())
        val subtitle = payload?.let {
            val conv = com.darkshamanism.lotcscholar.modules.spiritrealm.SpiritRealmLoreRepository.conversionFromClock(it.clock)
            "SA ${conv.saYear} / FA ${conv.faYear} - ${conv.monthOrcish} Day ${conv.dayOfMonth}"
        } ?: if (module.isRefreshing()) "Syncing..." else "Loading local index..."
        dc.drawTextWithShadow(tr, tr.trimToWidth(subtitle, (cw * 0.62f).toInt()), cx + 4, titleY + 10, 0xFF93A5C9.toInt())

        val ilzLabel = "Ilzpaak"
        val ilzW = tr.getWidth(ilzLabel) + 12
        val ilzX = cx + cw - ilzW - 4
        val ilzY = cy + 2
        val ilzHover = mx in ilzX until (ilzX + ilzW) && my in ilzY until (ilzY + 14)
        dc.fill(ilzX, ilzY, ilzX + ilzW, ilzY + 14, if (ilzHover) 0x55344763 else 0x3321304C)
        dc.drawStrokedRectangle(ilzX, ilzY, ilzW, 14, if (ilzHover) 0xFF8AB6F1.toInt() else 0xFF4A5F86.toInt())
        dc.drawCenteredTextWithShadow(tr, net.minecraft.text.Text.literal(ilzLabel), ilzX + ilzW / 2, ilzY + 3, 0xFFD5E6FF.toInt())
        switchButton = Hitbox(ilzX, ilzY, ilzW, 14)

        val bottomPanelH = 30
        val plot = PlotRect(
            left = cx + 3,
            top = cy + 22,
            right = cx + cw - 3,
            bottom = cy + ch - bottomPanelH - 3,
        )
        mapPlot = plot
        stepMapDrag(mx, my)
        renderTierPills(dc, tr, plot, mx, my)

        if (payload == null) {
            mapRawBounds = null
            dc.drawCenteredTextWithShadow(
                tr,
                net.minecraft.text.Text.literal(if (module.isRefreshing()) "Syncing Spirit Realm data..." else "No Spirit payload yet."),
                cx + cw / 2,
                cy + ch / 2,
                0xFFBBC8E0.toInt(),
            )
            renderBottomInfo(dc, tr, null, null, ws)
            return
        }

        stars = buildStars(payload, plot)
        if (clampMapPan(plot)) {
            stars = buildStars(payload, plot)
        }
        hoveredKey = findHovered(mx, my)?.key ?: ""
        if (selectedKey.isBlank() || stars.none { it.key == selectedKey }) {
            selectedKey = stars.firstOrNull()?.key.orEmpty()
        }
        renderConstellations(dc, stars)

        val selected = stars.firstOrNull { it.key == selectedKey } ?: stars.firstOrNull { it.key == hoveredKey }
        renderBottomInfo(dc, tr, payload, selected, ws)
    }

    private fun renderBackdrop(dc: DrawContext, x: Int, y: Int, w: Int, h: Int) {
        stepDriftingSky()
        val topRgb = 0x08162E
        val midRgb = 0x1A3F7A
        val bottomRgb = 0x090F22
        for (row in 0 until h step 2) {
            val t = row.toFloat() / (h - 1).coerceAtLeast(1).toFloat()
            val rise = if (t < 0.56f) (t / 0.56f) else (1f - ((t - 0.56f) / 0.44f)).coerceAtLeast(0f)
            val wave = (((sin((t * PI * 1.75) - 0.7) + 1.0) * 0.5).toFloat() * 0.35f)
            val blend = (rise * 0.65f + wave).coerceIn(0f, 1f)
            val upper = mixColor(topRgb, midRgb, blend)
            val rgb = mixColor(upper, bottomRgb, (t * t * 0.58f).coerceIn(0f, 1f))
            dc.fill(x, y + row, x + w, min(y + h, y + row + 2), argb(255, rgb))
        }
        dc.fill(x, y, x + w, y + h, argb(72, 0x183667))
        dc.fill(x, y + (h * 0.24f).toInt(), x + w, y + (h * 0.84f).toInt(), argb(56, 0x2E5C96))
        renderDriftingStars(dc, x, y, w, h, coolRgb = 0xAFC9FF, warmRgb = 0xBBD4FF, alphaBase = 132, alphaRange = 74)
    }

    private fun argb(alpha: Int, rgb: Int): Int {
        val a = alpha.coerceIn(0, 255)
        return (a shl 24) or (rgb and 0xFFFFFF)
    }

    private fun mixColor(a: Int, b: Int, t: Float): Int {
        val mix = t.coerceIn(0f, 1f)
        val ar = (a shr 16) and 0xFF
        val ag = (a shr 8) and 0xFF
        val ab = a and 0xFF
        val br = (b shr 16) and 0xFF
        val bg = (b shr 8) and 0xFF
        val bb = b and 0xFF
        val r = (ar + ((br - ar) * mix)).roundToInt().coerceIn(0, 255)
        val g = (ag + ((bg - ag) * mix)).roundToInt().coerceIn(0, 255)
        val c = (ab + ((bb - ab) * mix)).roundToInt().coerceIn(0, 255)
        return (r shl 16) or (g shl 8) or c
    }

    private fun renderTierPills(dc: DrawContext, tr: TextRenderer, plot: PlotRect, mx: Int, my: Int) {
        val pills = listOf(
            "all" to "All",
            "greater" to "Greater",
            "lesser" to "Lesser",
            "dishonored" to "Dishonored",
        )
        var x = plot.left + 6
        val y = plot.top + 4
        tierPills = pills.map { (id, label) ->
            val w = tr.getWidth(label) + 14
            val hovered = mx in x until (x + w) && my in y until (y + 14)
            val selected = tierFilter == id
            dc.fill(
                x, y, x + w, y + 14,
                when {
                    selected -> 0x664578B8
                    hovered -> 0x4438465E
                    else -> 0x330E182B
                },
            )
            dc.drawStrokedRectangle(x, y, w, 14, if (selected) 0xFF7AB9FF.toInt() else 0xFF355173.toInt())
            dc.drawCenteredTextWithShadow(tr, net.minecraft.text.Text.literal(label), x + w / 2, y + 3, 0xFFD5E6FF.toInt())
            val pill = TierPill(id, x, y, w, 14)
            x += w + 5
            pill
        }
    }

    private fun renderConstellations(dc: DrawContext, points: List<StarPoint>) {
        for (group in points.groupBy { it.constellation.id }.values) {
            for (i in 0 until group.lastIndex) {
                drawLine(dc, group[i], group[i + 1], 0x66B6CCFF)
            }
        }
        for (point in points) {
            val hovered = point.key == hoveredKey
            val selected = point.key == selectedKey
            val radius = when {
                selected -> point.radius + 2
                hovered -> point.radius + 1
                else -> point.radius
            }
            drawStar(dc, point.x, point.y, radius, point.color)
        }
    }

    private fun renderBottomInfo(
        dc: DrawContext,
        tr: TextRenderer,
        payload: SpiritRealmPayload?,
        selected: StarPoint?,
        ws: WindowState,
    ) {
        val panelTop = ws.contentY + ws.contentH - 30
        val left = ws.contentX
        val right = ws.contentX + ws.contentW
        dc.fill(left, panelTop, right, ws.contentY + ws.contentH, 0xBA0A0D17.toInt())
        dc.drawStrokedRectangle(left, panelTop, ws.contentW, 30, 0xFF33466B.toInt())

        if (selected == null) {
            val msg = if (payload == null) "Waiting for Spirit data..." else "Click a star to inspect."
            dc.drawTextWithShadow(tr, msg, left + 6, panelTop + 6, 0xFFBBC8E0.toInt())
            return
        }

        val star = selected.star
        val constellation = selected.constellation
        val line1 = "${star.name} [${normalizeTier(star.tier)}]"
        val domain = if (star.domain.isBlank()) "No domain" else star.domain
        val line2 = "${constellation.name} - $domain"
        startReveal(line2)
        val visibleLine2 = visibleRevealText()
        dc.drawTextWithShadow(tr, tr.trimToWidth(line1, ws.contentW - 12), left + 6, panelTop + 4, tierColor(star.tier))
        dc.drawTextWithShadow(tr, tr.trimToWidth(visibleLine2, ws.contentW - 12), left + 6, panelTop + 14, 0xFFB4C2DD.toInt())
    }

    private fun buildStars(payload: SpiritRealmPayload, plot: PlotRect): List<StarPoint> {
        val mapTop = plot.top + 20
        val mapBottom = plot.bottom
        val mapHeight = (mapBottom - mapTop).coerceAtLeast(40)
        val mapRect = PlotRect(plot.left, mapTop, plot.right, mapBottom)

        val clusters = mutableListOf<ConstellationCluster>()
        for (constellation in expandRealmConstellations(payload.constellations)) {
            val filtered = constellation.stars.filter { tierFilter == "all" || normalizeTier(it.tier) == tierFilter }
            if (filtered.isEmpty()) continue
            val orderedStars = orderStarsForConstellation(constellation.id, filtered)
            val bucketTier = if (tierFilter == "all") normalizeTier(constellation.tier) else tierFilter
            val clusterRadius = when (bucketTier) {
                "greater" -> (11f + (orderedStars.size * 1.4f)).coerceIn(10f, 42f)
                "lesser" -> (9f + (orderedStars.size * 1.1f)).coerceIn(8f, 34f)
                else -> (10f + (orderedStars.size * 1.2f)).coerceIn(9f, 32f)
            }
            clusters += ConstellationCluster(
                constellation = constellation,
                stars = orderedStars,
                bucketTier = bucketTier,
                realmKey = realmKeyForConstellation(constellation.id),
                radius = clusterRadius,
                phase = unitNoise("overlay_cluster_phase_${constellation.id}") * (PI * 2f).toFloat(),
            )
        }
        if (clusters.isEmpty()) {
            mapRawBounds = null
            return emptyList()
        }

        val sectors = mapOf(
            "elemental" to realmSectorFor(mapRect, "elemental"),
            "immortal" to realmSectorFor(mapRect, "immortal"),
            "ancestral" to realmSectorFor(mapRect, "ancestral"),
            "unknown" to realmSectorFor(mapRect, "unknown"),
        )
        for ((realm, entries) in clusters.groupBy { it.realmKey }) {
            val sector = sectors[realm] ?: sectors.getValue("unknown")
            placeClustersInSector(entries.sortedBy { it.constellation.id }, sector)
        }
        applyLoreAnchors(clusters, mapRect)

        val pan = min(1f, (System.currentTimeMillis() - openedAtMs) / 900f)
        val panOffset = ((1f - pan) * mapHeight * 0.16f).toInt()
        val out = mutableListOf<StarPoint>()
        val mapCenterX = mapRect.left + (mapRect.width / 2f)
        val mapCenterY = mapRect.top + (mapRect.height / 2f)
        var rawMinX = Float.POSITIVE_INFINITY
        var rawMaxX = Float.NEGATIVE_INFINITY
        var rawMinY = Float.POSITIVE_INFINITY
        var rawMaxY = Float.NEGATIVE_INFINITY

        for (cluster in clusters.sortedWith(compareBy({ it.realmKey }, { it.constellation.id }))) {
            val offsets = buildConstellationOffsets(cluster.constellation.id, cluster.stars.size)
            val color = parseHexColor(cluster.constellation.color, tierColor(cluster.bucketTier))
            for ((index, star) in cluster.stars.withIndex()) {
                val offset = offsets.getOrElse(index) { 0f to 0f }
                val jitterX = (unitNoise("${cluster.constellation.id}_${star.name}_x") - 0.5f) * 2.2f
                val jitterY = (unitNoise("${cluster.constellation.id}_${star.name}_y") - 0.5f) * 2.2f
                val rawSx = (cluster.cx + (offset.first * cluster.radius) + jitterX).roundToInt()
                val rawSy = (cluster.cy + (offset.second * cluster.radius * 0.92f) + jitterY).roundToInt() + panOffset
                rawMinX = min(rawMinX, rawSx.toFloat())
                rawMaxX = max(rawMaxX, rawSx.toFloat())
                rawMinY = min(rawMinY, rawSy.toFloat())
                rawMaxY = max(rawMaxY, rawSy.toFloat())
                val sx = ((rawSx - mapCenterX) * mapZoom + mapCenterX + mapPanX).roundToInt()
                val sy = ((rawSy - mapCenterY) * mapZoom + mapCenterY + mapPanY).roundToInt()
                val key = "${cluster.constellation.id}:${star.name}"
                out += StarPoint(
                    key = key,
                    constellation = cluster.constellation,
                    star = star,
                    x = sx,
                    y = sy,
                    radius = if (normalizeTier(star.tier) == "greater") 2 else 1,
                    color = color,
                )
            }
        }
        mapRawBounds = if (out.isEmpty()) null else MapRawBounds(rawMinX, rawMaxX, rawMinY, rawMaxY)
        return resolveStarStacking(out)
    }

    private data class RealmSector(val cx: Float, val cy: Float, val rx: Float, val ry: Float)

    private data class ConstellationCluster(
        val constellation: SpiritRealmConstellation,
        val stars: List<SpiritRealmStar>,
        val bucketTier: String,
        val realmKey: String,
        val radius: Float,
        val phase: Float,
        var cx: Float = 0f,
        var cy: Float = 0f,
    )

    private fun realmKeyForConstellation(constellationId: String): String = when {
        constellationId.startsWith("elemental_realm_") -> "elemental"
        constellationId.startsWith("immortal_realm_") -> "immortal"
        constellationId.startsWith("ancestral_realm_") -> "ancestral"
        else -> "unknown"
    }

    private fun realmSectorFor(plot: PlotRect, realm: String): RealmSector = when (realm) {
        "elemental" -> RealmSector(
            cx = plot.left + (plot.width * 0.20f),
            cy = plot.top + (plot.height * 0.28f),
            rx = plot.width * 0.24f,
            ry = plot.height * 0.24f,
        )
        "immortal" -> RealmSector(
            cx = plot.left + (plot.width * 0.80f),
            cy = plot.top + (plot.height * 0.30f),
            rx = plot.width * 0.24f,
            ry = plot.height * 0.24f,
        )
        "ancestral" -> RealmSector(
            cx = plot.left + (plot.width * 0.50f),
            cy = plot.top + (plot.height * 0.76f),
            rx = plot.width * 0.42f,
            ry = plot.height * 0.24f,
        )
        else -> RealmSector(
            cx = plot.left + (plot.width * 0.50f),
            cy = plot.top + (plot.height * 0.50f),
            rx = plot.width * 0.20f,
            ry = plot.height * 0.20f,
        )
    }

    private fun placeClustersInSector(clusters: List<ConstellationCluster>, sector: RealmSector) {
        if (clusters.isEmpty()) return
        val golden = 2.3999632f
        val count = clusters.size.toFloat()
        for ((index, cluster) in clusters.withIndex()) {
            val radial = sqrt((index + 0.65f) / (count + 0.35f))
            val angle = (index * golden) + cluster.phase
            val jitterX = (unitNoise("overlay_cluster_${cluster.constellation.id}_jx") - 0.5f) * sector.rx * 0.12f
            val jitterY = (unitNoise("overlay_cluster_${cluster.constellation.id}_jy") - 0.5f) * sector.ry * 0.12f
            cluster.cx = sector.cx + (cos(angle) * sector.rx * radial) + jitterX
            cluster.cy = sector.cy + (sin(angle) * sector.ry * radial) + jitterY
        }

        repeat(30) {
            var moved = false
            for (i in 0 until clusters.lastIndex) {
                val a = clusters[i]
                for (j in i + 1 until clusters.size) {
                    val b = clusters[j]
                    val dx = b.cx - a.cx
                    val dy = b.cy - a.cy
                    val minDist = a.radius + b.radius + 14f
                    val distSq = (dx * dx) + (dy * dy)
                    if (distSq >= (minDist * minDist)) continue
                    val dist = sqrt(distSq.coerceAtLeast(0.0001f))
                    val push = (minDist - dist) * 0.52f
                    val ux = dx / dist
                    val uy = dy / dist
                    a.cx -= ux * push
                    a.cy -= uy * push
                    b.cx += ux * push
                    b.cy += uy * push
                    moved = true
                }
            }
            for (cluster in clusters) {
                val marginX = min(cluster.radius * 0.56f, sector.rx * 0.72f)
                val marginY = min(cluster.radius * 0.56f, sector.ry * 0.72f)
                val minX = sector.cx - sector.rx + marginX
                val maxX = sector.cx + sector.rx - marginX
                val minY = sector.cy - sector.ry + marginY
                val maxY = sector.cy + sector.ry - marginY
                cluster.cx = clampRange(cluster.cx, minX, maxX)
                cluster.cy = clampRange(cluster.cy, minY, maxY)
            }
            if (!moved) return
        }
    }

    private fun clampRange(value: Float, minValue: Float, maxValue: Float): Float {
        if (minValue > maxValue) return (minValue + maxValue) * 0.5f
        return value.coerceIn(minValue, maxValue)
    }

    private fun spreadClustersGlobal(clusters: List<ConstellationCluster>, plot: PlotRect) {
        if (clusters.size < 2) return
        val minX = plot.left + 12f
        val maxX = plot.right - 12f
        val minY = plot.top + 22f
        val maxY = plot.bottom - 10f
        repeat(20) {
            var moved = false
            for (i in 0 until clusters.lastIndex) {
                val a = clusters[i]
                for (j in i + 1 until clusters.size) {
                    val b = clusters[j]
                    val dx = b.cx - a.cx
                    val dy = b.cy - a.cy
                    val minDist = a.radius + b.radius + 11f
                    val distSq = (dx * dx) + (dy * dy)
                    if (distSq >= (minDist * minDist)) continue
                    val dist = sqrt(distSq.coerceAtLeast(0.0001f))
                    val ux = dx / dist
                    val uy = dy / dist
                    val push = (minDist - dist) * 0.38f
                    a.cx -= ux * push
                    a.cy -= uy * push
                    b.cx += ux * push
                    b.cy += uy * push
                    moved = true
                }
            }
            for (cluster in clusters) {
                cluster.cx = cluster.cx.coerceIn(minX, maxX)
                cluster.cy = cluster.cy.coerceIn(minY, maxY)
            }
            if (!moved) return
        }
    }

    private fun applyLoreAnchors(clusters: List<ConstellationCluster>, plot: PlotRect) {
        val byId = clusters.associateBy { it.constellation.id }
        val greater = byId["ancestral_realm_greater_ancestrals"]
        val kulgarokLine = byId["ancestral_realm_dishonored_ancestrals"]
        val kor = byId["immortal_realm_kor"]
        val leyd = clusters.firstOrNull { cluster ->
            cluster.stars.any { star -> star.name.lowercase().contains("leyd") }
        }

        if (greater != null && kor != null) {
            kor.cx = greater.cx + min(greater.radius * 0.24f, plot.width * 0.028f)
            kor.cy = greater.cy + min(greater.radius * 0.14f, plot.height * 0.020f)
        }
        if (kulgarokLine != null) {
            kulgarokLine.cx = plot.left + (plot.width * 0.82f)
            kulgarokLine.cy = plot.top + (plot.height * 0.66f)
        }
        if (leyd != null) {
            leyd.cx = plot.left + (plot.width * 0.80f)
            leyd.cy = plot.top + (plot.height * 0.50f)
        }

        val elementalSpreadIds = listOf(
            "elemental_realm_omnizan",
            "elemental_realm_binazdar",
            "elemental_realm_sandru",
            "elemental_realm_fanzra",
            "elemental_realm_andrif",
            "elemental_realm_ringat",
            "elemental_realm_radzanib",
            "elemental_realm_radnazib",
        )
        val elementalSpread = elementalSpreadIds.mapNotNull { byId[it] }.distinct()
        if (elementalSpread.isNotEmpty()) {
            val centerX = plot.left + (plot.width * 0.18f)
            val centerY = plot.top + (plot.height * 0.56f)
            val radiusX = plot.width * 0.18f
            val radiusY = plot.height * 0.16f
            val n = elementalSpread.size.toFloat()
            for ((index, cluster) in elementalSpread.withIndex()) {
                val t = index.toFloat() / n
                val angle = (0.18f * PI.toFloat()) + (t * (PI * 1.76f).toFloat())
                cluster.cx = centerX + (cos(angle) * radiusX)
                cluster.cy = centerY + (sin(angle) * radiusY)
            }
        }

        val minX = plot.left + 10f
        val maxX = plot.right - 10f
        val minY = plot.top + 22f
        val maxY = plot.bottom - 8f
        for (cluster in listOfNotNull(kor, kulgarokLine, leyd)) {
            cluster.cx = cluster.cx.coerceIn(minX, maxX)
            cluster.cy = cluster.cy.coerceIn(minY, maxY)
        }
    }

    private fun orderStarsForConstellation(
        constellationId: String,
        stars: List<SpiritRealmStar>,
    ): List<SpiritRealmStar> {
        if (constellationId != "ancestral_realm_greater_ancestrals" || stars.isEmpty()) return stars
        val promoted = listOf("Grahla", "Agzal", "Balzug", "Dlimbok", "Saranak")
        val promotedByName = promoted.associateWith { target ->
            stars.firstOrNull { it.name.equals(target, ignoreCase = true) }
        }
        val out = mutableListOf<SpiritRealmStar>()
        var inserted = false
        for (star in stars) {
            if (promoted.any { star.name.equals(it, ignoreCase = true) }) continue
            out += star
            if (!inserted && star.name.equals("Krug", ignoreCase = true)) {
                for (name in promoted) {
                    promotedByName[name]?.let { out += it }
                }
                inserted = true
            }
        }
        if (!inserted) {
            for (name in promoted) {
                promotedByName[name]?.let { out += it }
            }
        }
        return out
    }

    private fun expandRealmConstellations(constellations: List<SpiritRealmConstellation>): List<SpiritRealmConstellation> {
        val sourceId = "ancestral_realm_notable_lesser_ancestrals"
        val chunkSize = 7
        return constellations.flatMap { constellation ->
            if (constellation.id != sourceId || constellation.stars.size <= chunkSize + 2) {
                listOf(constellation)
            } else {
                constellation.stars.chunked(chunkSize).mapIndexed { index, chunk ->
                    constellation.copy(
                        id = "${sourceId}_cluster_${index + 1}",
                        name = "${constellation.name} - Path ${index + 1}",
                        stars = chunk,
                    )
                }
            }
        }
    }

    private fun buildConstellationOffsets(constellationId: String, starCount: Int): List<Pair<Float, Float>> {
        if (starCount <= 0) return emptyList()
        buildIlzpaakDerivedOffsets(constellationId, starCount)?.let { return it }
        if (constellationId.startsWith("ancestral_realm_notable_lesser_ancestrals_cluster_")) {
            return buildLesserAncestralOffsets(constellationId, starCount)
        }
        if (constellationId == "ancestral_realm_or_ta_dom") {
            val base = mutableListOf(
                0.00f to -0.82f,
                0.02f to -0.12f,
                -0.46f to 0.44f,
                0.44f to 0.60f,
            )
            while (base.size < starCount) {
                val i = base.size
                val side = if (i % 2 == 0) -1f else 1f
                base += (side * (0.36f + ((i % 3) * 0.10f))) to (0.28f + (i * 0.06f))
            }
            return base.take(starCount)
        }
        if (starCount == 1) return listOf(0f to 0f)
        if (starCount == 2) return listOf((-0.44f to -0.10f), (0.44f to 0.12f))

        val style = ((constellationId.hashCode() % 4) + 4) % 4
        val out = mutableListOf<Pair<Float, Float>>()
        when (style) {
            0 -> {
                for (i in 0 until starCount) {
                    val t = i.toFloat() / (starCount - 1).toFloat()
                    val x = -0.96f + (1.92f * t)
                    val y = -0.16f + (sin(t * PI).toFloat() * 0.62f)
                    out += x to y
                }
            }
            1 -> {
                for (i in 0 until starCount) {
                    val t = if (starCount <= 1) 0f else i.toFloat() / (starCount - 1).toFloat()
                    val angle = (t * (PI * 4.8f).toFloat()) - (PI * 0.4f).toFloat()
                    val radius = 0.16f + (0.82f * t)
                    out += (cos(angle) * radius).toFloat() to (sin(angle) * radius).toFloat()
                }
            }
            2 -> {
                val trunk = max(2, starCount / 2)
                for (i in 0 until trunk) {
                    val t = if (trunk <= 1) 0f else i.toFloat() / (trunk - 1).toFloat()
                    val y = -0.86f + (t * 1.00f)
                    val x = (unitNoise("${constellationId}_trunk_$i") - 0.5f) * 0.14f
                    out += x to y
                }
                var arm = 0
                while (out.size < starCount) {
                    val side = if (arm % 2 == 0) -1f else 1f
                    val wave = (arm / 2).toFloat()
                    val x = side * (0.34f + (0.14f * (wave % 3f)))
                    val y = -0.08f + (0.24f * wave)
                    out += x to y
                    arm++
                }
            }
            else -> {
                for (i in 0 until starCount) {
                    val t = i.toFloat() / starCount.toFloat()
                    val angle = (t * (PI * 2f).toFloat())
                    val x = (cos(angle) * 0.82f).toFloat() + ((sin(angle * 2.1f) * 0.14f).toFloat())
                    val y = (sin(angle) * 0.60f).toFloat() + ((cos(angle * 1.7f) * 0.12f).toFloat())
                    out += x to y
                }
            }
        }
        val rotation = unitNoise("${constellationId}_rot") * (PI * 2f).toFloat()
        return out.map { rotateOffset(it.first, it.second, rotation) }
    }

    private fun buildLesserAncestralOffsets(constellationId: String, starCount: Int): List<Pair<Float, Float>> {
        if (starCount <= 1) return listOf(0f to 0f)
        if (starCount == 2) return listOf((-0.34f to -0.20f), (0.34f to 0.24f))
        val out = mutableListOf<Pair<Float, Float>>()
        val spineCount = max(3, min(starCount - 2, (starCount * 0.5f).roundToInt()))
        for (i in 0 until spineCount) {
            val t = if (spineCount <= 1) 0f else i.toFloat() / (spineCount - 1).toFloat()
            val x = (unitNoise("${constellationId}_spine_$i") - 0.5f) * 0.12f
            val y = -0.88f + (t * 1.26f)
            out += x to y
        }
        var branch = 0
        while (out.size < starCount) {
            val side = if (branch % 2 == 0) -1f else 1f
            val rung = (branch / 2).toFloat()
            val x = side * (0.28f + ((rung % 3f) * 0.12f))
            val y = -0.36f + (rung * 0.22f)
            out += x to y
            branch++
        }
        val rotation = (unitNoise("${constellationId}_rot") - 0.5f) * (PI * 0.42f).toFloat()
        return out.take(starCount).map { rotateOffset(it.first, it.second, rotation) }
    }

    private fun buildIlzpaakDerivedOffsets(constellationId: String, starCount: Int): List<Pair<Float, Float>>? {
        if (!constellationId.startsWith("immortal_realm_")) return null
        val spiritToken = constellationId.removePrefix("immortal_realm_")
        val sign = ilzpaakSigns.firstOrNull { normalizeIdToken(it.spirit) == spiritToken } ?: return null
        val sampledNodes = sampleIlzpaakNodes(sign.constellationNodes, starCount)
        if (sampledNodes.isEmpty()) return null
        val minX = sampledNodes.minOf { it.x }
        val maxX = sampledNodes.maxOf { it.x }
        val minY = sampledNodes.minOf { it.y }
        val maxY = sampledNodes.maxOf { it.y }
        val cx = (minX + maxX) * 0.5f
        val cy = (minY + maxY) * 0.5f
        val sx = ((maxX - minX) * 0.5f).coerceAtLeast(0.01f)
        val sy = ((maxY - minY) * 0.5f).coerceAtLeast(0.01f)
        return sampledNodes.map { ((it.x - cx) / sx) to ((it.y - cy) / sy) }
    }

    private fun sampleIlzpaakNodes(nodes: List<IlzpaakConstellationNode>, count: Int): List<IlzpaakConstellationNode> {
        if (count <= 0 || nodes.isEmpty()) return emptyList()
        if (count == 1) {
            val avgX = nodes.sumOf { it.x.toDouble() } / nodes.size.toDouble()
            val avgY = nodes.sumOf { it.y.toDouble() } / nodes.size.toDouble()
            return listOf(IlzpaakConstellationNode(avgX.toFloat(), avgY.toFloat()))
        }
        if (count >= nodes.size) return orderNodesByNearest(nodes)

        val selected = mutableListOf<Int>()
        val startIndex = nodes.indices.minByOrNull { nodes[it].y + (nodes[it].x * 0.05f) } ?: 0
        selected += startIndex
        while (selected.size < count) {
            var bestIndex = -1
            var bestScore = -1f
            for (candidate in nodes.indices) {
                if (candidate in selected) continue
                val minDist = selected.minOf { picked ->
                    val dx = nodes[candidate].x - nodes[picked].x
                    val dy = nodes[candidate].y - nodes[picked].y
                    (dx * dx) + (dy * dy)
                }
                if (minDist > bestScore) {
                    bestScore = minDist
                    bestIndex = candidate
                }
            }
            if (bestIndex < 0) break
            selected += bestIndex
        }
        return orderNodesByNearest(selected.map { nodes[it] })
    }

    private fun orderNodesByNearest(nodes: List<IlzpaakConstellationNode>): List<IlzpaakConstellationNode> {
        if (nodes.size <= 2) return nodes
        val remaining = nodes.toMutableList()
        val start = remaining.minByOrNull { it.y + (it.x * 0.05f) } ?: remaining.first()
        remaining.remove(start)
        val ordered = mutableListOf(start)
        while (remaining.isNotEmpty()) {
            val last = ordered.last()
            val next = remaining.minByOrNull { node ->
                val dx = node.x - last.x
                val dy = node.y - last.y
                (dx * dx) + (dy * dy)
            } ?: break
            ordered += next
            remaining.remove(next)
        }
        return ordered
    }

    private fun rotateOffset(x: Float, y: Float, angle: Float): Pair<Float, Float> {
        val c = cos(angle)
        val s = sin(angle)
        return ((x * c) - (y * s)).toFloat() to ((x * s) + (y * c)).toFloat()
    }

    private fun resolveStarStacking(points: List<StarPoint>): List<StarPoint> {
        if (points.size < 2) return points
        val pos = points.map { floatArrayOf(it.x.toFloat(), it.y.toFloat()) }.toMutableList()
        repeat(14) {
            var moved = false
            for (i in 0 until points.lastIndex) {
                for (j in i + 1 until points.size) {
                    val ax = pos[i][0]
                    val ay = pos[i][1]
                    val bx = pos[j][0]
                    val by = pos[j][1]
                    var dx = bx - ax
                    var dy = by - ay
                    val base = (points[i].radius + points[j].radius + 2).toFloat()
                    val extra = if (points[i].constellation.id == points[j].constellation.id) 0f else 5f
                    val minDist = base + extra
                    val distSq = (dx * dx) + (dy * dy)
                    if (distSq >= minDist * minDist) continue
                    var dist = sqrt(distSq.coerceAtLeast(0.0001f))
                    if (distSq < 0.0001f) {
                        val seed = (points[i].key.hashCode() * 31) xor points[j].key.hashCode()
                        val angle = ((((seed % 360) + 360) % 360) / 180.0 * PI).toFloat()
                        dx = cos(angle)
                        dy = sin(angle)
                        dist = 1f
                    } else {
                        dx /= dist
                        dy /= dist
                    }
                    val push = (minDist - dist) * 0.52f
                    pos[i][0] -= dx * push
                    pos[i][1] -= dy * push
                    pos[j][0] += dx * push
                    pos[j][1] += dy * push
                    moved = true
                }
            }
            if (!moved) return@repeat
        }
        return points.indices.map { idx ->
            points[idx].copy(
                x = pos[idx][0].roundToInt(),
                y = pos[idx][1].roundToInt(),
            )
        }
    }

    private fun normalizeIdToken(value: String): String = value.lowercase()
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .ifBlank { "unknown" }

    private fun onMouseClick(ws: WindowState, mx: Int, my: Int, button: Int): Boolean {
        if (button == 1 && pointInMap(mx, my)) {
            mapPanX = 0f
            mapPanY = 0f
            mapZoom = 1.18f
            clampMapPan()
            return true
        }
        val switch = switchButton
        if (switch != null && switch.contains(mx, my)) {
            module.openIlzpaakMainPage(null)
            return true
        }

        val hitPill = tierPills.firstOrNull { mx >= it.x && mx <= it.x + it.w && my >= it.y && my <= it.y + it.h }
        if (hitPill != null) {
            tierFilter = hitPill.id
            return true
        }

        val hit = findHovered(mx, my)
        if (hit != null) {
            selectedKey = hit.key
            return true
        }
        if (button == 0 && pointInMap(mx, my)) {
            draggingMap = true
            dragLastMouseX = mx
            dragLastMouseY = my
            return true
        }
        return false
    }

    private fun onMouseScroll(ws: WindowState, mx: Int, my: Int, dx: Double, dy: Double): Boolean {
        if (!pointInMap(mx, my)) return false
        val oldZoom = mapZoom
        mapZoom = (mapZoom + (dy * 0.09).toFloat()).coerceIn(minMapZoom, maxMapZoom)
        if (mapZoom != oldZoom) {
            clampMapPan()
            return true
        }
        return false
    }

    private fun onKeyPress(ws: WindowState, keyCode: Int, scanCode: Int, modifiers: Int): Boolean = when (keyCode) {
        GLFW.GLFW_KEY_1 -> {
            tierFilter = "greater"; true
        }
        GLFW.GLFW_KEY_2 -> {
            tierFilter = "lesser"; true
        }
        GLFW.GLFW_KEY_3 -> {
            tierFilter = "dishonored"; true
        }
        GLFW.GLFW_KEY_0 -> {
            tierFilter = "all"; true
        }
        GLFW.GLFW_KEY_R -> {
            module.requestRefresh(force = true, notifyOnFail = true); true
        }
        GLFW.GLFW_KEY_EQUAL, GLFW.GLFW_KEY_KP_ADD -> {
            mapZoom = (mapZoom + 0.10f).coerceAtMost(maxMapZoom)
            clampMapPan()
            true
        }
        GLFW.GLFW_KEY_MINUS, GLFW.GLFW_KEY_KP_SUBTRACT -> {
            mapZoom = (mapZoom - 0.10f).coerceAtLeast(minMapZoom)
            clampMapPan()
            true
        }
        GLFW.GLFW_KEY_UP, GLFW.GLFW_KEY_W -> {
            mapPanY += 14f
            clampMapPan()
            true
        }
        GLFW.GLFW_KEY_DOWN, GLFW.GLFW_KEY_S -> {
            mapPanY -= 14f
            clampMapPan()
            true
        }
        GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A -> {
            mapPanX += 14f
            clampMapPan()
            true
        }
        GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D -> {
            mapPanX -= 14f
            clampMapPan()
            true
        }
        GLFW.GLFW_KEY_I -> {
            module.openIlzpaakMainPage(null); true
        }
        else -> false
    }

    private fun stepMapDrag(mx: Int, my: Int) {
        if (!draggingMap) return
        val client = MinecraftClient.getInstance()
        val leftDown = GLFW.glfwGetMouseButton(client.window.handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS
        if (!leftDown) {
            draggingMap = false
            return
        }
        val dx = mx - dragLastMouseX
        val dy = my - dragLastMouseY
        dragLastMouseX = mx
        dragLastMouseY = my
        if (dx != 0 || dy != 0) {
            mapPanX += dx.toFloat()
            mapPanY += dy.toFloat()
            clampMapPan()
        }
    }

    private fun pointInMap(mx: Int, my: Int): Boolean {
        val plot = mapPlot ?: return false
        return mx >= plot.left && mx <= plot.right && my >= (plot.top + 20) && my <= plot.bottom
    }

    private fun clampMapPan(plotRef: PlotRect? = mapPlot): Boolean {
        val plot = plotRef ?: return false
        val bounds = mapRawBounds ?: return false
        val mapTop = plot.top + 20
        val mapCenterX = plot.left + (plot.width / 2f)
        val mapCenterY = mapTop + ((plot.bottom - mapTop) / 2f)

        val transformedMinX = ((bounds.minX - mapCenterX) * mapZoom) + mapCenterX
        val transformedMaxX = ((bounds.maxX - mapCenterX) * mapZoom) + mapCenterX
        val transformedMinY = ((bounds.minY - mapCenterY) * mapZoom) + mapCenterY
        val transformedMaxY = ((bounds.maxY - mapCenterY) * mapZoom) + mapCenterY

        val marginX = 8f
        val marginY = 8f
        var panMinX = (plot.right - marginX) - transformedMaxX
        var panMaxX = (plot.left + marginX) - transformedMinX
        if (panMinX > panMaxX) {
            val mid = (panMinX + panMaxX) * 0.5f
            panMinX = mid
            panMaxX = mid
        }
        var panMinY = (plot.bottom - marginY) - transformedMaxY
        var panMaxY = ((mapTop + marginY) - transformedMinY)
        if (panMinY > panMaxY) {
            val mid = (panMinY + panMaxY) * 0.5f
            panMinY = mid
            panMaxY = mid
        }

        val prevX = mapPanX
        val prevY = mapPanY
        mapPanX = mapPanX.coerceIn(panMinX, panMaxX)
        mapPanY = mapPanY.coerceIn(panMinY, panMaxY)
        return prevX != mapPanX || prevY != mapPanY
    }

    private fun stepDriftingSky() {
        val now = System.currentTimeMillis()
        val dtSec = ((now - lastSkyDriftMs).coerceIn(0L, 60L)).toFloat() / 1000f
        lastSkyDriftMs = now
        if (dtSec <= 0f) return
        for (star in driftingStars) {
            star.x = wrap01(star.x + (star.vx * dtSec))
            star.y = wrap01(star.y + (star.vy * dtSec))
        }
    }

    private fun renderDriftingStars(
        dc: DrawContext,
        x: Int,
        y: Int,
        w: Int,
        h: Int,
        coolRgb: Int,
        warmRgb: Int,
        alphaBase: Int,
        alphaRange: Int,
    ) {
        val t = (System.currentTimeMillis() - openedAtMs) / 700.0
        for ((idx, star) in driftingStars.withIndex()) {
            val px = (x + star.x * w).toInt().coerceIn(x, x + w - 1)
            val py = (y + star.y * h).toInt().coerceIn(y, y + h - 1)
            val pulse = 0.45 + ((sin((t * star.twinkle) + (idx * 0.19)) + 1.0) * 0.28)
            val alpha = (alphaBase + (alphaRange * pulse)).toInt().coerceIn(24, 230)
            val warmMix = (star.warmBias + (sin((t * 0.23) + idx) * 0.18).toFloat()).coerceIn(0f, 1f)
            val rgb = mixColor(coolRgb, warmRgb, warmMix)
            dc.fill(px, py, px + star.size, py + star.size, argb(alpha, rgb))
        }
    }

    private fun wrap01(v: Float): Float = when {
        v < 0f -> v + 1f
        v >= 1f -> v - 1f
        else -> v
    }

    private fun maybeAutoRefresh(payload: SpiritRealmPayload?) {
        val now = System.currentTimeMillis()
        if (payload == null && !module.isRefreshing() && now - lastAutoRefreshAtMs > 2200) {
            lastAutoRefreshAtMs = now
            module.requestRefresh(force = true, notifyOnFail = false)
        }
    }

    private fun findHovered(mx: Int, my: Int): StarPoint? {
        var best: StarPoint? = null
        var bestDist = Int.MAX_VALUE
        for (p in stars) {
            val dx = p.x - mx
            val dy = p.y - my
            val dist = dx * dx + dy * dy
            val maxDist = (p.radius + 5) * (p.radius + 5)
            if (dist <= maxDist && dist < bestDist) {
                best = p
                bestDist = dist
            }
        }
        return best
    }

    private fun drawStar(dc: DrawContext, x: Int, y: Int, r: Int, color: Int) {
        dc.fill(x - r, y, x + r + 1, y + 1, color)
        dc.fill(x, y - r, x + 1, y + r + 1, color)
        dc.fill(x - 1, y - 1, x + 2, y + 2, color)
    }

    private fun drawLine(dc: DrawContext, a: StarPoint, b: StarPoint, color: Int) {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val steps = max(abs(dx), abs(dy))
        if (steps <= 0) return
        for (i in 0..steps step 2) {
            val t = i.toFloat() / steps.toFloat()
            val x = (a.x + dx * t).toInt()
            val y = (a.y + dy * t).toInt()
            dc.fill(x, y, x + 1, y + 1, color)
        }
    }

    private fun tierColor(tier: String): Int = when (normalizeTier(tier)) {
        "greater" -> 0xFFE6BD88.toInt()
        "lesser" -> 0xFF8EE9FF.toInt()
        "dishonored" -> 0xFFFF6C6C.toInt()
        else -> 0xFFCAD5ED.toInt()
    }

    private fun parseHexColor(raw: String?, fallback: Int): Int {
        if (raw.isNullOrBlank()) return fallback
        val clean = raw.trim().removePrefix("#")
        return if (clean.length == 6) {
            runCatching { 0xFF000000.toInt() or clean.toInt(16) }.getOrDefault(fallback)
        } else fallback
    }

    private fun normalizeTier(input: String): String = when (input.lowercase()) {
        "greater" -> "greater"
        "lesser" -> "lesser"
        "dishonored", "dishonoured" -> "dishonored"
        else -> "greater"
    }

    private fun unitNoise(seed: String): Float {
        val h = seed.hashCode().toLong() * 1103515245L + 12345L
        val v = ((h ushr 16) and 0x7FFFL).toFloat()
        return (v % 4096f) / 4096f
    }
}

