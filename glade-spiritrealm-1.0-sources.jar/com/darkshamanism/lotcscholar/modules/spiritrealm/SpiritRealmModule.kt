package com.darkshamanism.lotcscholar.modules.spiritrealm

import com.darkshamanism.lotcscholar.core.ClientContext
import com.darkshamanism.lotcscholar.core.GladeModuleProvider
import com.darkshamanism.lotcscholar.core.HasKeybinds
import com.darkshamanism.lotcscholar.core.HasScreen
import com.darkshamanism.lotcscholar.core.ModuleManager
import com.darkshamanism.lotcscholar.core.ModuleCategory
import com.darkshamanism.lotcscholar.core.TickableModule
import com.darkshamanism.lotcscholar.services.SpiritRealmPayload
import com.darkshamanism.lotcscholar.ui.modules.spiritrealm.IlzpaakOverlayWindow
import com.darkshamanism.lotcscholar.ui.modules.spiritrealm.SpiritRealmOverlayWindow
import kotlin.concurrent.thread
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.screen.Screen
import org.lwjgl.glfw.GLFW

class SpiritRealmModule : GladeModuleProvider, TickableModule, HasScreen, HasKeybinds {

    override val id = "spiritrealm"
    override val title = "Spirit Realm"
    override val category = ModuleCategory.TOOLS

    private lateinit var ctx: ClientContext
    private var openKey: net.minecraft.client.option.KeyBinding? = null
    private var openIlzpaakKey: net.minecraft.client.option.KeyBinding? = null
    private var overlayWindow: SpiritRealmOverlayWindow? = null
    private var ilzpaakOverlayWindow: IlzpaakOverlayWindow? = null
    private var ilzpaakModuleRegistered = false

    @Volatile private var cachedPayload: SpiritRealmPayload? = null
    @Volatile private var refreshInFlight = false
    @Volatile private var lastRefreshAtMs: Long = 0L

    private val refreshIntervalMs = 60_000L

    override fun register(context: ClientContext) {
        ctx = context
        if (overlayWindow == null) {
            overlayWindow = SpiritRealmOverlayWindow(context, this)
        }
        if (ilzpaakOverlayWindow == null) {
            ilzpaakOverlayWindow = IlzpaakOverlayWindow(context, this)
        }
        context.windowRegistry.register(overlayWindow!!.createDescriptor())
        context.windowRegistry.register(ilzpaakOverlayWindow!!.createDescriptor())
        if (!ilzpaakModuleRegistered) {
            ModuleManager.register(IlzpaakModule(this), context)
            ilzpaakModuleRegistered = true
        }
        requestRefresh(force = true, notifyOnFail = false)
    }

    override fun registerKeybinds(context: ClientContext) {
        openKey = context.keybinds.register(
            "key.lotcscholar.spiritrealm.open",
            GLFW.GLFW_KEY_END,
        )
        openIlzpaakKey = context.keybinds.register(
            "key.lotcscholar.ilzpaak.open",
            GLFW.GLFW_KEY_HOME,
        )
    }

    override fun handleTick(client: MinecraftClient) {
        requestRefresh(force = false, notifyOnFail = false)
        while (openKey?.wasPressed() == true) {
            requestRefresh(force = true, notifyOnFail = false)
            openScreen(null)
        }
        while (openIlzpaakKey?.wasPressed() == true) {
            requestRefresh(force = true, notifyOnFail = false)
            openIlzpaakMainPage(null)
        }
    }

    override fun openScreen(parent: Screen?) {
        requestRefresh(force = true, notifyOnFail = false)
        MinecraftClient.getInstance().setScreen(SpiritRealmScreen(parent, ctx, this))
    }

    fun openIlzpaakMainPage(parent: Screen?) {
        requestRefresh(force = true, notifyOnFail = false)
        MinecraftClient.getInstance().setScreen(
            SpiritRealmScreen(
                parent = parent,
                ctx = ctx,
                module = this,
                startInIlzpaak = true,
            ),
        )
    }

    fun snapshot(): SpiritRealmPayload? = cachedPayload

    fun isRefreshing(): Boolean = refreshInFlight

    fun requestRefresh(force: Boolean, notifyOnFail: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && (now - lastRefreshAtMs) < refreshIntervalMs) return
        if (refreshInFlight) return
        refreshInFlight = true
        thread(name = "SpiritRealmRefresh", isDaemon = true) {
            try {
                val payload = ctx.api.fetchSpiritRealm()
                val enriched = SpiritRealmLoreRepository.enrichPayload(payload)
                cachedPayload = enriched
                lastRefreshAtMs = System.currentTimeMillis()
                if (payload == null && notifyOnFail) {
                    ctx.notification.error("Spirit Realm sync failed. Showing local lore index and Ilzpaak data.")
                }
            } finally {
                refreshInFlight = false
            }
        }
    }
}
