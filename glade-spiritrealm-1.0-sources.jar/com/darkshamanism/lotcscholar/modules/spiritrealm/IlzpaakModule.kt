package com.darkshamanism.lotcscholar.modules.spiritrealm

import com.darkshamanism.lotcscholar.core.ClientContext
import com.darkshamanism.lotcscholar.core.ClientModule
import com.darkshamanism.lotcscholar.core.HasScreen
import com.darkshamanism.lotcscholar.core.ModuleCategory
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.screen.Screen

/**
 * Dedicated full-screen entry point for Ilzpaak.
 *
 * Uses the Spirit Realm data/cache module and opens [SpiritRealmScreen]
 * directly in Ilzpaak mode so players can travel to it from the hub.
 */
class IlzpaakModule(
    private val spiritRealm: SpiritRealmModule,
) : ClientModule, HasScreen {

    override val id = "ilzpaak"
    override val title = "Ilzpaak"
    override val category = ModuleCategory.TOOLS

    private lateinit var ctx: ClientContext

    override fun register(context: ClientContext) {
        ctx = context
    }

    override fun openScreen(parent: Screen?) {
        spiritRealm.requestRefresh(force = true, notifyOnFail = false)
        MinecraftClient.getInstance().setScreen(
            SpiritRealmScreen(
                parent = parent,
                ctx = ctx,
                module = spiritRealm,
                startInIlzpaak = true,
            ),
        )
    }
}
