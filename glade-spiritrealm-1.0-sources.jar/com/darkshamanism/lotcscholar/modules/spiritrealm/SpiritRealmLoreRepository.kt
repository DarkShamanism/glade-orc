package com.darkshamanism.lotcscholar.modules.spiritrealm

import com.darkshamanism.lotcscholar.services.SpiritRealmClock
import com.darkshamanism.lotcscholar.services.SpiritRealmConstellation
import com.darkshamanism.lotcscholar.services.SpiritRealmPayload
import com.darkshamanism.lotcscholar.services.SpiritRealmSign
import com.darkshamanism.lotcscholar.services.SpiritRealmStar
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.absoluteValue

enum class IlzpaakSandPath {
    YELLOW,
    BOTH,
    RED;

    fun id(): String = when (this) {
        YELLOW -> "yellow"
        BOTH -> "both"
        RED -> "red"
    }

    fun label(): String = when (this) {
        YELLOW -> "Yellow Sand"
        BOTH -> "Twin Sands"
        RED -> "Red Sand"
    }
}

data class IlzpaakConstellationNode(val x: Float, val y: Float)
data class IlzpaakConstellationEdge(val a: Int, val b: Int)

data class IlzpaakSignProfile(
    val month: Int,
    val elven: String,
    val orcish: String,
    val spirit: String,
    val spiritDomain: String,
    val constellationShape: String,
    val symbol: String,
    val general: String,
    val yellowReading: String,
    val redReading: String,
    val bothReading: String,
    val yellowNature: String,
    val redNature: String,
    val bothNature: String,
    val yellowTraits: List<String>,
    val redTraits: List<String>,
    val bothTraits: List<String>,
    val constellationNodes: List<IlzpaakConstellationNode>,
    val constellationEdges: List<IlzpaakConstellationEdge>,
)

data class IlzpaakMonthInfo(
    val idx: Int,
    val elven: String,
    val orcish: String,
    val weekday: String,
)

data class IlzpaakTimeConversion(
    val saYear: Int,
    val faYear: Int,
    val monthIdx: Int,
    val dayOfMonth: Int,
    val hour: Int,
    val minute: Int,
    val zoneId: String,
    val monthElven: String,
    val monthOrcish: String,
)

data class IlzpaakDivinationResult(
    val name: String,
    val sign: IlzpaakSignProfile,
    val sand: IlzpaakSandPath,
    val dateLabel: String,
    val ageNote: String,
    val reading: String,
    val sandNature: String,
    val signNature: String,
    val traits: List<String>,
    val saYear: Int?,
    val faYear: Int?,
)

private data class LoadedData(
    val constellations: List<SpiritRealmConstellation>,
    val ancestrals: List<SpiritRealmStar>,
    val ilzpaakMonths: List<IlzpaakMonthInfo>,
    val ilzpaakSigns: List<IlzpaakSignProfile>,
    val sandNature: Map<IlzpaakSandPath, String>,
    val anchorSaYear: Int,
    val anchorDate: LocalDate,
)

object SpiritRealmLoreRepository {

    private const val SPIRIT_INDEX_PATH = "/assets/lotcscholar/data/spirit_index.json"
    private const val ILZPAAK_SIGNS_PATH = "/assets/lotcscholar/data/ilzpaak_signs.json"
    private val localZoneId: ZoneId = ZoneId.systemDefault()
    private val stampFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

    private val loadedData: LoadedData by lazy(LazyThreadSafetyMode.PUBLICATION) { loadData() }

    fun ilzpaakSigns(): List<IlzpaakSignProfile> = loadedData.ilzpaakSigns

    fun ilzpaakMonths(): List<IlzpaakMonthInfo> = loadedData.ilzpaakMonths

    fun ancestralStars(): List<SpiritRealmStar> = loadedData.ancestrals

    fun constellations(): List<SpiritRealmConstellation> = loadedData.constellations

    fun enrichPayload(remote: SpiritRealmPayload?): SpiritRealmPayload {
        val conversion = currentTimeConversion()
        val localClock = fallbackClock(conversion)
        val clock = remote?.clock?.takeUnless { it.display.isBlank() || it.display.equals("Unknown", ignoreCase = true) } ?: localClock

        val signs = loadedData.ilzpaakSigns.sortedBy { it.month }
        val fallbackCurrent = signs.getOrNull(conversion.monthIdx)?.let { SpiritRealmSign(name = it.elven, domain = it.spirit) }
            ?: SpiritRealmSign(name = "Unknown", domain = "")
        val currentSign = remote?.currentSign?.takeUnless { it.name.isBlank() || it.name.equals("Unknown", ignoreCase = true) } ?: fallbackCurrent

        val fallbackZodiac = signs.map { SpiritRealmSign(name = it.elven, domain = it.spirit) }
        val zodiac = remote?.zodiac?.takeIf { it.isNotEmpty() } ?: fallbackZodiac

        val mergedConstellations = mergeConstellations(
            local = loadedData.constellations,
            remote = remote?.constellations.orEmpty(),
        )

        return SpiritRealmPayload(
            fetchedAtEpochMs = System.currentTimeMillis(),
            clock = clock,
            currentSign = currentSign,
            zodiac = zodiac,
            constellations = mergedConstellations,
        )
    }

    fun currentTimeConversion(now: ZonedDateTime = ZonedDateTime.now(localZoneId)): IlzpaakTimeConversion {
        val anchorWeek = weekStart(loadedData.anchorDate)
        val currentWeek = weekStart(now.toLocalDate())
        val weeksDiff = ChronoUnit.WEEKS.between(anchorWeek, currentWeek).toInt()
        val sa = loadedData.anchorSaYear + weeksDiff
        val fa = sa + 1796
        val monthIdx = weekdayToMonth(now.dayOfWeek)
        val month = loadedData.ilzpaakMonths.getOrNull(monthIdx) ?: loadedData.ilzpaakMonths.first()
        val dayOfMonth = (now.hour + 1).coerceIn(1, 24)
        return IlzpaakTimeConversion(
            saYear = sa,
            faYear = fa,
            monthIdx = monthIdx,
            dayOfMonth = dayOfMonth,
            hour = now.hour,
            minute = now.minute,
            zoneId = now.zone.id,
            monthElven = month.elven,
            monthOrcish = month.orcish,
        )
    }

    fun conversionFromClock(clock: SpiritRealmClock?): IlzpaakTimeConversion {
        val fallback = currentTimeConversion()
        if (clock == null) return fallback
        val dayOfYear = clock.dayOfYear.coerceAtLeast(1)
        val monthIdx = ((dayOfYear - 1) / 24).coerceIn(0, 6)
        val dayOfMonth = ((dayOfYear - 1) % 24) + 1
        val month = loadedData.ilzpaakMonths.getOrNull(monthIdx) ?: loadedData.ilzpaakMonths.first()
        val saYear = clock.ageYear.takeIf { it > 0 } ?: fallback.saYear
        return IlzpaakTimeConversion(
            saYear = saYear,
            faYear = saYear + 1796,
            monthIdx = monthIdx,
            dayOfMonth = dayOfMonth,
            hour = clock.hour.coerceIn(0, 23),
            minute = clock.minute.coerceIn(0, 59),
            zoneId = clock.timezone.ifBlank { fallback.zoneId },
            monthElven = month.elven,
            monthOrcish = month.orcish,
        )
    }

    fun guessSandPath(conversion: IlzpaakTimeConversion): IlzpaakSandPath = when (conversion.hour) {
        6, 18 -> IlzpaakSandPath.BOTH
        in 7..17 -> IlzpaakSandPath.YELLOW
        else -> IlzpaakSandPath.RED
    }

    fun divine(
        name: String,
        calendarSystem: String,
        yearInput: Int?,
        monthIdx: Int,
        dayInput: Int?,
        sand: IlzpaakSandPath,
    ): IlzpaakDivinationResult {
        val safeMonth = monthIdx.coerceIn(0, 6)
        val sign = loadedData.ilzpaakSigns.firstOrNull { it.month == safeMonth } ?: loadedData.ilzpaakSigns.first()
        val currentSa = currentTimeConversion().saYear

        val normalizedName = name.trim().ifBlank { "Unknown Kub" }
        val day = dayInput?.coerceIn(1, 24)
        val cal = calendarSystem.uppercase()

        val (saYear, faYear) = when (cal) {
            "FA" -> {
                val fa = yearInput
                if (fa == null) null to null
                else if (fa <= 1795) null to fa
                else (fa - 1796) to fa
            }
            else -> {
                val sa = yearInput
                if (sa == null) null to null
                else sa to (sa + 1796)
            }
        }

        val dayLabel = day?.let { "the ${ordinal(it)} of " } ?: ""
        val dateLabel = when {
            yearInput == null -> "Born on ${dayLabel}${sign.elven}"
            cal == "FA" && (faYear ?: 0) <= 1795 -> "Born on ${dayLabel}${sign.elven}, FA ${faYear}"
            cal == "FA" -> "Born on ${dayLabel}${sign.elven}, FA ${faYear} (SA ${saYear})"
            else -> "Born on ${dayLabel}${sign.elven}, SA ${saYear} (FA ${faYear})"
        }

        val ageNote = when {
            yearInput == null -> "Current year: SA $currentSa (FA ${currentSa + 1796})"
            cal == "FA" && (faYear ?: 0) <= 1795 -> {
                val faCurrent = currentSa + 1796
                val diff = (faCurrent - (faYear ?: faCurrent)).absoluteValue
                "First Age chart - FA ${faYear} - ${diff} year(s) from current FA $faCurrent"
            }
            saYear != null -> {
                val diff = currentSa - saYear
                if (diff >= 0) "Chart cast $diff year(s) ago - current SA $currentSa"
                else "Chart cast for SA $saYear - current SA $currentSa"
            }
            else -> "Current year: SA $currentSa (FA ${currentSa + 1796})"
        }

        val (reading, nature, traits) = when (sand) {
            IlzpaakSandPath.YELLOW -> Triple(sign.yellowReading, sign.yellowNature, sign.yellowTraits)
            IlzpaakSandPath.RED -> Triple(sign.redReading, sign.redNature, sign.redTraits)
            IlzpaakSandPath.BOTH -> Triple(sign.bothReading, sign.bothNature, sign.bothTraits)
        }

        return IlzpaakDivinationResult(
            name = normalizedName,
            sign = sign,
            sand = sand,
            dateLabel = dateLabel,
            ageNote = ageNote,
            reading = reading,
            sandNature = loadedData.sandNature[sand].orEmpty(),
            signNature = nature,
            traits = traits,
            saYear = saYear,
            faYear = faYear,
        )
    }

    private fun mergeConstellations(
        local: List<SpiritRealmConstellation>,
        remote: List<SpiritRealmConstellation>,
    ): List<SpiritRealmConstellation> {
        val byId = LinkedHashMap<String, SpiritRealmConstellation>()
        local.forEach { byId[normalizeId(it.id, it.name)] = normalizeConstellation(it) }

        for (remoteConstellation in remote) {
            val id = normalizeId(remoteConstellation.id, remoteConstellation.name)
            val normalizedRemote = normalizeConstellation(remoteConstellation, fallbackId = id)
            val existing = byId[id]
            if (existing == null) {
                byId[id] = normalizedRemote
                continue
            }

            val mergedStars = LinkedHashMap<String, SpiritRealmStar>()
            existing.stars.forEach { mergedStars[starKey(it)] = normalizeStar(it) }
            normalizedRemote.stars.forEach { mergedStars[starKey(it)] = normalizeStar(it) }

            byId[id] = existing.copy(
                name = if (normalizedRemote.name.isNotBlank()) normalizedRemote.name else existing.name,
                tier = if (normalizedRemote.tier.isNotBlank()) normalizeTier(normalizedRemote.tier) else existing.tier,
                color = if (normalizedRemote.color.isNotBlank()) normalizedRemote.color else existing.color,
                stars = mergedStars.values.toList(),
            )
        }
        return byId.values.toList()
    }

    private fun fallbackClock(conversion: IlzpaakTimeConversion): SpiritRealmClock {
        val dayOfYear = (conversion.monthIdx * 24 + conversion.dayOfMonth).coerceIn(1, 168)
        return SpiritRealmClock(
            ageLabel = "Second Age of Warfare",
            ageYear = conversion.saYear,
            absoluteYear = conversion.faYear,
            dayOfYear = dayOfYear,
            hour = conversion.hour,
            minute = conversion.minute,
            display = "${conversion.monthElven} (${conversion.monthOrcish}) - Day ${conversion.dayOfMonth}, SA ${conversion.saYear}",
            timezone = conversion.zoneId,
            serverNowLocal = LocalDateTime.now(localZoneId).format(stampFormatter),
        )
    }

    private fun normalizeConstellation(
        c: SpiritRealmConstellation,
        fallbackId: String = normalizeId(c.id, c.name),
    ): SpiritRealmConstellation {
        val safeTier = normalizeTier(c.tier)
        return SpiritRealmConstellation(
            id = fallbackId,
            name = c.name.ifBlank { fallbackId.replace('_', ' ') },
            tier = safeTier,
            color = c.color.ifBlank { "#ffffff" },
            stars = c.stars.map { normalizeStar(it) },
        )
    }

    private fun normalizeStar(star: SpiritRealmStar): SpiritRealmStar = SpiritRealmStar(
        name = star.name.ifBlank { "Unknown" },
        domain = star.domain,
        tier = normalizeTier(star.tier),
        description = star.description,
    )

    private fun starKey(star: SpiritRealmStar): String = star.name.lowercase() + "|" + star.domain.lowercase()

    private fun normalizeId(id: String, name: String): String {
        val source = id.ifBlank { name }
        return source.lowercase()
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "spirit_constellation" }
    }

    private fun normalizeTier(tier: String): String = when (tier.lowercase()) {
        "greater" -> "greater"
        "lesser" -> "lesser"
        "dishonored", "dishonoured" -> "dishonored"
        else -> "greater"
    }

    private fun weekdayToMonth(dayOfWeek: DayOfWeek): Int = when (dayOfWeek) {
        DayOfWeek.WEDNESDAY -> 0
        DayOfWeek.THURSDAY -> 1
        DayOfWeek.FRIDAY -> 2
        DayOfWeek.SATURDAY -> 3
        DayOfWeek.SUNDAY -> 4
        DayOfWeek.MONDAY -> 5
        DayOfWeek.TUESDAY -> 6
    }

    private fun weekStart(date: LocalDate): LocalDate {
        val shift = if (date.dayOfWeek == DayOfWeek.SUNDAY) 6L else (date.dayOfWeek.value - 1L)
        return date.minusDays(shift)
    }

    private fun ordinal(value: Int): String = when {
        value % 100 in 11..13 -> "${value}th"
        value % 10 == 1 -> "${value}st"
        value % 10 == 2 -> "${value}nd"
        value % 10 == 3 -> "${value}rd"
        else -> "${value}th"
    }

    private fun loadData(): LoadedData {
        val spiritRoot = readResourceJson(SPIRIT_INDEX_PATH)
        val ilzRoot = readResourceJson(ILZPAAK_SIGNS_PATH)

        val constellations = spiritRoot?.getAsJsonArray("constellations")
            ?.mapNotNull { it.asJsonObjectOrNull() }
            ?.map { parseConstellation(it) }
            ?.filter { it.stars.isNotEmpty() }
            .orEmpty()

        val ancestrals = spiritRoot?.getAsJsonArray("ancestrals")
            ?.mapNotNull { it.asJsonObjectOrNull() }
            ?.map { parseStar(it) }
            ?.filter { it.name.isNotBlank() }
            .orEmpty()

        val calendar = ilzRoot?.getAsJsonObject("calendar")
        val months = calendar?.getAsJsonArray("months")
            ?.mapNotNull { it.asJsonObjectOrNull() }
            ?.map {
                IlzpaakMonthInfo(
                    idx = it.optInt("idx", 0).coerceIn(0, 6),
                    elven = it.optString("elven", "Unknown"),
                    orcish = it.optString("orcish", "Unknown"),
                    weekday = it.optString("weekday", ""),
                )
            }
            ?.sortedBy { it.idx }
            .orEmpty()

        val signs = ilzRoot?.getAsJsonArray("signs")
            ?.mapNotNull { it.asJsonObjectOrNull() }
            ?.map { parseSign(it) }
            ?.sortedBy { it.month }
            .orEmpty()

        val sandNatureObj = calendar?.getAsJsonObject("sand_nature")
        val sandNature = mapOf(
            IlzpaakSandPath.YELLOW to (sandNatureObj?.optString("yellow").orEmpty()),
            IlzpaakSandPath.BOTH to (sandNatureObj?.optString("both").orEmpty()),
            IlzpaakSandPath.RED to (sandNatureObj?.optString("red").orEmpty()),
        )

        val anchorYear = calendar?.optInt("sa_anchor_year", 275) ?: 275
        val anchorDate = runCatching { LocalDate.parse(calendar?.optString("anchor_date", "2026-03-09")) }.getOrElse { LocalDate.of(2026, 3, 9) }

        val fallbackConstellation = SpiritRealmConstellation(
            id = "fallback_spirit_lore",
            name = "Spirit Lore",
            tier = "greater",
            color = "#88ccaa",
            stars = listOf(
                SpiritRealmStar(
                    name = "Krug",
                    domain = "First Shaman",
                    tier = "greater",
                    description = "Fallback spirit lore loaded from client resources.",
                )
            ),
        )
        val fallbackSign = IlzpaakSignProfile(
            month = 0,
            elven = "Snow's Maiden",
            orcish = "Daumanlob",
            spirit = "Urin",
            spiritDomain = "Weather",
            constellationShape = "The Claw of a Raven",
            symbol = "claw",
            general = "Fallback Ilzpaak data.",
            yellowReading = "Fallback Yellow path reading.",
            redReading = "Fallback Red path reading.",
            bothReading = "Fallback Twin Sands reading.",
            yellowNature = "Fallback nature.",
            redNature = "Fallback nature.",
            bothNature = "Fallback nature.",
            yellowTraits = listOf("Fallback"),
            redTraits = listOf("Fallback"),
            bothTraits = listOf("Fallback"),
            constellationNodes = listOf(IlzpaakConstellationNode(50f, 50f)),
            constellationEdges = emptyList(),
        )

        return LoadedData(
            constellations = if (constellations.isNotEmpty()) constellations else listOf(fallbackConstellation),
            ancestrals = ancestrals,
            ilzpaakMonths = if (months.isNotEmpty()) months else listOf(IlzpaakMonthInfo(0, "Snow's Maiden", "Daumanlob", "Wednesday")),
            ilzpaakSigns = if (signs.isNotEmpty()) signs else listOf(fallbackSign),
            sandNature = sandNature,
            anchorSaYear = anchorYear,
            anchorDate = anchorDate,
        )
    }

    private fun parseConstellation(obj: JsonObject): SpiritRealmConstellation {
        val stars = obj.getAsJsonArray("stars")
            ?.mapNotNull { it.asJsonObjectOrNull() }
            ?.map { parseStar(it) }
            .orEmpty()
        return SpiritRealmConstellation(
            id = obj.optString("id", ""),
            name = obj.optString("name", "Unknown"),
            tier = normalizeTier(obj.optString("tier", "greater")),
            color = obj.optString("color", "#ffffff"),
            stars = stars,
        )
    }

    private fun parseStar(obj: JsonObject): SpiritRealmStar = SpiritRealmStar(
        name = obj.optString("name", "Unknown"),
        domain = obj.optString("domain", ""),
        tier = normalizeTier(obj.optString("tier", "greater")),
        description = obj.optString("description", ""),
    )

    private fun parseSign(obj: JsonObject): IlzpaakSignProfile {
        val constellationObj = obj.getAsJsonObject("constellation")
        val nodes = constellationObj?.getAsJsonArray("stars")
            ?.mapNotNull { it.asJsonObjectOrNull() }
            ?.map { IlzpaakConstellationNode(it.optFloat("x", 50f), it.optFloat("y", 50f)) }
            .orEmpty()
        val edges = constellationObj?.getAsJsonArray("lines")
            ?.mapNotNull { line ->
                val arr = line.takeIf { it.isJsonArray }?.asJsonArray ?: return@mapNotNull null
                if (arr.size() < 2) return@mapNotNull null
                IlzpaakConstellationEdge(arr[0].asInt, arr[1].asInt)
            }
            .orEmpty()

        return IlzpaakSignProfile(
            month = obj.optInt("month", 0).coerceIn(0, 6),
            elven = obj.optString("elven", "Unknown"),
            orcish = obj.optString("orcish", "Unknown"),
            spirit = obj.optString("spirit", "Unknown"),
            spiritDomain = obj.optString("spirit_domain", ""),
            constellationShape = obj.optString("constellation_shape", ""),
            symbol = obj.optString("symbol", ""),
            general = obj.optString("general", ""),
            yellowReading = obj.optString("yellow", ""),
            redReading = obj.optString("red", ""),
            bothReading = obj.optString("both", ""),
            yellowNature = obj.optString("yellow_nature", ""),
            redNature = obj.optString("red_nature", ""),
            bothNature = obj.optString("both_nature", ""),
            yellowTraits = obj.getAsJsonArray("yellow_traits")?.mapNotNull { it.asStringOrNull() }.orEmpty(),
            redTraits = obj.getAsJsonArray("red_traits")?.mapNotNull { it.asStringOrNull() }.orEmpty(),
            bothTraits = obj.getAsJsonArray("both_traits")?.mapNotNull { it.asStringOrNull() }.orEmpty(),
            constellationNodes = nodes,
            constellationEdges = edges,
        )
    }

    private fun readResourceJson(path: String): JsonObject? {
        val stream = SpiritRealmLoreRepository::class.java.getResourceAsStream(path) ?: return null
        return stream.bufferedReader(Charsets.UTF_8).use { reader ->
            JsonParser.parseReader(reader).takeIf { it.isJsonObject }?.asJsonObject
        }
    }

    private fun JsonObject.optString(key: String, fallback: String = ""): String {
        val value = get(key) ?: return fallback
        if (value.isJsonNull) return fallback
        return runCatching { value.asString }.getOrDefault(fallback)
    }

    private fun JsonObject.optInt(key: String, fallback: Int = 0): Int {
        val value = get(key) ?: return fallback
        if (value.isJsonNull) return fallback
        return runCatching { value.asInt }.getOrDefault(fallback)
    }

    private fun JsonObject.optFloat(key: String, fallback: Float = 0f): Float {
        val value = get(key) ?: return fallback
        if (value.isJsonNull) return fallback
        return runCatching { value.asFloat }.getOrDefault(fallback)
    }

    private fun JsonObject.getAsJsonArray(key: String): JsonArray? = get(key)?.takeIf { it.isJsonArray }?.asJsonArray

    private fun JsonObject.getAsJsonObject(key: String): JsonObject? = get(key)?.takeIf { it.isJsonObject }?.asJsonObject

    private fun com.google.gson.JsonElement.asJsonObjectOrNull(): JsonObject? = takeIf { it.isJsonObject }?.asJsonObject

    private fun com.google.gson.JsonElement.asStringOrNull(): String? = runCatching { asString }.getOrNull()
}
