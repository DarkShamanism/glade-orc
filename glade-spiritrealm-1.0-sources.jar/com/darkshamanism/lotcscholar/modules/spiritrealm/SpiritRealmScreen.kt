﻿package com.darkshamanism.lotcscholar.modules.spiritrealm

import com.darkshamanism.lotcscholar.core.ClientContext
import com.darkshamanism.lotcscholar.services.SpiritRealmConstellation
import com.darkshamanism.lotcscholar.services.SpiritRealmPayload
import com.darkshamanism.lotcscholar.services.SpiritRealmStar
import com.darkshamanism.lotcscholar.ui.components.ParchmentTheme
import com.darkshamanism.lotcscholar.ui.components.wrapPlain
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import net.minecraft.client.gui.DrawContext
import net.minecraft.client.gui.screen.Screen
import net.minecraft.client.util.InputUtil
import net.minecraft.client.gui.widget.TextFieldWidget
import net.minecraft.text.Text
import org.lwjgl.glfw.GLFW

class SpiritRealmScreen(
    private val parent: Screen?,
    private val ctx: ClientContext,
    private val module: SpiritRealmModule,
    private val startInIlzpaak: Boolean = false,
) : com.darkshamanism.lotcscholar.ui.compat.LegacyScreen(Text.literal("Spirit Realm")) {

    private data class StarPoint(
        val key: String,
        val constellation: SpiritRealmConstellation,
        val star: SpiritRealmStar,
        val x: Int,
        val y: Int,
        val radius: Int,
        val color: Int,
    )

    private data class TierPill(
        val id: String,
        val x: Int,
        val y: Int,
        val w: Int,
        val h: Int,
    )

    private data class StarListHitbox(
        val key: String,
        val x: Int,
        val y: Int,
        val w: Int,
        val h: Int,
    )

    private data class PlotRect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val width: Int get() = right - left
        val height: Int get() = bottom - top
    }

    private data class MapRawBounds(
        val minX: Float,
        val maxX: Float,
        val minY: Float,
        val maxY: Float,
    )

    private data class UiRect(
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int,
    ) {
        fun contains(x: Int, y: Int): Boolean = x in left..right && y in top..bottom
    }

    private data class DriftStar(
        var x: Float,
        var y: Float,
        val vx: Float,
        val vy: Float,
        val twinkle: Float,
        val warmBias: Float,
        val size: Int,
    )

    private data class SkySignHitbox(val x: Int, val y: Int, val signIndex: Int)

    private data class SkyNodeHitbox(
        val x: Int,
        val y: Int,
        val signIndex: Int,
        val nodeIndex: Int,
        val star: SpiritRealmStar,
    )

    private enum class DisplayMode {
        REALM_MAP,
        ILZPAAK_SKYVIEW,
    }

    private val driftingStars = MutableList(260) { i ->
        val angle = (unitNoise("sky_a_$i") * (PI * 2f).toFloat())
        val speed = 0.010f + (unitNoise("sky_s_$i") * 0.040f)
        DriftStar(
            x = unitNoise("sky_x_$i"),
            y = unitNoise("sky_y_$i"),
            vx = cos(angle) * speed,
            vy = sin(angle) * speed,
            twinkle = 0.6f + unitNoise("sky_t_$i"),
            warmBias = unitNoise("sky_w_$i"),
            size = if (unitNoise("sky_z_$i") > 0.82f) 2 else 1,
        )
    }
    private var lastSkyDriftMs = System.currentTimeMillis()

    private val ilzpaakSigns = SpiritRealmLoreRepository.ilzpaakSigns()
    private val spiritConstellations = SpiritRealmLoreRepository.constellations()
    private val ancestralPool = SpiritRealmLoreRepository.ancestralStars().ifEmpty {
        listOf(SpiritRealmStar("Unknown Ancestral", "", "lesser", "No ancestral lore available."))
    }
    private val skySpiritAssignments = buildSkySpiritAssignments()
    private val mapInfoPanelHeight = 58
    private val mapInfoPanelGap = 4

    private var openedAtMs = System.currentTimeMillis()

    // Typewriter reveal for the Ilzpaak hover lore body and the star inspect line.
    private var ilzpaakLoreRevealedText: String = ""
    private var ilzpaakLoreRevealStartedAt: Long = 0L
    private var ilzpaakLoreCachedFor: String = ""
    private var ilzpaakLoreCachedWidth: Int = -1
    private var ilzpaakLoreCachedWrapped: List<String> = emptyList()
    private var ilzpaakLorePanelLeft: Int = 0
    private var ilzpaakLorePanelTop: Int = 0
    private var ilzpaakLorePanelRight: Int = 0
    private var ilzpaakLorePanelBottom: Int = 0

    private var starDomainRevealedText: String = ""
    private var starDomainRevealStartedAt: Long = 0L

    private fun startIlzpaakLoreReveal(fullText: String) {
        if (fullText == ilzpaakLoreRevealedText) return
        ilzpaakLoreRevealedText = fullText
        ilzpaakLoreRevealStartedAt =
            if (ctx.config.current.ui.reducedMotion) 0L else System.currentTimeMillis()
        ilzpaakLoreCachedFor = ""
    }

    private fun visibleIlzpaakLore(): String {
        if (ilzpaakLoreRevealStartedAt == 0L) return ilzpaakLoreRevealedText
        val charsPerSecond = 60L
        val elapsed = System.currentTimeMillis() - ilzpaakLoreRevealStartedAt
        val visible = (elapsed * charsPerSecond / 1000L).toInt().coerceAtMost(ilzpaakLoreRevealedText.length)
        return if (visible >= ilzpaakLoreRevealedText.length) ilzpaakLoreRevealedText
        else ilzpaakLoreRevealedText.substring(0, visible)
    }

    private fun isIlzpaakLoreRevealActive(): Boolean =
        ilzpaakLoreRevealStartedAt != 0L &&
            visibleIlzpaakLore().length < ilzpaakLoreRevealedText.length

    private fun completeIlzpaakLoreRevealNow() {
        if (ilzpaakLoreRevealStartedAt != 0L) {
            ilzpaakLoreRevealStartedAt = System.currentTimeMillis() - 99_999L
        }
    }

    private fun isPointInIlzpaakLorePanel(mx: Int, my: Int): Boolean =
        mx in ilzpaakLorePanelLeft..ilzpaakLorePanelRight &&
            my in ilzpaakLorePanelTop..ilzpaakLorePanelBottom

    private fun startStarDomainReveal(fullText: String) {
        if (fullText == starDomainRevealedText) return
        starDomainRevealedText = fullText
        starDomainRevealStartedAt =
            if (ctx.config.current.ui.reducedMotion) 0L else System.currentTimeMillis()
    }

    private fun visibleStarDomain(): String {
        if (starDomainRevealStartedAt == 0L) return starDomainRevealedText
        val charsPerSecond = 60L
        val elapsed = System.currentTimeMillis() - starDomainRevealStartedAt
        val visible = (elapsed * charsPerSecond / 1000L).toInt().coerceAtMost(starDomainRevealedText.length)
        return if (visible >= starDomainRevealedText.length) starDomainRevealedText
        else starDomainRevealedText.substring(0, visible)
    }

    private var tierFilter = "all"
    private var selectedKey = ""
    private var hoveredKey = ""
    private var stars: List<StarPoint> = emptyList()
    private var tierPills: List<TierPill> = emptyList()
    private var starListHitboxes: List<StarListHitbox> = emptyList()
    private var lastAutoRefreshAtMs = 0L

    private var displayMode = if (startInIlzpaak) DisplayMode.ILZPAAK_SKYVIEW else DisplayMode.REALM_MAP
    private var highlightedIlzpaak = SpiritRealmLoreRepository.currentTimeConversion().monthIdx
    private var skySignHitboxes: List<SkySignHitbox> = emptyList()
    private var skyNodeHitboxes: List<SkyNodeHitbox> = emptyList()
    private var selectedSkyNode: SkyNodeHitbox? = null
    private var hoveredSkyNode: SkyNodeHitbox? = null

    private var divinationMonthIdx = highlightedIlzpaak
    private var divinationCalendar = "SA"
    private var divinationYear: Int? = SpiritRealmLoreRepository.currentTimeConversion().saYear
    private var divinationDay: Int = SpiritRealmLoreRepository.currentTimeConversion().dayOfMonth
    private var divinationSand: IlzpaakSandPath =
        SpiritRealmLoreRepository.guessSandPath(SpiritRealmLoreRepository.currentTimeConversion())
    private var divinationResult: IlzpaakDivinationResult? = null
    private var showDivinationPanel = false
    private var divinationPanelProgress = 0f
    private lateinit var divinationNameField: TextFieldWidget
    private var realmMapPlot: PlotRect? = null
    private var mapPanX = 0f
    private var mapPanY = 0f
    private var mapZoom = 1.18f
    private val minMapZoom = 0.36f
    private val maxMapZoom = 2.8f
    private var draggingMap = false
    private var mapRawBounds: MapRawBounds? = null
    private var focusedIlzpaakSign: Int? = null
    private var focusedIlzpaakProgress = 0f
    private var focusedIlzpaakTarget = 0f
    private var hoveredIlzpaakSign: Int? = null
    private var hoveredIlzpaakX = 0
    private var hoveredIlzpaakY = 0
    private var skyNodeInfoRect: UiRect? = null
    private var skyNodeInfoScroll = 0f
    private var skyNodeInfoMaxScroll = 0f
    private var skyNodeInfoKey = ""

    override fun init() {
        clearChildren()
        divinationNameField = TextFieldWidget(textRenderer, 22, 194, 176, 14, Text.literal("Name")).also {
            it.setMaxLength(40)
            it.setText("Unknown Kub")
            it.setPlaceholder(Text.literal("Kub name for divination"))
            it.visible = displayMode == DisplayMode.ILZPAAK_SKYVIEW && showDivinationPanel
            addDrawableChild(it)
        }
        module.requestRefresh(force = true, notifyOnFail = false)
        syncDivinationDefaults(module.snapshot())
    }

    fun openIlzpaakMode() {
        displayMode = DisplayMode.ILZPAAK_SKYVIEW
        showDivinationPanel = false
        selectedSkyNode = null
        hoveredSkyNode = null
        draggingMap = false
        val inferred = inferIlzpaakFromPayload(module.snapshot())
        if (inferred >= 0) {
            highlightedIlzpaak = inferred
            divinationMonthIdx = inferred
        }
        syncDivinationDefaults(module.snapshot())
    }

    private fun openRealmMapMode() {
        displayMode = DisplayMode.REALM_MAP
        showDivinationPanel = false
        selectedSkyNode = null
        hoveredSkyNode = null
        focusedIlzpaakSign = null
        focusedIlzpaakProgress = 0f
        focusedIlzpaakTarget = 0f
        showDivinationPanel = false
        divinationPanelProgress = 0f
        if (::divinationNameField.isInitialized) {
            divinationNameField.setFocused(false)
        }
    }

    override fun renderBackground(context: DrawContext, mouseX: Int, mouseY: Int, delta: Float) {}

    override fun render(dc: DrawContext, mx: Int, my: Int, delta: Float) {
        val payload = module.snapshot()
        maybeAutoRefresh(payload)
        updateDivinationPanelAnimation()
        if (::divinationNameField.isInitialized) {
            divinationNameField.visible = displayMode == DisplayMode.ILZPAAK_SKYVIEW && divinationPanelProgress > 0.06f
        }

        if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
            realmMapPlot = null
            tierPills = emptyList()
            starListHitboxes = emptyList()
            renderIlzpaakSkyview(dc, payload, mx, my)
            renderFooter(dc, payload)
        } else {
            skySignHitboxes = emptyList()
            skyNodeHitboxes = emptyList()
            renderSkyBackdrop(dc)
            renderHeader(dc, payload)
            val plot = PlotRect(16, 44, width - 16, height - mapInfoPanelHeight - mapInfoPanelGap)
            realmMapPlot = plot
            renderTierPills(dc, plot, mx, my)

            if (payload == null) {
                dc.drawCenteredTextWithShadow(
                    textRenderer,
                    Text.literal(if (module.isRefreshing()) "Syncing Spirit Realm data..." else "Loading local Spirit Index data..."),
                    width / 2,
                    height / 2,
                    ParchmentTheme.TEXT_LIGHT,
                )
                renderFooter(dc, null)
            } else {
                if (selectedKey.isBlank()) {
                    val first = payload.constellations.firstOrNull { it.stars.isNotEmpty() }?.let { c ->
                        c.stars.firstOrNull()?.let { s -> "${c.id}:${s.name}" }
                    }
                    if (first != null) selectedKey = first
                }

                stars = buildStars(payload, plot)
                if (clampMapPan(plot)) {
                    stars = buildStars(payload, plot)
                }
                hoveredKey = findHovered(mx, my)?.key ?: ""
                dc.enableScissor(plot.left + 1, plot.top + 22, plot.right - 1, plot.bottom - 1)
                renderConstellations(dc, stars)
                dc.disableScissor()
                renderSelectedPanel(dc, payload, mx, my)
                renderFooter(dc, payload)
            }
        }

        super.render(dc, mx, my, delta)
        if (!ctx.config.current.ui.reducedMotion) drawOpenFadeWash(dc)
    }

    private fun renderSkyBackdrop(dc: DrawContext) {
        stepDriftingSky()
        val topRgb = 0x08162E
        val midRgb = 0x1A3F7A
        val bottomRgb = 0x090F22
        for (row in 0 until height step 2) {
            val t = row.toFloat() / (height - 1).coerceAtLeast(1).toFloat()
            val rise = if (t < 0.56f) (t / 0.56f) else (1f - ((t - 0.56f) / 0.44f)).coerceAtLeast(0f)
            val wave = (((sin((t * PI * 1.75) - 0.7) + 1.0) * 0.5).toFloat() * 0.35f)
            val blend = (rise * 0.65f + wave).coerceIn(0f, 1f)
            val upper = mixColor(topRgb, midRgb, blend)
            val rgb = mixColor(upper, bottomRgb, (t * t * 0.58f).coerceIn(0f, 1f))
            dc.fill(0, row, width, min(height, row + 2), argb(255, rgb))
        }
        dc.fill(0, 0, width, height, argb(72, 0x183667))
        dc.fill(0, (height * 0.24f).toInt(), width, (height * 0.84f).toInt(), argb(56, 0x2E5C96))
        renderDriftingStars(dc, coolRgb = 0xAFC9FF, warmRgb = 0xBBD4FF, alphaBase = 132, alphaRange = 74)
    }

    private fun renderHeader(dc: DrawContext, payload: SpiritRealmPayload?) {
        dc.fill(0, 0, width, 42, 0xA0101018.toInt())
        dc.drawStrokedRectangle(0, 0, width, 42, 0xFF3E4A73.toInt())
        if (payload == null) {
            dc.drawTextWithShadow(textRenderer, Text.literal(if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) "Ilzpaak" else "Spirit Realm"), 16, 13, 0xFFA9C8FF.toInt())
            return
        }
        val clock = payload.clock
        val conv = SpiritRealmLoreRepository.conversionFromClock(clock)
        val titleBase = if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) "Ilzpaak" else "Spirit Realm"
        val title = textRenderer.trimToWidth(titleBase, width - 32)
        val date = textRenderer.trimToWidth("SA ${conv.saYear} / FA ${conv.faYear} - ${conv.monthOrcish} Day ${conv.dayOfMonth}", width - 32)
        val sign = textRenderer.trimToWidth("Current sign: ${payload.currentSign.name} - ${payload.currentSign.domain}", width - 32)
        dc.drawTextWithShadow(textRenderer, Text.literal(title), 16, 5, 0xFFA9C8FF.toInt())
        dc.drawTextWithShadow(textRenderer, Text.literal(date), 16, 17, 0xFFD6C589.toInt())
        dc.drawTextWithShadow(textRenderer, Text.literal(sign), 16, 29, 0xFF9FAED1.toInt())
    }

    private fun renderTierPills(dc: DrawContext, plot: PlotRect, mx: Int, my: Int) {
        val pills = listOf(
            "all" to "All",
            "greater" to "Greater",
            "lesser" to "Lesser",
            "dishonored" to "Dishonored",
        )
        var x = plot.left + 8
        val y = plot.top + 6
        tierPills = pills.map { (id, label) ->
            val w = textRenderer.getWidth(label) + 16
            val hovered = mx in x until (x + w) && my in y until (y + 14)
            val selected = tierFilter == id
            dc.fill(
                x, y, x + w, y + 14,
                when {
                    selected -> 0x664578B8
                    hovered -> 0x4438465E
                    else -> 0x330E182B
                },
            )
            dc.drawStrokedRectangle(x, y, w, 14, if (selected) 0xFF7AB9FF.toInt() else 0xFF355173.toInt())
            dc.drawCenteredTextWithShadow(textRenderer, Text.literal(label), x + (w / 2), y + 3, 0xFFD5E6FF.toInt())
            val pill = TierPill(id, x, y, w, 14)
            x += w + 6
            pill
        }
    }

    private fun renderConstellations(dc: DrawContext, points: List<StarPoint>) {
        for (constellation in points.groupBy { it.constellation.id }.values) {
            for (i in 0 until constellation.lastIndex) {
                drawLine(dc, constellation[i], constellation[i + 1], 0x66B6CCFF)
            }
        }
        for (point in points) {
            val hovered = point.key == hoveredKey
            val selected = point.key == selectedKey
            val radius = when {
                selected -> point.radius + 2
                hovered -> point.radius + 1
                else -> point.radius
            }
            drawStar(dc, point.x, point.y, radius, point.color)
        }
    }

    private fun renderSelectedPanel(dc: DrawContext, payload: SpiritRealmPayload, mx: Int, my: Int) {
        val selected = stars.firstOrNull { it.key == selectedKey } ?: stars.firstOrNull { it.key == hoveredKey }
        val panelHeight = mapInfoPanelHeight
        val panelTop = height - panelHeight
        dc.fill(0, panelTop, width, height, 0xBA0A0D17.toInt())
        dc.drawStrokedRectangle(0, panelTop, width, panelHeight, 0xFF33466B.toInt())
        starListHitboxes = emptyList()

        if (selected == null) {
            dc.drawTextWithShadow(textRenderer, Text.literal("Select a star to inspect its lore."), 16, panelTop + 12, 0xFFBBC8E0.toInt())
            return
        }

        val star = selected.star
        val constellation = selected.constellation
        val listLeft = (width * 0.61f).toInt().coerceAtLeast(320)
        val domainLine = "${constellation.name} - ${if (star.domain.isBlank()) "No domain" else star.domain}"
        startStarDomainReveal(domainLine)
        dc.drawTextWithShadow(textRenderer, Text.literal("${star.name}  [${star.tier}]"), 16, panelTop + 8, tierColor(star.tier))
        dc.drawTextWithShadow(
            textRenderer,
            Text.literal(visibleStarDomain()),
            16,
            panelTop + 20,
            0xFFB4C2DD.toInt(),
        )

        val totalSpirits = payload.constellations.sumOf { it.stars.size }
        dc.drawTextWithShadow(
            textRenderer,
            Text.literal("Spirit index: $totalSpirits stars"),
            16,
            panelTop + 34,
            0xFF6E84AE.toInt(),
        )

        dc.drawTextWithShadow(
            textRenderer,
            Text.literal("Constellation Stars (${constellation.stars.size})"),
            listLeft,
            panelTop + 8,
            0xFFD9C79D.toInt(),
        )

        val hitboxes = mutableListOf<StarListHitbox>()
        var rowTop = panelTop + 22
        val maxRows = 3
        for (entry in constellation.stars.take(maxRows)) {
            val rowKey = "${constellation.id}:${entry.name}"
            val selectedRow = rowKey == selectedKey
            val hoveredRow = mx in listLeft..(width - 18) && my in rowTop..(rowTop + 12)
            if (selectedRow || hoveredRow) {
                dc.fill(
                    listLeft - 4,
                    rowTop - 1,
                    width - 14,
                    rowTop + 11,
                    if (selectedRow) 0x553A5E8A else 0x3334445B,
                )
            }
            val marker = if (selectedRow) ">" else "-"
            val label = "$marker ${entry.name} [${normalizeTier(entry.tier)}]"
            dc.drawTextWithShadow(textRenderer, Text.literal(label), listLeft, rowTop, tierColor(entry.tier))
            hitboxes += StarListHitbox(rowKey, listLeft - 4, rowTop - 1, (width - 14) - (listLeft - 4), 12)
            rowTop += 14
        }
        if (constellation.stars.size > maxRows) {
            dc.drawTextWithShadow(
                textRenderer,
                Text.literal("+${constellation.stars.size - maxRows} more"),
                listLeft,
                rowTop + 2,
                0xFF8FA2C8.toInt(),
            )
        }
        starListHitboxes = hitboxes
    }

    private fun renderFooter(dc: DrawContext, payload: SpiritRealmPayload?) {}

    private fun renderIlzpaakSkyview(dc: DrawContext, payload: SpiritRealmPayload?, mx: Int, my: Int) {
        updateIlzpaakFocusAnimation()
        stepDriftingSky()
        dc.fill(0, 0, width, height, 0xFF12050B.toInt())
        dc.fill(0, 0, width, height, 0x7F2C0A16)
        dc.fill(0, 0, width, (height * 0.72f).toInt(), 0x55381422)
        renderDriftingStars(dc, coolRgb = 0xE4B0B7, warmRgb = 0xFBC198, alphaBase = 152, alphaRange = 82)

        val centerX = width / 2f
        val centerY = height * 0.53f
        val radiusX = width * 0.35f
        val radiusY = height * 0.25f
        val rotation = ((System.currentTimeMillis() - openedAtMs) / 62_000.0) * (PI * 2.0)
        val focusedSign = focusedIlzpaakSign

        val signHits = mutableListOf<SkySignHitbox>()
        val nodeHits = mutableListOf<SkyNodeHitbox>()
        hoveredIlzpaakSign = null
        hoveredSkyNode = null
        var hoveredNodeDistSq = Float.MAX_VALUE

        for ((index, sign) in ilzpaakSigns.withIndex()) {
            val angle = rotation + ((PI * 2.0) * index / ilzpaakSigns.size) - (PI / 2.0)
            val cx = centerX + cos(angle).toFloat() * radiusX
            val cy = centerY + sin(angle).toFloat() * radiusY
            val isFocused = focusedSign == index
            val selected = index == highlightedIlzpaak
            val hoveredSign = (mx - cx).toInt() * (mx - cx).toInt() + (my - cy).toInt() * (my - cy).toInt() <= 74 * 74
            if (hoveredSign && (focusedSign == null || isFocused || focusedIlzpaakProgress < 0.1f)) {
                highlightedIlzpaak = index
                divinationMonthIdx = index
                hoveredIlzpaakSign = index
                hoveredIlzpaakX = cx.roundToInt()
                hoveredIlzpaakY = cy.roundToInt()
            }

            val visibility = when {
                focusedSign == null -> 1f
                isFocused -> 1f
                else -> (1f - focusedIlzpaakProgress).coerceAtLeast(0.14f)
            }
            val baseScale = 0.56f + if (selected) 0.18f else if (hoveredSign) 0.10f else 0f
            val focusScale = 2.35f
            val focusCenterX = width * 0.5f
            val focusCenterY = height * 0.56f
            val assignedStars = skySpiritAssignments.getOrElse(index) { emptyList() }
            val nodePositions = MutableList(sign.constellationNodes.size) { Pair(0f, 0f) }

            for ((nodeIndex, node) in sign.constellationNodes.withIndex()) {
                val orbitX = cx + (node.x - 50f) * baseScale
                val orbitY = cy + (node.y - 50f) * baseScale
                val focusX = focusCenterX + (node.x - 50f) * focusScale
                val focusY = focusCenterY + (node.y - 50f) * focusScale
                val stagger = (nodeIndex.toFloat() / sign.constellationNodes.size.coerceAtLeast(1)) * 0.28f
                val nodeBlendRaw = ((focusedIlzpaakProgress - stagger) / (1f - stagger).coerceAtLeast(0.25f)).coerceIn(0f, 1f)
                val nodeBlend = nodeBlendRaw * nodeBlendRaw * (3f - (2f * nodeBlendRaw))
                val blend = if (isFocused) nodeBlend else 0f
                val fx = lerp(orbitX, focusX, blend)
                val fy = lerp(orbitY, focusY, blend)
                nodePositions[nodeIndex] = Pair(fx, fy)
            }

            for (edge in sign.constellationEdges) {
                val a = sign.constellationNodes[edge.a]
                val b = sign.constellationNodes[edge.b]
                val ap = nodePositions[edge.a]
                val bp = nodePositions[edge.b]
                val lineAlpha = (visibility * if (selected || isFocused) 255 else 190).roundToInt().coerceIn(18, 255)
                val lineColor = argb(lineAlpha, if (selected || isFocused) 0xFFE4A8 else 0xC8922A)
                drawPrimitiveLine(dc, ap.first, ap.second, bp.first, bp.second, lineColor, if (selected || isFocused) 2 else 1)
            }

            for ((nodeIndex, node) in sign.constellationNodes.withIndex()) {
                val pos = nodePositions[nodeIndex]
                val nx = pos.first.roundToInt()
                val ny = pos.second.roundToInt()
                val ancestral = assignedStars.getOrNull(nodeIndex)
                val dx = nx - mx
                val dy = ny - my
                val distSq = (dx * dx + dy * dy).toFloat()
                val nodeInteractionEnabled = focusedSign != null && isFocused && focusedIlzpaakProgress >= 0.28f
                val hoveredNode = nodeInteractionEnabled && distSq <= (15f * 15f)
                if (hoveredNode && ancestral != null && distSq < hoveredNodeDistSq) {
                    hoveredNodeDistSq = distSq
                    hoveredSkyNode = SkyNodeHitbox(nx, ny, index, nodeIndex, ancestral)
                }
                val selectedNode = selectedSkyNode?.let { it.signIndex == index && it.nodeIndex == nodeIndex } == true
                val activeNode = nodeInteractionEnabled && (selectedNode || hoveredNode)
                val size = when {
                    activeNode -> 4
                    selected && (nodeIndex == 0 || nodeIndex == sign.constellationNodes.lastIndex) -> 3
                    else -> 2
                }
                val coreAlpha = (visibility * if (selected || isFocused || hoveredNode) 255 else 220).roundToInt().coerceIn(30, 255)
                val glowAlpha = (visibility * if (selected || isFocused || hoveredNode) 220 else 130).roundToInt().coerceIn(24, 230)
                val starCoreColor = argb(coreAlpha, 0xFFF6DA)
                val starGlowColor = argb(glowAlpha, if (hoveredNode) 0xFFEAA6 else 0xFFD470)
                dc.fill(nx - size - 1, ny - size - 1, nx + size + 2, ny + size + 2, starGlowColor)
                dc.fill(nx - size, ny - size, nx + size + 1, ny + size + 1, starCoreColor)
                if (ancestral != null && nodeInteractionEnabled) {
                    nodeHits += SkyNodeHitbox(nx, ny, index, nodeIndex, ancestral)
                }
            }

            val label = sign.orcish
            val labelAnchor = if (isFocused && focusedIlzpaakProgress > 0f) {
                val count = nodePositions.size.coerceAtLeast(1)
                val avgX = nodePositions.sumOf { it.first.toDouble() }.toFloat() / count
                val avgY = nodePositions.sumOf { it.second.toDouble() }.toFloat() / count
                Pair(avgX, avgY + 26f)
            } else {
                Pair(cx, cy + 44f * baseScale)
            }
            val lx = labelAnchor.first.roundToInt() - textRenderer.getWidth(label) / 2
            val ly = labelAnchor.second.roundToInt()
            val labelColor = argb(
                (visibility * if (selected || isFocused) 255 else 170).roundToInt().coerceIn(24, 255),
                if (selected || isFocused) 0xF0D8A0 else 0xAA8E58,
            )
            dc.drawTextWithShadow(textRenderer, Text.literal(label), lx, ly, labelColor)

            val hitCenter = if (isFocused && focusedIlzpaakProgress > 0.05f) {
                nodePositions.firstOrNull() ?: Pair(cx, cy)
            } else {
                Pair(cx, cy)
            }
            signHits += SkySignHitbox(hitCenter.first.roundToInt(), hitCenter.second.roundToInt(), index)
        }

        skySignHitboxes = signHits
        skyNodeHitboxes = nodeHits
        hoveredSkyNode?.let {
            highlightedIlzpaak = it.signIndex
            divinationMonthIdx = it.signIndex
        }

        renderHeader(dc, payload)
        val active = ilzpaakSigns[highlightedIlzpaak.coerceIn(0, ilzpaakSigns.lastIndex)]
        dc.drawCenteredTextWithShadow(
            textRenderer,
            Text.literal("${active.orcish} | ${active.elven} | ${active.constellationShape}"),
            width / 2,
            48,
            0xFFC9B07A.toInt(),
        )
        dc.drawCenteredTextWithShadow(
            textRenderer,
            Text.literal("Spirit: ${active.spirit} | Click sign to focus, then stars for spirits | V divination | K Spirit Realm"),
            width / 2,
            height - 24,
            0xFFA88D58.toInt(),
        )
        if (focusedSign != null && focusedIlzpaakProgress > 0.1f) {
            dc.drawCenteredTextWithShadow(
                textRenderer,
                Text.literal("Focused constellation. Right-click anywhere to return."),
                width / 2,
                height - 36,
                0xFFD6C89A.toInt(),
            )
        }
        val renderedFocusedLore = renderFocusedIlzpaakLore(dc)
        if (!renderedFocusedLore && hoveredSkyNode == null && selectedSkyNode == null) {
            renderHoveredIlzpaakLore(dc, mx, my)
        }
        renderSkyNodeInfo(dc)
        if (divinationPanelProgress > 0.01f) {
            renderDivinationInfo(dc, payload)
        }
    }

    private fun renderSkyNodeInfo(dc: DrawContext) {
        val selected = hoveredSkyNode ?: selectedSkyNode ?: run {
            skyNodeInfoRect = null
            skyNodeInfoMaxScroll = 0f
            skyNodeInfoScroll = 0f
            skyNodeInfoKey = ""
            return
        }
        val star = selected.star
        val subtitle = star.domain.ifBlank { "No title listed" }
        val activeSign = ilzpaakSigns.getOrNull(selected.signIndex)
        val signLine = activeSign?.let { "Sign: ${it.orcish}" } ?: ""
        val maxPanelW = min(348, width - 24)
        val desiredW = max(
            200,
            max(
                textRenderer.getWidth("${star.name} [${star.tier}]") + 16,
                max(textRenderer.getWidth(subtitle) + 16, textRenderer.getWidth(signLine) + 16),
            ),
        )
        val panelW = desiredW.coerceIn(188, maxPanelW)
        val bodyWidth = panelW - 12
        val nameLines = textRenderer.wrapPlain("${star.name} [${star.tier}]", bodyWidth).take(2)
        val subtitleLines = textRenderer.wrapPlain(subtitle, bodyWidth).take(2)
        val signLines = if (signLine.isBlank()) emptyList() else textRenderer.wrapPlain(signLine, bodyWidth).take(1)
        val lineCount = (nameLines.size + subtitleLines.size + signLines.size).coerceAtLeast(2)
        val panelH = (22 + (lineCount * 10) + 8).coerceIn(66, (height / 2).coerceAtLeast(76))
        val rect = chooseCornerPanelRect(selected.x, selected.y, panelW, panelH)
        val left = rect.left
        val top = rect.top
        val right = rect.right
        val bottom = rect.bottom
        skyNodeInfoRect = UiRect(left, top, right, bottom)
        dc.fill(left, top, right, bottom, 0xC0130E1C.toInt())
        dc.drawStrokedRectangle(left, top, right - left, bottom - top, 0xFF5D4A2A.toInt())
        dc.drawTextWithShadow(textRenderer, Text.literal("Constellation Spirit"), left + 6, top + 8, 0xFFE2C88D.toInt())
        var y = top + 20
        for (line in nameLines) {
            dc.drawTextWithShadow(textRenderer, Text.literal(line), left + 6, y, tierColor(star.tier))
            y += 10
        }
        for (line in subtitleLines) {
            dc.drawTextWithShadow(textRenderer, Text.literal(line), left + 6, y, 0xFFC8B08A.toInt())
            y += 10
        }
        for (line in signLines) {
            dc.drawTextWithShadow(textRenderer, Text.literal(line), left + 6, y, 0xFFB49A70.toInt())
            y += 10
        }
        skyNodeInfoKey = "${selected.signIndex}:${selected.nodeIndex}:${star.name}"
        skyNodeInfoScroll = 0f
        skyNodeInfoMaxScroll = 0f
    }

    private fun renderDivinationInfo(dc: DrawContext, payload: SpiritRealmPayload?) {
        val progress = divinationPanelProgress.coerceIn(0f, 1f)
        if (progress <= 0.001f) return
        val conversion = SpiritRealmLoreRepository.conversionFromClock(payload?.clock)
        val panelW = min(360, width - 40)
        val panelH = min(288, height - 120)
        val slide = ((1f - progress) * 26f).roundToInt()
        val right = width - 16 + slide
        val left = right - panelW
        val top = 56
        val bottom = top + panelH
        dc.fill(left, top, right, bottom, argb((200f * progress).roundToInt(), 0x0F0E18))
        dc.drawStrokedRectangle(left, top, right - left, bottom - top, argb((255f * progress).roundToInt(), 0x4A3D2A))
        var y = top + 8
        fun drawLine(text: String, color: Int) {
            if (y <= bottom - 16) {
                dc.drawTextWithShadow(textRenderer, Text.literal(text), left + 8, y, color)
                y += 10
            }
        }

        drawLine("Divination", 0xFFE7CB90.toInt())
        val sign = ilzpaakSigns.getOrNull(divinationMonthIdx)
        drawLine("Date: SA ${conversion.saYear} / FA ${conversion.faYear} - ${conversion.monthOrcish} Day ${conversion.dayOfMonth}", 0xFFD2B980.toInt())
        drawLine("Birth: ${sign?.orcish ?: "?"} Day $divinationDay  |  $divinationCalendar ${divinationYear ?: "-"}", 0xFFD7C59A.toInt())
        drawLine("Sand: ${divinationSand.label()}", 0xFFD7C59A.toInt())

        val nameLabelY = y + 2
        dc.drawTextWithShadow(textRenderer, Text.literal("Kub Name"), left + 8, nameLabelY, 0xFFC7B28A.toInt())
        val inputY = nameLabelY + 11
        divinationNameField.x = left + 8
        divinationNameField.y = inputY
        divinationNameField.width = (right - left - 16).coerceAtLeast(120)

        y = inputY + 18

        val result = divinationResult
        if (result != null) {
            y += 2
            drawLine("Result: ${result.sign.orcish} (${result.sign.spirit})", 0xFFE8D39E.toInt())
            drawLine(result.dateLabel, 0xFFC9B287.toInt())
            drawLine(result.ageNote, 0xFFB7A783.toInt())
            val readingTop = y + 2
            val readingBottom = bottom - 8
            dc.enableScissor(left + 8, readingTop, right - 8, readingBottom)
            var readingY = readingTop
            for (line in textRenderer.wrapPlain(result.reading, right - left - 16)) {
                if (readingY > readingBottom - 10) break
                dc.drawTextWithShadow(textRenderer, Text.literal(line), left + 8, readingY, 0xFFAFA4BB.toInt())
                readingY += 10
            }
            dc.disableScissor()
        }
    }

    private fun divinationPanelRect(): UiRect? {
        if (displayMode != DisplayMode.ILZPAAK_SKYVIEW) return null
        val progress = divinationPanelProgress.coerceIn(0f, 1f)
        if (!showDivinationPanel || progress <= 0.06f) return null
        val panelW = min(360, width - 40)
        val panelH = min(288, height - 120)
        val slide = ((1f - progress) * 26f).roundToInt()
        val right = width - 16 + slide
        val left = right - panelW
        val top = 56
        val bottom = top + panelH
        return UiRect(left, top, right, bottom)
    }

    private fun buildStars(payload: SpiritRealmPayload, plot: PlotRect): List<StarPoint> {
        val clusters = mutableListOf<ConstellationCluster>()
        for (constellation in expandRealmConstellations(payload.constellations)) {
            val filteredStars = constellation.stars.filter { tierFilter == "all" || normalizeTier(it.tier) == tierFilter }
            if (filteredStars.isEmpty()) continue
            val orderedStars = orderStarsForConstellation(constellation.id, filteredStars)
            val bucketTier = if (tierFilter == "all") normalizeTier(constellation.tier) else tierFilter
            val clusterRadius = when (bucketTier) {
                "greater" -> (20f + (orderedStars.size * 1.9f)).coerceIn(16f, 62f)
                "lesser" -> (16f + (orderedStars.size * 1.45f)).coerceIn(13f, 54f)
                else -> (18f + (orderedStars.size * 1.65f)).coerceIn(14f, 56f)
            }
            clusters += ConstellationCluster(
                constellation = constellation,
                stars = orderedStars,
                bucketTier = bucketTier,
                realmKey = realmKeyForConstellation(constellation.id),
                radius = clusterRadius,
                phase = unitNoise("cluster_phase_${constellation.id}") * (PI * 2f).toFloat(),
            )
        }
        if (clusters.isEmpty()) return emptyList()

        val grouped = clusters.groupBy { it.realmKey }
        val sectors = mapOf(
            "elemental" to realmSectorFor(plot, "elemental", grouped["elemental"]?.size ?: 0),
            "immortal" to realmSectorFor(plot, "immortal", grouped["immortal"]?.size ?: 0),
            "ancestral" to realmSectorFor(plot, "ancestral", grouped["ancestral"]?.size ?: 0),
            "unknown" to realmSectorFor(plot, "unknown", grouped["unknown"]?.size ?: 0),
        )
        for ((realm, entries) in grouped) {
            val orderedEntries = entries.sortedBy { it.constellation.id }
            val densityScale = clusterDensityScale(orderedEntries.size)
            for (cluster in orderedEntries) {
                cluster.radius = (cluster.radius * densityScale).coerceAtLeast(11f)
            }
            val sector = sectors[realm] ?: sectors.getValue("unknown")
            placeClustersInSector(orderedEntries, sector)
        }
        applyLoreAnchors(clusters, plot)

        val pan = min(1f, (System.currentTimeMillis() - openedAtMs) / 1200f)
        val panOffset = ((1f - pan) * plot.height * 0.30f).toInt()
        val plotCenterX = plot.left + (plot.width / 2f)
        val plotCenterY = plot.top + (plot.height / 2f)
        val out = mutableListOf<StarPoint>()
        var rawMinX = Float.POSITIVE_INFINITY
        var rawMaxX = Float.NEGATIVE_INFINITY
        var rawMinY = Float.POSITIVE_INFINITY
        var rawMaxY = Float.NEGATIVE_INFINITY

        for (cluster in clusters.sortedWith(compareBy({ it.realmKey }, { it.constellation.id }))) {
            val offsets = buildConstellationOffsets(cluster.constellation.id, cluster.stars.size)
            val color = parseHexColor(cluster.constellation.color, tierColor(cluster.bucketTier))
            for ((index, star) in cluster.stars.withIndex()) {
                val offset = offsets.getOrElse(index) { 0f to 0f }
                val jitterX = (unitNoise("${cluster.constellation.id}_${star.name}_x") - 0.5f) * 3.8f
                val jitterY = (unitNoise("${cluster.constellation.id}_${star.name}_y") - 0.5f) * 3.8f
                val rawSx = (cluster.cx + (offset.first * cluster.radius) + jitterX).roundToInt()
                val rawSy = (cluster.cy + (offset.second * cluster.radius * 0.92f) + jitterY).roundToInt() + panOffset
                rawMinX = min(rawMinX, rawSx.toFloat())
                rawMaxX = max(rawMaxX, rawSx.toFloat())
                rawMinY = min(rawMinY, rawSy.toFloat())
                rawMaxY = max(rawMaxY, rawSy.toFloat())
                val sx = ((rawSx - plotCenterX) * mapZoom + plotCenterX + mapPanX).roundToInt()
                val sy = ((rawSy - plotCenterY) * mapZoom + plotCenterY + mapPanY).roundToInt()
                val key = "${cluster.constellation.id}:${star.name}"
                out += StarPoint(
                    key = key,
                    constellation = cluster.constellation,
                    star = star,
                    x = sx,
                    y = sy,
                    radius = if (normalizeTier(star.tier) == "greater") 4 else 3,
                    color = color,
                )
            }
        }
        mapRawBounds = if (out.isEmpty()) null else MapRawBounds(rawMinX, rawMaxX, rawMinY, rawMaxY)
        return resolveStarStacking(out)
    }

    private data class RealmSector(val cx: Float, val cy: Float, val rx: Float, val ry: Float)

    private data class ConstellationCluster(
        val constellation: SpiritRealmConstellation,
        val stars: List<SpiritRealmStar>,
        val bucketTier: String,
        val realmKey: String,
        var radius: Float,
        val phase: Float,
        var cx: Float = 0f,
        var cy: Float = 0f,
    )

    private fun realmKeyForConstellation(constellationId: String): String = when {
        constellationId.startsWith("elemental_realm_") -> "elemental"
        constellationId.startsWith("immortal_realm_") -> "immortal"
        constellationId.startsWith("ancestral_realm_") -> "ancestral"
        else -> "unknown"
    }

    private fun realmSectorFor(plot: PlotRect, realm: String, clusterCount: Int): RealmSector = when (realm) {
        "elemental" -> RealmSector(
            cx = plot.left + (plot.width * 0.22f),
            cy = plot.top + (plot.height * 0.34f),
            rx = plot.width * (0.24f + (clusterCount.coerceAtMost(18) / 18f) * 0.14f),
            ry = plot.height * (0.24f + (clusterCount.coerceAtMost(18) / 18f) * 0.10f),
        )
        "immortal" -> RealmSector(
            cx = plot.left + (plot.width * 0.78f),
            cy = plot.top + (plot.height * 0.36f),
            rx = plot.width * (0.24f + (clusterCount.coerceAtMost(48) / 48f) * 0.16f),
            ry = plot.height * (0.24f + (clusterCount.coerceAtMost(48) / 48f) * 0.12f),
        )
        "ancestral" -> RealmSector(
            cx = plot.left + (plot.width * 0.50f),
            cy = plot.top + (plot.height * 0.76f),
            rx = plot.width * 0.42f,
            ry = plot.height * 0.24f,
        )
        else -> RealmSector(
            cx = plot.left + (plot.width * 0.50f),
            cy = plot.top + (plot.height * 0.50f),
            rx = plot.width * 0.20f,
            ry = plot.height * 0.20f,
        )
    }

    private fun clusterDensityScale(clusterCount: Int): Float = when {
        clusterCount >= 40 -> 0.60f
        clusterCount >= 28 -> 0.70f
        clusterCount >= 18 -> 0.80f
        clusterCount >= 10 -> 0.90f
        else -> 1.0f
    }

    private fun placeClustersInSector(clusters: List<ConstellationCluster>, sector: RealmSector) {
        if (clusters.isEmpty()) return
        val golden = 2.3999632f
        val count = clusters.size.toFloat()
        val spacingPadding = (24f - ((clusters.size - 8).coerceAtLeast(0) * 0.55f)).coerceIn(6f, 24f)
        for ((index, cluster) in clusters.withIndex()) {
            val radial = sqrt((index + 0.65f) / (count + 0.35f))
            val angle = (index * golden) + cluster.phase
            val jitterX = (unitNoise("cluster_${cluster.constellation.id}_jx") - 0.5f) * sector.rx * 0.12f
            val jitterY = (unitNoise("cluster_${cluster.constellation.id}_jy") - 0.5f) * sector.ry * 0.12f
            cluster.cx = sector.cx + (cos(angle) * sector.rx * radial) + jitterX
            cluster.cy = sector.cy + (sin(angle) * sector.ry * radial) + jitterY
        }

        repeat(34) {
            var moved = false
            for (i in 0 until clusters.lastIndex) {
                val a = clusters[i]
                for (j in i + 1 until clusters.size) {
                    val b = clusters[j]
                    val dx = b.cx - a.cx
                    val dy = b.cy - a.cy
                    val minDist = a.radius + b.radius + spacingPadding
                    val distSq = (dx * dx) + (dy * dy)
                    if (distSq >= (minDist * minDist)) continue
                    val dist = sqrt(distSq.coerceAtLeast(0.0001f))
                    val push = (minDist - dist) * 0.52f
                    val ux = dx / dist
                    val uy = dy / dist
                    a.cx -= ux * push
                    a.cy -= uy * push
                    b.cx += ux * push
                    b.cy += uy * push
                    moved = true
                }
            }

            for (cluster in clusters) {
                val marginX = min(cluster.radius * 0.56f, sector.rx * 0.72f)
                val marginY = min(cluster.radius * 0.56f, sector.ry * 0.72f)
                val minX = sector.cx - sector.rx + marginX
                val maxX = sector.cx + sector.rx - marginX
                val minY = sector.cy - sector.ry + marginY
                val maxY = sector.cy + sector.ry - marginY
                cluster.cx = clampRange(cluster.cx, minX, maxX)
                cluster.cy = clampRange(cluster.cy, minY, maxY)
            }
            if (!moved) return
        }
    }

    private fun clampRange(value: Float, minValue: Float, maxValue: Float): Float {
        if (minValue > maxValue) return (minValue + maxValue) * 0.5f
        return value.coerceIn(minValue, maxValue)
    }

    private fun spreadClustersGlobal(clusters: List<ConstellationCluster>, plot: PlotRect) {
        if (clusters.size < 2) return
        val minX = plot.left + 20f
        val maxX = plot.right - 20f
        val minY = plot.top + 34f
        val maxY = plot.bottom - 16f
        repeat(24) {
            var moved = false
            for (i in 0 until clusters.lastIndex) {
                val a = clusters[i]
                for (j in i + 1 until clusters.size) {
                    val b = clusters[j]
                    val dx = b.cx - a.cx
                    val dy = b.cy - a.cy
                    val minDist = a.radius + b.radius + 18f
                    val distSq = (dx * dx) + (dy * dy)
                    if (distSq >= (minDist * minDist)) continue
                    val dist = sqrt(distSq.coerceAtLeast(0.0001f))
                    val ux = dx / dist
                    val uy = dy / dist
                    val push = (minDist - dist) * 0.38f
                    a.cx -= ux * push
                    a.cy -= uy * push
                    b.cx += ux * push
                    b.cy += uy * push
                    moved = true
                }
            }
            for (cluster in clusters) {
                cluster.cx = cluster.cx.coerceIn(minX, maxX)
                cluster.cy = cluster.cy.coerceIn(minY, maxY)
            }
            if (!moved) return
        }
    }

    private fun applyLoreAnchors(clusters: List<ConstellationCluster>, plot: PlotRect) {
        val byId = clusters.associateBy { it.constellation.id }
        val greater = byId["ancestral_realm_greater_ancestrals"]
        val kulgarokLine = byId["ancestral_realm_dishonored_ancestrals"]
        val kor = byId["immortal_realm_kor"]
        val leyd = clusters.firstOrNull { cluster ->
            cluster.stars.any { star -> star.name.lowercase().contains("leyd") }
        }

        if (greater != null && kor != null) {
            kor.cx = greater.cx + min(greater.radius * 0.24f, plot.width * 0.028f)
            kor.cy = greater.cy + min(greater.radius * 0.14f, plot.height * 0.020f)
        }
        if (kulgarokLine != null) {
            kulgarokLine.cx = plot.left + (plot.width * 0.82f)
            kulgarokLine.cy = plot.top + (plot.height * 0.66f)
        }
        if (leyd != null) {
            leyd.cx = plot.left + (plot.width * 0.80f)
            leyd.cy = plot.top + (plot.height * 0.50f)
        }

        val elementalSpreadIds = listOf(
            "elemental_realm_omnizan",
            "elemental_realm_binazdar",
            "elemental_realm_sandru",
            "elemental_realm_fanzra",
            "elemental_realm_andrif",
            "elemental_realm_ringat",
            "elemental_realm_radzanib",
            "elemental_realm_radnazib",
        )
        val elementalSpread = elementalSpreadIds.mapNotNull { byId[it] }.distinct()
        if (elementalSpread.isNotEmpty()) {
            val centerX = plot.left + (plot.width * 0.18f)
            val centerY = plot.top + (plot.height * 0.56f)
            val radiusX = plot.width * 0.18f
            val radiusY = plot.height * 0.16f
            val n = elementalSpread.size.toFloat()
            for ((index, cluster) in elementalSpread.withIndex()) {
                val t = index.toFloat() / n
                val angle = (0.18f * PI.toFloat()) + (t * (PI * 1.76f).toFloat())
                cluster.cx = centerX + (cos(angle) * radiusX)
                cluster.cy = centerY + (sin(angle) * radiusY)
            }
        }

        val minX = plot.left + 18f
        val maxX = plot.right - 18f
        val minY = plot.top + 34f
        val maxY = plot.bottom - 14f
        for (cluster in listOfNotNull(kor, kulgarokLine, leyd)) {
            cluster.cx = cluster.cx.coerceIn(minX, maxX)
            cluster.cy = cluster.cy.coerceIn(minY, maxY)
        }
    }

    private fun orderStarsForConstellation(
        constellationId: String,
        stars: List<SpiritRealmStar>,
    ): List<SpiritRealmStar> {
        if (constellationId != "ancestral_realm_greater_ancestrals" || stars.isEmpty()) return stars
        val promoted = listOf("Grahla", "Agzal", "Balzug", "Dlimbok", "Saranak")
        val promotedByName = promoted.associateWith { target ->
            stars.firstOrNull { it.name.equals(target, ignoreCase = true) }
        }
        val out = mutableListOf<SpiritRealmStar>()
        var inserted = false
        for (star in stars) {
            if (promoted.any { star.name.equals(it, ignoreCase = true) }) continue
            out += star
            if (!inserted && star.name.equals("Krug", ignoreCase = true)) {
                for (name in promoted) {
                    promotedByName[name]?.let { out += it }
                }
                inserted = true
            }
        }
        if (!inserted) {
            for (name in promoted) {
                promotedByName[name]?.let { out += it }
            }
        }
        return out
    }

    private fun expandRealmConstellations(constellations: List<SpiritRealmConstellation>): List<SpiritRealmConstellation> {
        val sourceId = "ancestral_realm_notable_lesser_ancestrals"
        val chunkSize = 7
        return constellations.flatMap { constellation ->
            if (constellation.id != sourceId || constellation.stars.size <= chunkSize + 2) {
                listOf(constellation)
            } else {
                constellation.stars.chunked(chunkSize).mapIndexed { index, chunk ->
                    constellation.copy(
                        id = "${sourceId}_cluster_${index + 1}",
                        name = constellation.name,
                        stars = chunk,
                    )
                }
            }
        }
    }

    private fun buildConstellationOffsets(constellationId: String, starCount: Int): List<Pair<Float, Float>> {
        if (starCount <= 0) return emptyList()
        buildIlzpaakDerivedOffsets(constellationId, starCount)?.let { return it }
        if (constellationId.startsWith("ancestral_realm_notable_lesser_ancestrals_cluster_")) {
            return buildLesserAncestralOffsets(constellationId, starCount)
        }
        if (constellationId == "ancestral_realm_or_ta_dom") {
            val base = mutableListOf(
                0.00f to -0.82f, // Or'ta'Dom
                0.02f to -0.12f, // Zogrocka'Rax (descending)
                -0.46f to 0.44f, // Raz'Dom
                0.44f to 0.60f,  // Grak'Dom
            )
            while (base.size < starCount) {
                val i = base.size
                val side = if (i % 2 == 0) -1f else 1f
                base += (side * (0.36f + ((i % 3) * 0.10f))) to (0.28f + (i * 0.06f))
            }
            return base.take(starCount)
        }
        if (starCount == 1) return listOf(0f to 0f)
        if (starCount == 2) return listOf((-0.44f to -0.10f), (0.44f to 0.12f))

        val style = ((constellationId.hashCode() % 4) + 4) % 4
        val out = mutableListOf<Pair<Float, Float>>()
        when (style) {
            0 -> { // Crescent arc
                for (i in 0 until starCount) {
                    val t = i.toFloat() / (starCount - 1).toFloat()
                    val x = -0.96f + (1.92f * t)
                    val y = -0.16f + (sin(t * PI).toFloat() * 0.62f)
                    out += x to y
                }
            }
            1 -> { // Lore spiral
                for (i in 0 until starCount) {
                    val t = if (starCount <= 1) 0f else i.toFloat() / (starCount - 1).toFloat()
                    val angle = (t * (PI * 4.8f).toFloat()) - (PI * 0.4f).toFloat()
                    val radius = 0.16f + (0.82f * t)
                    out += (cos(angle) * radius).toFloat() to (sin(angle) * radius).toFloat()
                }
            }
            2 -> { // Branching tree
                val trunk = max(2, starCount / 2)
                for (i in 0 until trunk) {
                    val t = if (trunk <= 1) 0f else i.toFloat() / (trunk - 1).toFloat()
                    val y = -0.86f + (t * 1.00f)
                    val x = (unitNoise("${constellationId}_trunk_$i") - 0.5f) * 0.14f
                    out += x to y
                }
                var arm = 0
                while (out.size < starCount) {
                    val side = if (arm % 2 == 0) -1f else 1f
                    val wave = (arm / 2).toFloat()
                    val x = side * (0.34f + (0.14f * (wave % 3f)))
                    val y = -0.08f + (0.24f * wave)
                    out += x to y
                    arm++
                }
            }
            else -> { // Woven loop
                for (i in 0 until starCount) {
                    val t = i.toFloat() / starCount.toFloat()
                    val angle = (t * (PI * 2f).toFloat())
                    val x = (cos(angle) * 0.82f).toFloat() + ((sin(angle * 2.1f) * 0.14f).toFloat())
                    val y = (sin(angle) * 0.60f).toFloat() + ((cos(angle * 1.7f) * 0.12f).toFloat())
                    out += x to y
                }
            }
        }

        val rotation = unitNoise("${constellationId}_rot") * (PI * 2f).toFloat()
        return out.map { rotateOffset(it.first, it.second, rotation) }
    }

    private fun buildLesserAncestralOffsets(constellationId: String, starCount: Int): List<Pair<Float, Float>> {
        if (starCount <= 1) return listOf(0f to 0f)
        if (starCount == 2) return listOf((-0.34f to -0.20f), (0.34f to 0.24f))
        val out = mutableListOf<Pair<Float, Float>>()
        val clusterIndex = lesserAncestralClusterIndex(constellationId)
        val motifCount = 8
        val motif = when {
            clusterIndex != null -> ((clusterIndex - 1) % motifCount + motifCount) % motifCount
            else -> ((constellationId.hashCode() % motifCount) + motifCount) % motifCount
        }
        when (motif) {
            0 -> { // Totem spine with uneven branches.
                val spineCount = min(starCount, max(2, (starCount * (0.42f + (unitNoise("${constellationId}_m0") * 0.28f))).roundToInt()))
                for (i in 0 until spineCount) {
                    val t = if (spineCount <= 1) 0f else i.toFloat() / (spineCount - 1).toFloat()
                    val x = (unitNoise("${constellationId}_m0_spine_$i") - 0.5f) * 0.20f
                    val y = -0.92f + (t * 1.34f)
                    out += x to y
                }
                var branch = 0
                while (out.size < starCount) {
                    val side = if (branch % 2 == 0) -1f else 1f
                    val rung = (branch / 2).toFloat()
                    val x = side * (0.24f + ((rung % 3f) * 0.15f))
                    val y = -0.56f + (rung * 0.28f) + ((unitNoise("${constellationId}_m0_branch_$branch") - 0.5f) * 0.12f)
                    out += x to y
                    branch++
                }
            }
            1 -> { // Crooked crescent with ribs.
                val bend = 0.40f + (unitNoise("${constellationId}_m1_bend") * 0.28f)
                val ribDepth = 0.18f + (unitNoise("${constellationId}_m1_rib") * 0.20f)
                for (i in 0 until starCount) {
                    val t = if (starCount <= 1) 0f else i.toFloat() / (starCount - 1).toFloat()
                    val x = -0.92f + (1.84f * t)
                    val arch = sin((t * PI).toDouble()).toFloat() * bend
                    val rib = if (i % 2 == 0) -ribDepth else ribDepth * 0.64f
                    out += x to (-0.22f + arch + rib)
                }
            }
            2 -> { // Forked path (trunk and split arms).
                val trunkCount = min(starCount, max(2, starCount / 2))
                for (i in 0 until trunkCount) {
                    val t = if (trunkCount <= 1) 0f else i.toFloat() / (trunkCount - 1).toFloat()
                    val x = (unitNoise("${constellationId}_m2_trunk_$i") - 0.5f) * 0.18f
                    val y = -0.94f + (t * 0.86f)
                    out += x to y
                }
                var arm = 0
                while (out.size < starCount) {
                    val side = if (arm % 2 == 0) -1f else 1f
                    val rung = (arm / 2).toFloat()
                    val spread = 0.24f + (0.17f * rung)
                    val y = -0.10f + (rung * 0.22f)
                    out += (side * spread) to y
                    arm++
                }
            }
            3 -> { // Broken ring.
                val wobble = 0.10f + (unitNoise("${constellationId}_m3_wobble") * 0.12f)
                for (i in 0 until starCount) {
                    val t = i.toFloat() / starCount.toFloat()
                    val angle = (t * (PI * 2f).toFloat()) + (PI * 0.11f).toFloat()
                    val rx = 0.72f + (sin((angle * 1.9f).toDouble()).toFloat() * wobble)
                    val ry = 0.52f + (cos((angle * 1.4f).toDouble()).toFloat() * (wobble * 0.9f))
                    out += (cos(angle) * rx).toFloat() to (sin(angle) * ry).toFloat()
                }
            }
            4 -> { // Zig-zag river chain.
                val slope = 0.30f + (unitNoise("${constellationId}_m4_slope") * 0.28f)
                for (i in 0 until starCount) {
                    val t = if (starCount <= 1) 0f else i.toFloat() / (starCount - 1).toFloat()
                    val side = if (i % 2 == 0) -1f else 1f
                    val x = (side * (0.22f + (t * 0.58f))) + ((unitNoise("${constellationId}_m4_jitx_$i") - 0.5f) * 0.10f)
                    val y = -0.88f + (t * 1.34f) + (side * slope * 0.08f)
                    out += x to y
                }
            }
            5 -> { // Staggered ladder.
                for (i in 0 until starCount) {
                    val t = if (starCount <= 1) 0f else i.toFloat() / (starCount - 1).toFloat()
                    val rail = if (i % 2 == 0) -0.42f else 0.42f
                    val x = rail + ((unitNoise("${constellationId}_m5_jitx_$i") - 0.5f) * 0.10f)
                    val y = -0.88f + (t * 1.36f)
                    out += x to y
                }
            }
            6 -> { // Crown arc.
                for (i in 0 until starCount) {
                    val t = if (starCount <= 1) 0f else i.toFloat() / (starCount - 1).toFloat()
                    val x = -0.94f + (1.88f * t)
                    val spike = if (i % 2 == 0) 0.30f else -0.18f
                    val y = -0.34f + (sin((t * PI).toDouble()).toFloat() * 0.78f) + (spike * 0.38f)
                    out += x to y
                }
            }
            else -> { // Orb and tail.
                val orbCount = min(starCount, max(3, starCount / 2))
                for (i in 0 until orbCount) {
                    val t = i.toFloat() / orbCount.toFloat()
                    val angle = t * (PI * 2f).toFloat()
                    val x = (cos(angle) * 0.46f).toFloat()
                    val y = (sin(angle) * 0.34f).toFloat() - 0.20f
                    out += x to y
                }
                var tail = 0
                while (out.size < starCount) {
                    val t = tail.toFloat() / (starCount - orbCount).coerceAtLeast(1).toFloat()
                    val x = 0.12f - (t * 0.72f)
                    val y = -0.05f + (t * 1.08f)
                    out += x to y
                    tail++
                }
            }
        }
        val stretchX = 0.86f + (unitNoise("${constellationId}_sx") * 0.42f)
        val stretchY = 0.82f + (unitNoise("${constellationId}_sy") * 0.48f)
        val mirrorX = if ((clusterIndex ?: 0) % 2 == 0) 1f else -1f
        val shear = (unitNoise("${constellationId}_shear") - 0.5f) * 0.34f
        val rotationBase = (unitNoise("${constellationId}_rot") - 0.5f) * (PI * 0.94f).toFloat()
        val indexedTwist = ((((clusterIndex ?: 1) - 1) % 6).toFloat()) * (PI.toFloat() / 48f)
        val rotation = rotationBase + indexedTwist
        return out.take(starCount)
            .map { (x, y) ->
                val sx = (x * stretchX * mirrorX) + (y * shear)
                val sy = y * stretchY
                sx to sy
            }
            .map { rotateOffset(it.first, it.second, rotation) }
    }

    private fun lesserAncestralClusterIndex(constellationId: String): Int? {
        val marker = "_cluster_"
        val idx = constellationId.lastIndexOf(marker)
        if (idx < 0) return null
        return constellationId.substring(idx + marker.length).toIntOrNull()
    }

    private fun buildIlzpaakDerivedOffsets(constellationId: String, starCount: Int): List<Pair<Float, Float>>? {
        if (!constellationId.startsWith("immortal_realm_")) return null
        val spiritToken = constellationId.removePrefix("immortal_realm_")
        val sign = ilzpaakSigns.firstOrNull { normalizedIdToken(it.spirit) == spiritToken } ?: return null
        val sampledNodes = sampleIlzpaakNodes(sign.constellationNodes, starCount)
        if (sampledNodes.isEmpty()) return null
        val minX = sampledNodes.minOf { it.x }
        val maxX = sampledNodes.maxOf { it.x }
        val minY = sampledNodes.minOf { it.y }
        val maxY = sampledNodes.maxOf { it.y }
        val cx = (minX + maxX) * 0.5f
        val cy = (minY + maxY) * 0.5f
        val sx = ((maxX - minX) * 0.5f).coerceAtLeast(0.01f)
        val sy = ((maxY - minY) * 0.5f).coerceAtLeast(0.01f)
        return sampledNodes.map { ((it.x - cx) / sx) to ((it.y - cy) / sy) }
    }

    private fun sampleIlzpaakNodes(nodes: List<IlzpaakConstellationNode>, count: Int): List<IlzpaakConstellationNode> {
        if (count <= 0 || nodes.isEmpty()) return emptyList()
        if (count == 1) {
            val avgX = nodes.sumOf { it.x.toDouble() } / nodes.size.toDouble()
            val avgY = nodes.sumOf { it.y.toDouble() } / nodes.size.toDouble()
            return listOf(IlzpaakConstellationNode(avgX.toFloat(), avgY.toFloat()))
        }
        if (count >= nodes.size) return orderNodesByNearest(nodes)

        val selected = mutableListOf<Int>()
        val startIndex = nodes.indices.minByOrNull { nodes[it].y + (nodes[it].x * 0.05f) } ?: 0
        selected += startIndex
        while (selected.size < count) {
            var bestIndex = -1
            var bestScore = -1f
            for (candidate in nodes.indices) {
                if (candidate in selected) continue
                val minDist = selected.minOf { picked ->
                    val dx = nodes[candidate].x - nodes[picked].x
                    val dy = nodes[candidate].y - nodes[picked].y
                    (dx * dx) + (dy * dy)
                }
                if (minDist > bestScore) {
                    bestScore = minDist
                    bestIndex = candidate
                }
            }
            if (bestIndex < 0) break
            selected += bestIndex
        }
        return orderNodesByNearest(selected.map { nodes[it] })
    }

    private fun orderNodesByNearest(nodes: List<IlzpaakConstellationNode>): List<IlzpaakConstellationNode> {
        if (nodes.size <= 2) return nodes
        val remaining = nodes.toMutableList()
        val start = remaining.minByOrNull { it.y + (it.x * 0.05f) } ?: remaining.first()
        remaining.remove(start)
        val ordered = mutableListOf(start)
        while (remaining.isNotEmpty()) {
            val last = ordered.last()
            val next = remaining.minByOrNull { node ->
                val dx = node.x - last.x
                val dy = node.y - last.y
                (dx * dx) + (dy * dy)
            } ?: break
            ordered += next
            remaining.remove(next)
        }
        return ordered
    }

    private fun rotateOffset(x: Float, y: Float, angle: Float): Pair<Float, Float> {
        val c = cos(angle)
        val s = sin(angle)
        return ((x * c) - (y * s)).toFloat() to ((x * s) + (y * c)).toFloat()
    }

    private fun resolveStarStacking(points: List<StarPoint>): List<StarPoint> {
        if (points.size < 2) return points
        val pos = points.map { floatArrayOf(it.x.toFloat(), it.y.toFloat()) }.toMutableList()
        repeat(14) {
            var moved = false
            for (i in 0 until points.lastIndex) {
                for (j in i + 1 until points.size) {
                    val ax = pos[i][0]
                    val ay = pos[i][1]
                    val bx = pos[j][0]
                    val by = pos[j][1]
                    var dx = bx - ax
                    var dy = by - ay
                    val base = (points[i].radius + points[j].radius + 2).toFloat()
                    val extra = if (points[i].constellation.id == points[j].constellation.id) 0f else 6f
                    val minDist = base + extra
                    val distSq = (dx * dx) + (dy * dy)
                    if (distSq >= minDist * minDist) continue
                    var dist = sqrt(distSq.coerceAtLeast(0.0001f))
                    if (distSq < 0.0001f) {
                        val seed = (points[i].key.hashCode() * 31) xor points[j].key.hashCode()
                        val angle = ((((seed % 360) + 360) % 360) / 180.0 * PI).toFloat()
                        dx = cos(angle)
                        dy = sin(angle)
                        dist = 1f
                    } else {
                        dx /= dist
                        dy /= dist
                    }
                    val push = (minDist - dist) * 0.52f
                    pos[i][0] -= dx * push
                    pos[i][1] -= dy * push
                    pos[j][0] += dx * push
                    pos[j][1] += dy * push
                    moved = true
                }
            }
            if (!moved) return@repeat
        }
        return points.indices.map { idx ->
            points[idx].copy(
                x = pos[idx][0].roundToInt(),
                y = pos[idx][1].roundToInt(),
            )
        }
    }

    override fun mouseClicked(mx: Double, my: Double, button: Int): Boolean {
        if (button == 0 && isIlzpaakLoreRevealActive() &&
            isPointInIlzpaakLorePanel(mx.toInt(), my.toInt())) {
            completeIlzpaakLoreRevealNow()
            return true
        }
        if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
            val divRect = divinationPanelRect()
            if (divRect != null && divRect.contains(mx.toInt(), my.toInt())) {
                if (super.mouseClicked(mx, my, button)) return true
                if (::divinationNameField.isInitialized && button == 0) {
                    val inField = mx >= divinationNameField.x &&
                        mx < (divinationNameField.x + divinationNameField.width) &&
                        my >= divinationNameField.y &&
                        my < (divinationNameField.y + divinationNameField.height)
                    divinationNameField.setFocused(inField)
                    return true
                }
                return true
            }
            if (button == 1 && focusedIlzpaakSign != null) {
                focusedIlzpaakTarget = 0f
                selectedSkyNode = null
                return true
            }
            val nodeHit = skyNodeHitboxes.firstOrNull {
                val dx = it.x - mx
                val dy = it.y - my
                (dx * dx + dy * dy) <= 14.0 * 14.0
            }
            if (nodeHit != null) {
                highlightedIlzpaak = nodeHit.signIndex
                divinationMonthIdx = nodeHit.signIndex
                selectedSkyNode = nodeHit
                if (focusedIlzpaakSign == null || focusedIlzpaakTarget <= 0.01f) {
                    focusedIlzpaakSign = nodeHit.signIndex
                    focusedIlzpaakTarget = 1f
                }
                return true
            }

            val signHit = skySignHitboxes.firstOrNull {
                val dx = it.x - mx
                val dy = it.y - my
                (dx * dx + dy * dy) <= 72.0 * 72.0
            }
            if (signHit != null) {
                highlightedIlzpaak = signHit.signIndex
                divinationMonthIdx = signHit.signIndex
                selectedSkyNode = null
                focusedIlzpaakSign = signHit.signIndex
                focusedIlzpaakTarget = 1f
                return true
            }
            return super.mouseClicked(mx, my, button)
        }

        val hitPill = tierPills.firstOrNull { mx >= it.x && mx <= it.x + it.w && my >= it.y && my <= it.y + it.h }
        if (hitPill != null) {
            tierFilter = hitPill.id
            return true
        }
        val listHit = starListHitboxes.firstOrNull {
            mx >= it.x && mx <= it.x + it.w && my >= it.y && my <= it.y + it.h
        }
        if (listHit != null) {
            selectedKey = listHit.key
            return true
        }
        val hit = findHovered(mx.toInt(), my.toInt())
        if (hit != null) {
            selectedKey = hit.key
            return true
        }
        if (button == 0 && pointInRealmMap(mx.toInt(), my.toInt())) {
            draggingMap = true
            return true
        }
        return super.mouseClicked(mx, my, button)
    }

    override fun mouseDragged(mx: Double, my: Double, button: Int, dx: Double, dy: Double): Boolean {
        if (displayMode == DisplayMode.REALM_MAP && button == 0 && draggingMap && realmMapPlot != null) {
            mapPanX += dx.toFloat()
            mapPanY += dy.toFloat()
            clampMapPan()
            return true
        }
        return super.mouseDragged(mx, my, button, dx, dy)
    }

    override fun mouseReleased(mx: Double, my: Double, button: Int): Boolean {
        if (button == 0) draggingMap = false
        return super.mouseReleased(mx, my, button)
    }

    override fun mouseScrolled(mx: Double, my: Double, hAmount: Double, vAmount: Double): Boolean {
        if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
            val rect = skyNodeInfoRect
            if (rect != null && rect.contains(mx.toInt(), my.toInt()) && skyNodeInfoMaxScroll > 0f) {
                skyNodeInfoScroll = (skyNodeInfoScroll - (vAmount * 14.0).toFloat()).coerceIn(0f, skyNodeInfoMaxScroll)
                return true
            }
        }
        if (displayMode == DisplayMode.REALM_MAP && pointInRealmMap(mx.toInt(), my.toInt())) {
            val oldZoom = mapZoom
            mapZoom = (mapZoom + (vAmount * 0.09).toFloat()).coerceIn(minMapZoom, maxMapZoom)
            if (mapZoom != oldZoom) {
                clampMapPan()
                return true
            }
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount)
    }

    override fun keyPressed(kc: Int, sc: Int, mods: Int): Boolean {
        if (::divinationNameField.isInitialized && divinationNameField.visible && divinationNameField.isFocused) {
            if (kc == GLFW.GLFW_KEY_V) {
                showDivinationPanel = false
                divinationNameField.setFocused(false)
                return true
            }
            if (kc == GLFW.GLFW_KEY_ENTER || kc == GLFW.GLFW_KEY_KP_ENTER) {
                castDivination()
                return true
            }
            return super.keyPressed(kc, sc, mods)
        }
        when (kc) {
            GLFW.GLFW_KEY_K -> {
                if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) openRealmMapMode() else openIlzpaakMode()
                return true
            }
            GLFW.GLFW_KEY_I -> {
                openIlzpaakMode()
                return true
            }
            GLFW.GLFW_KEY_F -> if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
                if (focusedIlzpaakSign == null || focusedIlzpaakTarget <= 0f) {
                    focusedIlzpaakSign = highlightedIlzpaak.coerceIn(0, ilzpaakSigns.lastIndex)
                    focusedIlzpaakTarget = 1f
                } else {
                    focusedIlzpaakTarget = 0f
                    selectedSkyNode = null
                }
                return true
            }
            GLFW.GLFW_KEY_LEFT -> if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
                cycleMonth(-1); return true
            }
            GLFW.GLFW_KEY_RIGHT -> if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
                cycleMonth(1); return true
            }
            GLFW.GLFW_KEY_UP -> if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
                divinationDay = (divinationDay + 1).coerceAtMost(24); return true
            }
            GLFW.GLFW_KEY_DOWN -> if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
                divinationDay = (divinationDay - 1).coerceAtLeast(1); return true
            }
            GLFW.GLFW_KEY_PAGE_UP -> if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
                divinationYear = (divinationYear ?: SpiritRealmLoreRepository.currentTimeConversion().saYear) + 1; return true
            }
            GLFW.GLFW_KEY_PAGE_DOWN -> if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
                divinationYear = (divinationYear ?: SpiritRealmLoreRepository.currentTimeConversion().saYear) - 1; return true
            }
            GLFW.GLFW_KEY_C -> if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
                divinationCalendar = if (divinationCalendar == "SA") "FA" else "SA"; return true
            }
            GLFW.GLFW_KEY_O -> if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
                divinationSand = when (divinationSand) {
                    IlzpaakSandPath.YELLOW -> IlzpaakSandPath.BOTH
                    IlzpaakSandPath.BOTH -> IlzpaakSandPath.RED
                    IlzpaakSandPath.RED -> IlzpaakSandPath.YELLOW
                }
                return true
            }
            GLFW.GLFW_KEY_V -> if (displayMode == DisplayMode.ILZPAAK_SKYVIEW) {
                showDivinationPanel = !showDivinationPanel
                if (showDivinationPanel) {
                    castDivination()
                    highlightedIlzpaak = divinationMonthIdx
                    if (::divinationNameField.isInitialized) {
                        divinationNameField.setFocused(true)
                    }
                } else if (::divinationNameField.isInitialized) {
                    divinationNameField.setFocused(false)
                }
                return true
            }
            GLFW.GLFW_KEY_R -> {
                module.requestRefresh(force = true, notifyOnFail = true)
                return true
            }
            GLFW.GLFW_KEY_1 -> if (displayMode == DisplayMode.REALM_MAP) { tierFilter = "greater"; return true }
            GLFW.GLFW_KEY_2 -> if (displayMode == DisplayMode.REALM_MAP) { tierFilter = "lesser"; return true }
            GLFW.GLFW_KEY_3 -> if (displayMode == DisplayMode.REALM_MAP) { tierFilter = "dishonored"; return true }
            GLFW.GLFW_KEY_0 -> if (displayMode == DisplayMode.REALM_MAP) { tierFilter = "all"; return true }
        }
        return super.keyPressed(kc, sc, mods)
    }

    private fun inferIlzpaakFromPayload(payload: SpiritRealmPayload?): Int {
        if (payload == null) return -1
        val tokens = buildString {
            append(payload.currentSign.name.lowercase())
            append(' ')
            append(payload.currentSign.domain.lowercase())
            if (payload.zodiac.isNotEmpty()) {
                append(' ')
                append(payload.zodiac.joinToString(" ") { it.name.lowercase() })
            }
        }
        return ilzpaakSigns.indexOfFirst { sign ->
            tokens.contains(sign.orcish.lowercase()) ||
                tokens.contains(sign.elven.lowercase()) ||
                tokens.contains(sign.spirit.lowercase())
        }
    }

    private fun findHovered(mx: Int, my: Int): StarPoint? {
        var best: StarPoint? = null
        var bestDist = Int.MAX_VALUE
        for (p in stars) {
            val dx = p.x - mx
            val dy = p.y - my
            val dist = dx * dx + dy * dy
            val maxDist = (p.radius + 5) * (p.radius + 5)
            if (dist <= maxDist && dist < bestDist) {
                best = p
                bestDist = dist
            }
        }
        return best
    }

    private fun drawStar(dc: DrawContext, x: Int, y: Int, r: Int, color: Int) {
        dc.fill(x - r, y, x + r + 1, y + 1, color)
        dc.fill(x, y - r, x + 1, y + r + 1, color)
        dc.fill(x - 1, y - 1, x + 2, y + 2, color)
    }

    private fun drawLine(dc: DrawContext, a: StarPoint, b: StarPoint, color: Int) {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val steps = max(abs(dx), abs(dy))
        if (steps <= 0) return
        for (i in 0..steps step 2) {
            val t = i.toFloat() / steps.toFloat()
            val x = (a.x + dx * t).toInt()
            val y = (a.y + dy * t).toInt()
            dc.fill(x, y, x + 1, y + 1, color)
        }
    }

    private fun drawPrimitiveLine(dc: DrawContext, x1: Float, y1: Float, x2: Float, y2: Float, color: Int, thickness: Int) {
        val dx = x2 - x1
        val dy = y2 - y1
        val steps = max(abs(dx), abs(dy)).roundToInt().coerceAtLeast(1)
        for (i in 0..steps) {
            val t = i.toFloat() / steps.toFloat()
            val x = (x1 + dx * t).roundToInt()
            val y = (y1 + dy * t).roundToInt()
            dc.fill(x - thickness, y - thickness, x + thickness + 1, y + thickness + 1, color)
        }
    }

    private fun tierColor(tier: String): Int = when (normalizeTier(tier)) {
        "greater" -> 0xFFE6BD88.toInt()
        "lesser" -> 0xFF8EE9FF.toInt()
        "dishonored" -> 0xFFFF6C6C.toInt()
        else -> 0xFFCAD5ED.toInt()
    }

    private fun parseHexColor(raw: String?, fallback: Int): Int {
        if (raw.isNullOrBlank()) return fallback
        val clean = raw.trim().removePrefix("#")
        return if (clean.length == 6) {
            runCatching { 0xFF000000.toInt() or clean.toInt(16) }.getOrDefault(fallback)
        } else fallback
    }

    private fun normalizeTier(input: String): String = when (input.lowercase()) {
        "greater" -> "greater"
        "lesser" -> "lesser"
        "dishonored", "dishonoured" -> "dishonored"
        else -> "greater"
    }

    private fun maybeAutoRefresh(payload: SpiritRealmPayload?) {
        val now = System.currentTimeMillis()
        if (payload == null && !module.isRefreshing() && now - lastAutoRefreshAtMs > 2000) {
            lastAutoRefreshAtMs = now
            module.requestRefresh(force = true, notifyOnFail = false)
        }
    }

    private fun unitNoise(seed: String): Float {
        val h = seed.hashCode().toLong() * 1103515245L + 12345L
        val v = ((h ushr 16) and 0x7FFFL).toFloat()
        return (v % 4096f) / 4096f
    }

    private fun stepDriftingSky() {
        val now = System.currentTimeMillis()
        val dtSec = ((now - lastSkyDriftMs).coerceIn(0L, 60L)).toFloat() / 1000f
        lastSkyDriftMs = now
        if (dtSec <= 0f) return
        for (star in driftingStars) {
            star.x = wrap01(star.x + (star.vx * dtSec))
            star.y = wrap01(star.y + (star.vy * dtSec))
        }
    }

    private fun renderDriftingStars(dc: DrawContext, coolRgb: Int, warmRgb: Int, alphaBase: Int, alphaRange: Int) {
        val t = (System.currentTimeMillis() - openedAtMs) / 700.0
        for ((idx, star) in driftingStars.withIndex()) {
            val x = (star.x * width).toInt().coerceIn(0, width - 1)
            val y = (star.y * height).toInt().coerceIn(0, height - 1)
            val pulse = 0.45 + ((sin((t * star.twinkle) + (idx * 0.19)) + 1.0) * 0.28)
            val alpha = (alphaBase + (alphaRange * pulse)).toInt().coerceIn(24, 230)
            val warmMix = (star.warmBias + (sin((t * 0.23) + idx) * 0.18).toFloat()).coerceIn(0f, 1f)
            val rgb = mixColor(coolRgb, warmRgb, warmMix)
            dc.fill(x, y, x + star.size, y + star.size, argb(alpha, rgb))
        }
    }

    private fun renderFocusedIlzpaakLore(dc: DrawContext): Boolean {
        val idx = focusedIlzpaakSign ?: return false
        if (showDivinationPanel && divinationPanelProgress > 0.15f) return false
        val sign = ilzpaakSigns.getOrNull(idx) ?: return false
        val loreBody = hoverLoreText(sign)
        if (loreBody.isBlank()) return false

        val showFull = isShiftDown()
        val loreToShow = if (showFull) loreBody else loreBrief(loreBody, 260)
        startIlzpaakLoreReveal(loreToShow)
        val visibleLore = visibleIlzpaakLore()
        val maxTextW = min(if (showFull) 360 else 320, width - 28)
        val hint = if (showFull) "Release Shift for brief lore" else "Hold Shift for full lore"
        val hintH = 10
        val title = "${sign.orcish} | ${sign.elven}"
        val spiritLine = "Spirit: ${sign.spirit}"
        val wrapWidth = maxTextW - 12
        if (ilzpaakLoreCachedFor != visibleLore || ilzpaakLoreCachedWidth != wrapWidth) {
            ilzpaakLoreCachedWrapped = textRenderer.wrapPlain(visibleLore, wrapWidth)
            ilzpaakLoreCachedFor = visibleLore
            ilzpaakLoreCachedWidth = wrapWidth
        }
        val wrapped = ilzpaakLoreCachedWrapped
        val maxLinesByHeight = (((height - 120).coerceAtLeast(80) - 34 - hintH) / 10).coerceAtLeast(3)
        val lineCap = min(if (showFull) 12 else 6, maxLinesByHeight)
        val bodyLines = wrapped.take(lineCap)
        val clipped = wrapped.size > bodyLines.size || (!showFull && loreToShow != loreBody)
        val titleW = textRenderer.getWidth(title)
        val spiritW = textRenderer.getWidth(spiritLine)
        val bodyW = bodyLines.maxOfOrNull { textRenderer.getWidth(it) } ?: 0
        val hintW = if (clipped || showFull) textRenderer.getWidth(hint) else 0
        val panelW = (max(max(max(titleW, spiritW), bodyW), hintW) + 16).coerceIn(196, maxTextW)
        val panelH = 38 + (bodyLines.size * 10) + if (clipped || showFull) hintH else 0
        val avoidRight = showDivinationPanel && divinationPanelProgress > 0.18f
        val left = if (avoidRight) 12 else width - panelW - 12
        val top = 62

        ilzpaakLorePanelLeft = left
        ilzpaakLorePanelTop = top
        ilzpaakLorePanelRight = left + panelW
        ilzpaakLorePanelBottom = top + panelH

        dc.fill(left, top, left + panelW, top + panelH, 0xD112101E.toInt())
        dc.drawStrokedRectangle(left, top, panelW, panelH, 0xFF5D4A2A.toInt())
        dc.drawTextWithShadow(textRenderer, Text.literal(title), left + 6, top + 6, 0xFFE2C88D.toInt())
        dc.drawTextWithShadow(textRenderer, Text.literal(spiritLine), left + 6, top + 16, 0xFFC8B08A.toInt())
        var y = top + 26
        for (line in bodyLines) {
            dc.drawTextWithShadow(textRenderer, Text.literal(line), left + 6, y, 0xFFB6AFC3.toInt())
            y += 10
        }
        if (clipped || showFull) {
            dc.drawTextWithShadow(textRenderer, Text.literal(hint), left + 6, y, 0xFF8E85A5.toInt())
        }
        return true
    }

    private fun renderHoveredIlzpaakLore(dc: DrawContext, mx: Int, my: Int) {
        val idx = hoveredIlzpaakSign ?: return
        if (showDivinationPanel && divinationPanelProgress > 0.15f) return
        val sign = ilzpaakSigns.getOrNull(idx) ?: return
        val loreBody = hoverLoreText(sign)
        if (loreBody.isBlank()) {
            ilzpaakLorePanelLeft = 0; ilzpaakLorePanelRight = 0
            ilzpaakLorePanelTop = 0; ilzpaakLorePanelBottom = 0
            return
        }

        val showFull = isShiftDown()
        val loreToShow = if (showFull) loreBody else loreBrief(loreBody, 220)
        startIlzpaakLoreReveal(loreToShow)
        val visibleLore = visibleIlzpaakLore()
        val maxTextW = min(if (showFull) 360 else 304, width - 28)
        val hint = if (showFull) "Release Shift for brief lore" else "Hold Shift for full lore"
        val hintH = 10
        val safeTop = 56
        val safeBottom = (height - 52).coerceAtLeast(safeTop + 40)
        val availableH = (safeBottom - safeTop).coerceAtLeast(40)
        val maxLinesByHeight = ((availableH - 30 - hintH) / 10).coerceAtLeast(2)
        val lineCap = min(if (showFull) 10 else 4, maxLinesByHeight)
        val title = "${sign.orcish} | ${sign.elven}"
        val wrapWidth = maxTextW - 12
        if (ilzpaakLoreCachedFor != visibleLore || ilzpaakLoreCachedWidth != wrapWidth) {
            ilzpaakLoreCachedWrapped = textRenderer.wrapPlain(visibleLore, wrapWidth)
            ilzpaakLoreCachedFor = visibleLore
            ilzpaakLoreCachedWidth = wrapWidth
        }
        val wrapped = ilzpaakLoreCachedWrapped
        val bodyLines = wrapped.take(lineCap)
        val clipped = wrapped.size > bodyLines.size || (!showFull && loreToShow != loreBody)
        val titleW = textRenderer.getWidth(title)
        val bodyW = bodyLines.maxOfOrNull { textRenderer.getWidth(it) } ?: 0
        val hintW = if (clipped || showFull) textRenderer.getWidth(hint) else 0
        val panelW = (max(max(titleW, bodyW), hintW) + 16).coerceIn(180, maxTextW)
        val panelH = 28 + (bodyLines.size * 10) + if (clipped || showFull) hintH else 0
        val anchorX = if (hoveredIlzpaakX != 0) hoveredIlzpaakX else mx
        val anchorY = if (hoveredIlzpaakY != 0) hoveredIlzpaakY else my
        val rect = chooseCornerPanelRect(anchorX, anchorY, panelW, panelH)
        val left = rect.left
        val top = rect.top.coerceIn(safeTop, safeBottom - panelH)

        ilzpaakLorePanelLeft = left
        ilzpaakLorePanelTop = top
        ilzpaakLorePanelRight = left + panelW
        ilzpaakLorePanelBottom = top + panelH

        dc.fill(left, top, left + panelW, top + panelH, 0xCC12101E.toInt())
        dc.drawStrokedRectangle(left, top, panelW, panelH, 0xFF5D4A2A.toInt())
        dc.drawTextWithShadow(textRenderer, Text.literal(title), left + 6, top + 6, 0xFFE2C88D.toInt())
        var y = top + 16
        for (line in bodyLines) {
            dc.drawTextWithShadow(textRenderer, Text.literal(line), left + 6, y, 0xFFB6AFC3.toInt())
            y += 10
        }
        if (clipped || showFull) {
            dc.drawTextWithShadow(textRenderer, Text.literal(hint), left + 6, y, 0xFF8E85A5.toInt())
        }
    }

    private fun updateDivinationPanelAnimation() {
        val target = if (displayMode == DisplayMode.ILZPAAK_SKYVIEW && showDivinationPanel) 1f else 0f
        val speed = if (target > divinationPanelProgress) 0.10f else 0.12f
        divinationPanelProgress = when {
            divinationPanelProgress < target -> min(target, divinationPanelProgress + speed)
            divinationPanelProgress > target -> max(target, divinationPanelProgress - speed)
            else -> divinationPanelProgress
        }
        if (divinationPanelProgress <= 0.001f && target <= 0f) {
            divinationPanelProgress = 0f
            if (::divinationNameField.isInitialized) {
                divinationNameField.setFocused(false)
            }
        }
    }

    private fun updateIlzpaakFocusAnimation() {
        val speed = if (focusedIlzpaakTarget > focusedIlzpaakProgress) 0.075f else 0.09f
        focusedIlzpaakProgress = when {
            focusedIlzpaakProgress < focusedIlzpaakTarget -> min(focusedIlzpaakTarget, focusedIlzpaakProgress + speed)
            focusedIlzpaakProgress > focusedIlzpaakTarget -> max(focusedIlzpaakTarget, focusedIlzpaakProgress - speed)
            else -> focusedIlzpaakProgress
        }
        if (focusedIlzpaakProgress <= 0.001f && focusedIlzpaakTarget <= 0f) {
            focusedIlzpaakSign = null
            focusedIlzpaakProgress = 0f
            selectedSkyNode = null
        }
    }

    private fun lerp(start: Float, end: Float, t: Float): Float = start + ((end - start) * t)

    private fun hoverLoreText(sign: IlzpaakSignProfile): String = when (divinationSand) {
        IlzpaakSandPath.YELLOW -> sign.yellowReading.ifBlank { sign.general }
        IlzpaakSandPath.RED -> sign.redReading.ifBlank { sign.general }
        IlzpaakSandPath.BOTH -> sign.bothReading.ifBlank { sign.general }
    }.ifBlank { sign.general }
        .replace('\n', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun loreBrief(lore: String, maxChars: Int): String {
        val clean = lore.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        if (clean.length <= maxChars) return clean
        val sentenceBreak = Regex("(?<=[.!?])\\s+")
        val firstSentences = sentenceBreak.split(clean).take(2).joinToString(" ").trim()
        if (firstSentences.isNotBlank() && firstSentences.length <= maxChars + 24) {
            return firstSentences
        }
        val clipped = clean.take(maxChars).trimEnd()
        val lastSpace = clipped.lastIndexOf(' ')
        val base = if (lastSpace > (maxChars / 2)) clipped.substring(0, lastSpace) else clipped
        return "$base..."
    }

    private fun chooseCornerPanelRect(anchorX: Int, anchorY: Int, panelW: Int, panelH: Int): UiRect {
        val safeTop = 56
        val safeBottom = height - 40
        val leftX = 12
        val rightX = width - panelW - 12
        val topY = safeTop
        val bottomY = (safeBottom - panelH).coerceAtLeast(safeTop)
        val candidates = listOf(
            UiRect(leftX, topY, leftX + panelW, topY + panelH),
            UiRect(rightX, topY, rightX + panelW, topY + panelH),
            UiRect(leftX, bottomY, leftX + panelW, bottomY + panelH),
            UiRect(rightX, bottomY, rightX + panelW, bottomY + panelH),
        )
        val avoidRight = showDivinationPanel && divinationPanelProgress > 0.18f
        return candidates.maxByOrNull { rect ->
            val cx = (rect.left + rect.right) / 2f
            val cy = (rect.top + rect.bottom) / 2f
            val dx = cx - anchorX
            val dy = cy - anchorY
            var score = (dx * dx) + (dy * dy)
            if (avoidRight && rect.right > width - (width * 0.45f)) score -= 60000f
            score
        } ?: candidates.first()
    }

    private fun pointInRealmMap(mx: Int, my: Int): Boolean {
        val plot = realmMapPlot ?: return false
        return mx >= plot.left && mx <= plot.right && my >= (plot.top + 20) && my <= plot.bottom
    }

    private fun clampMapPan(plotRef: PlotRect? = realmMapPlot): Boolean {
        val plot = plotRef ?: return false
        val bounds = mapRawBounds ?: return false
        val centerX = plot.left + (plot.width / 2f)
        val centerY = plot.top + (plot.height / 2f)

        val transformedMinX = ((bounds.minX - centerX) * mapZoom) + centerX
        val transformedMaxX = ((bounds.maxX - centerX) * mapZoom) + centerX
        val transformedMinY = ((bounds.minY - centerY) * mapZoom) + centerY
        val transformedMaxY = ((bounds.maxY - centerY) * mapZoom) + centerY

        val marginX = 12f
        val marginY = 12f

        var panMinX = (plot.right - marginX) - transformedMaxX
        var panMaxX = (plot.left + marginX) - transformedMinX
        if (panMinX > panMaxX) {
            val mid = (panMinX + panMaxX) * 0.5f
            panMinX = mid
            panMaxX = mid
        }

        var panMinY = (plot.bottom - marginY) - transformedMaxY
        var panMaxY = ((plot.top + 22f) + marginY) - transformedMinY
        if (panMinY > panMaxY) {
            val mid = (panMinY + panMaxY) * 0.5f
            panMinY = mid
            panMaxY = mid
        }

        val prevX = mapPanX
        val prevY = mapPanY
        mapPanX = mapPanX.coerceIn(panMinX, panMaxX)
        mapPanY = mapPanY.coerceIn(panMinY, panMaxY)
        return prevX != mapPanX || prevY != mapPanY
    }

    private fun argb(alpha: Int, rgb: Int): Int {
        val a = alpha.coerceIn(0, 255)
        return (a shl 24) or (rgb and 0xFFFFFF)
    }

    private fun mixColor(a: Int, b: Int, t: Float): Int {
        val mix = t.coerceIn(0f, 1f)
        val ar = (a shr 16) and 0xFF
        val ag = (a shr 8) and 0xFF
        val ab = a and 0xFF
        val br = (b shr 16) and 0xFF
        val bg = (b shr 8) and 0xFF
        val bb = b and 0xFF
        val r = (ar + ((br - ar) * mix)).roundToInt().coerceIn(0, 255)
        val g = (ag + ((bg - ag) * mix)).roundToInt().coerceIn(0, 255)
        val c = (ab + ((bb - ab) * mix)).roundToInt().coerceIn(0, 255)
        return (r shl 16) or (g shl 8) or c
    }

    private fun wrap01(v: Float): Float = when {
        v < 0f -> v + 1f
        v >= 1f -> v - 1f
        else -> v
    }

    private fun buildSkySpiritAssignments(): List<List<SpiritRealmStar>> {
        if (ilzpaakSigns.isEmpty()) return emptyList()
        val constellationsById = spiritConstellations.associateBy { it.id.lowercase() }
        val fallbackImmortalConstellation = spiritConstellations.firstOrNull { it.id.startsWith("immortal_realm_") }
        val fallbackElementalConstellation = spiritConstellations.firstOrNull { it.id.startsWith("elemental_realm_") }
        val greaterAncestrals = ancestralPool.filter { normalizeTier(it.tier) == "greater" }.ifEmpty { ancestralPool }
        val lesserAncestrals = ancestralPool.filter { normalizeTier(it.tier) == "lesser" }.ifEmpty { ancestralPool }
        val fallbackImmortalLessers = spiritConstellations
            .filter { it.id.startsWith("immortal_realm_") }
            .flatMap { constellation ->
                constellation.stars
                    .filter { normalizeTier(it.tier) == "lesser" }
                    .map { enrichSkyLoreStar(it, "Lesser Immortal Echo", constellation.name) }
            }
            .ifEmpty {
                lesserAncestrals.map { enrichSkyLoreStar(it, "Lesser Ancestral Echo", "Ancestral Realm") }
            }

        val out = mutableListOf<List<SpiritRealmStar>>()
        var greaterAncestralCursor = 0
        var lesserAncestralCursor = 0
        var immortalFallbackCursor = 0

        fun nextGreaterAncestral(): SpiritRealmStar {
            val star = greaterAncestrals[greaterAncestralCursor % greaterAncestrals.size]
            greaterAncestralCursor++
            return enrichSkyLoreStar(star, "Greater Ancestral", "Ancestral Realm")
        }

        fun nextLesserAncestral(): SpiritRealmStar {
            val star = lesserAncestrals[lesserAncestralCursor % lesserAncestrals.size]
            lesserAncestralCursor++
            return enrichSkyLoreStar(star, "Lesser Ancestral", "Ancestral Realm")
        }

        fun nextImmortalFallback(): SpiritRealmStar {
            val star = fallbackImmortalLessers[immortalFallbackCursor % fallbackImmortalLessers.size]
            immortalFallbackCursor++
            return star
        }

        for ((index, sign) in ilzpaakSigns.withIndex()) {
            val nodeCount = sign.constellationNodes.size.coerceAtLeast(1)
            val immortalId = "immortal_realm_${normalizedIdToken(sign.spirit)}"
            val elementalId = pickElementalConstellationId(index)

            val immortalConstellation = constellationsById[immortalId] ?: fallbackImmortalConstellation
            val elementalConstellation = constellationsById[elementalId] ?: fallbackElementalConstellation

            val immortalGreater = immortalConstellation?.stars
                ?.firstOrNull { normalizeTier(it.tier) == "greater" }
                ?.let { enrichSkyLoreStar(it, "Greater Immortal", immortalConstellation.name) }

            val immortalLesserPool = mutableListOf<SpiritRealmStar>()
            if (immortalConstellation != null) {
                immortalLesserPool += immortalConstellation.stars
                    .filter { normalizeTier(it.tier) == "lesser" }
                    .map { enrichSkyLoreStar(it, "Lesser Immortal", immortalConstellation.name) }
            }
            if (immortalLesserPool.isEmpty() && sign.spirit.equals("Paxahru", ignoreCase = true)) {
                for (allyId in listOf("immortal_realm_ghorza", "immortal_realm_veist")) {
                    val ally = constellationsById[allyId] ?: continue
                    immortalLesserPool += ally.stars
                        .filter { normalizeTier(it.tier) == "lesser" }
                        .map { enrichSkyLoreStar(it, "Lesser Immortal (Linked)", ally.name) }
                }
            }

            val elementalGreater = elementalConstellation?.stars
                ?.firstOrNull { normalizeTier(it.tier) == "greater" }
                ?.let { enrichSkyLoreStar(it, "Greater Elemental", elementalConstellation.name) }

            val elementalLesserPool = elementalConstellation?.stars
                ?.filter { normalizeTier(it.tier) == "lesser" }
                ?.map { enrichSkyLoreStar(it, "Lesser Elemental", elementalConstellation.name) }
                .orEmpty()

            val assigned = mutableListOf<SpiritRealmStar>()
            assigned += nextLesserAncestral()
            assigned += immortalGreater ?: nextImmortalFallback()
            assigned += elementalGreater ?: nextLesserAncestral()
            assigned += nextGreaterAncestral()
            assigned += if (immortalLesserPool.isNotEmpty()) immortalLesserPool.first() else nextImmortalFallback()
            assigned += if (elementalLesserPool.isNotEmpty()) elementalLesserPool.first() else nextLesserAncestral()

            var immortalCursor = 1
            var elementalCursor = 1
            while (assigned.size < nodeCount) {
                assigned += nextLesserAncestral()
                if (assigned.size >= nodeCount) break
                assigned += if (immortalLesserPool.isNotEmpty()) {
                    immortalLesserPool[immortalCursor % immortalLesserPool.size].also { immortalCursor++ }
                } else {
                    nextImmortalFallback()
                }
                if (assigned.size >= nodeCount) break
                assigned += if (elementalLesserPool.isNotEmpty()) {
                    elementalLesserPool[elementalCursor % elementalLesserPool.size].also { elementalCursor++ }
                } else {
                    nextLesserAncestral()
                }
                if (assigned.size >= nodeCount) break
                assigned += nextLesserAncestral()
            }
            out += assigned.take(nodeCount)
        }
        return out
    }

    private fun enrichSkyLoreStar(star: SpiritRealmStar, role: String, source: String): SpiritRealmStar {
        val taggedDomain = buildString {
            append(role)
            if (source.isNotBlank()) append(" - ").append(source)
            if (star.domain.isNotBlank()) append(" - ").append(star.domain)
        }
        val text = star.description.ifBlank { "$role spirit tied to $source." }
        return star.copy(domain = taggedDomain, description = text)
    }

    private fun pickElementalConstellationId(monthIdx: Int): String = when (monthIdx % 7) {
        0 -> "elemental_realm_neizdark" // Urin / weather -> storms
        1 -> "elemental_realm_akathro" // Akezo / healing -> waters
        2 -> "elemental_realm_skathach" // Ublulhar / beginnings -> fire spark
        3 -> "elemental_realm_bregthar" // Arwa / fertility -> earth
        4 -> "elemental_realm_kulthark" // Paxahru / stubborn pride -> metal
        5 -> "elemental_realm_fiarza" // Ghorza / travel -> winds
        else -> "elemental_realm_akathro" // Ixli fallback kept on known elemental houses
    }

    private fun normalizedIdToken(value: String): String = value.lowercase()
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .ifBlank { "unknown" }

    private fun cycleMonth(step: Int) {
        if (ilzpaakSigns.isEmpty()) return
        val size = ilzpaakSigns.size
        divinationMonthIdx = ((divinationMonthIdx + step) % size + size) % size
        highlightedIlzpaak = divinationMonthIdx
        selectedSkyNode = null
    }

    private fun syncDivinationDefaults(payload: SpiritRealmPayload?) {
        val conversion = SpiritRealmLoreRepository.conversionFromClock(payload?.clock)
        divinationMonthIdx = conversion.monthIdx
        highlightedIlzpaak = conversion.monthIdx
        divinationYear = conversion.saYear
        divinationDay = conversion.dayOfMonth
        divinationSand = SpiritRealmLoreRepository.guessSandPath(conversion)
    }

    private fun castDivination() {
        divinationResult = SpiritRealmLoreRepository.divine(
            name = if (::divinationNameField.isInitialized) divinationNameField.text else "Unknown Kub",
            calendarSystem = divinationCalendar,
            yearInput = divinationYear,
            monthIdx = divinationMonthIdx,
            dayInput = divinationDay,
            sand = divinationSand,
        )
    }

    private fun isShiftDown(): Boolean {
        val c = client ?: return false
        return InputUtil.isKeyPressed(c.window, GLFW.GLFW_KEY_LEFT_SHIFT) ||
            InputUtil.isKeyPressed(c.window, GLFW.GLFW_KEY_RIGHT_SHIFT)
    }

    override fun close() {
        client?.setScreen(parent)
    }

    override fun shouldPause() = false
}
